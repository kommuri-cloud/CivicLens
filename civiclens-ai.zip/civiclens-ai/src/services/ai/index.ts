import type { AiAnalysisResult, Severity } from '@/types';

export interface AIService {
  analyzeImage(imageData: { name: string; size: number; type: string; dataUrl?: string }): Promise<AiAnalysisResult>;
  estimateSeverity(category: string): Promise<Severity>;
  generateDescription(category: string): Promise<string>;
  verifyRepair(beforeImageUrl: string, afterImageUrl: string): Promise<{
    issue_status: string;
    visual_similarity: number;
    detected_change: string;
    verification_confidence: number;
  }>;
}

const CATEGORY_KEYWORDS: Record<string, string[]> = {
  Pothole: ['pothole', 'hole', 'road', 'crack', 'damage', 'surface'],
  'Damaged Road': ['road', 'damage', 'crack', 'broken', 'surface', 'subsidence'],
  'Garbage Dump': ['garbage', 'waste', 'trash', 'dump', 'rubbish'],
  'Overflowing Garbage Bin': ['bin', 'garbage', 'overflow', 'trash', 'waste'],
  'Blocked Drain': ['drain', 'block', 'water', 'clog', 'overflow'],
  'Open Manhole': ['manhole', 'hole', 'open', 'cover', 'danger'],
  'Broken Streetlight': ['streetlight', 'light', 'lamp', 'dark', 'broken'],
  'Water Leakage': ['water', 'leak', 'pipe', 'leakage', 'tap'],
  'Sewage Overflow': ['sewage', 'overflow', 'waste', 'drain', 'smell'],
  'Fallen Tree': ['tree', 'fallen', 'branch', 'wood', 'block'],
  'Damaged Public Infrastructure': ['infrastructure', 'broken', 'damaged', 'public', 'property'],
  Other: ['other', 'issue', 'problem'],
};

const CATEGORY_SEVERITY: Record<string, Severity> = {
  Pothole: 'medium',
  'Damaged Road': 'medium',
  'Garbage Dump': 'medium',
  'Overflowing Garbage Bin': 'low',
  'Blocked Drain': 'medium',
  'Open Manhole': 'high',
  'Broken Streetlight': 'medium',
  'Water Leakage': 'medium',
  'Sewage Overflow': 'high',
  'Fallen Tree': 'high',
  'Damaged Public Infrastructure': 'medium',
  Other: 'low',
};

const CATEGORY_DEPARTMENT: Record<string, string> = {
  Pothole: 'Roads & Infrastructure',
  'Damaged Road': 'Roads & Infrastructure',
  'Garbage Dump': 'Sanitation & Waste Management',
  'Overflowing Garbage Bin': 'Sanitation & Waste Management',
  'Blocked Drain': 'Drainage Department',
  'Open Manhole': 'Drainage Department',
  'Broken Streetlight': 'Street Lighting',
  'Water Leakage': 'Water Works',
  'Sewage Overflow': 'Sewage Department',
  'Fallen Tree': 'Urban Forestry',
  'Damaged Public Infrastructure': 'General Infrastructure',
  Other: 'General Infrastructure',
};

const CATEGORY_DESCRIPTIONS: Record<string, string> = {
  Pothole: 'Road pothole detected with surface damage. Estimated diameter and depth suggest road repair is needed.',
  'Damaged Road': 'Road surface damage detected. Cracks or subsidence visible. Structural assessment recommended.',
  'Garbage Dump': 'Accumulated waste material detected in a non-designated area. Estimated volume suggests illegal dumping.',
  'Overflowing Garbage Bin': 'Public garbage bin detected with overflow. Waste scattered around the bin area.',
  'Blocked Drain': 'Drainage blockage detected with potential water overflow. Clearing recommended to prevent flooding.',
  'Open Manhole': 'Open manhole detected with missing cover. Critical safety hazard requiring immediate attention.',
  'Broken Streetlight': 'Non-functional streetlight detected. Reduced visibility in the area at night.',
  'Water Leakage': 'Water leakage detected from pipe or supply source. Water accumulation visible on surface.',
  'Sewage Overflow': 'Sewage overflow detected on public surface. Health hazard identified. Immediate action required.',
  'Fallen Tree': 'Fallen tree detected blocking pathway or road. Clearance required for safe passage.',
  'Damaged Public Infrastructure': 'Damaged public infrastructure detected. Repair or maintenance recommended.',
  Other: 'Civic issue detected. Manual review recommended for proper categorization.',
};

function pickCategoryFromFilename(filename: string): string {
  const lower = filename.toLowerCase();
  let bestMatch = 'Other';
  let bestScore = 0;

  for (const [category, keywords] of Object.entries(CATEGORY_KEYWORDS)) {
    let score = 0;
    for (const keyword of keywords) {
      if (lower.includes(keyword)) score += 1;
    }
    if (score > bestScore) {
      bestScore = score;
      bestMatch = category;
    }
  }

  return bestMatch;
}

function generateConfidence(category: string): number {
  const base = 80 + Math.floor(Math.random() * 18);
  return Math.min(base, 98);
}

export class MockAIService implements AIService {
  async analyzeImage(imageData: { name: string; size: number; type: string; dataUrl?: string }): Promise<AiAnalysisResult> {
    await new Promise((r) => setTimeout(r, 1200 + Math.random() * 800));

    const detectedCategory = pickCategoryFromFilename(imageData.name);
    const confidence = generateConfidence(detectedCategory);
    const estimatedSeverity = CATEGORY_SEVERITY[detectedCategory] || 'medium';
    const suggestedDepartment = CATEGORY_DEPARTMENT[detectedCategory] || 'General Infrastructure';
    const aiDescription = CATEGORY_DESCRIPTIONS[detectedCategory] || 'Civic issue detected.';

    return {
      detected_category: detectedCategory,
      confidence,
      estimated_severity: estimatedSeverity,
      suggested_department: suggestedDepartment,
      ai_description: aiDescription,
    };
  }

  async estimateSeverity(category: string): Promise<Severity> {
    return CATEGORY_SEVERITY[category] || 'medium';
  }

  async generateDescription(category: string): Promise<string> {
    return CATEGORY_DESCRIPTIONS[category] || 'Civic issue detected.';
  }

  async verifyRepair(_beforeImageUrl: string, _afterImageUrl: string) {
    await new Promise((r) => setTimeout(r, 1500 + Math.random() * 1000));

    const confidence = 85 + Math.floor(Math.random() * 12);
    return {
      issue_status: 'Likely Resolved',
      visual_similarity: 30 + Math.floor(Math.random() * 25),
      detected_change: 'Visible repair work detected. The reported issue area appears to have been addressed with new material or clearing.',
      verification_confidence: confidence,
    };
  }
}

export function createAIService(): AIService {
  const apiKey = import.meta.env.VITE_AI_API_KEY;
  if (apiKey) {
    // In a real implementation, this would use the actual AI provider
    // For now, we use the mock service which provides realistic results
    return new MockAIService();
  }
  return new MockAIService();
}

export const aiService = createAIService();
