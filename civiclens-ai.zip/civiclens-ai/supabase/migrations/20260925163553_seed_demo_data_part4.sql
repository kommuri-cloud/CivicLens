/*
# CivicLens AI - Seed Data Part 4: AI Analysis Records
*/
INSERT INTO issue_ai_analysis (issue_id, detected_category, confidence, estimated_severity, suggested_department, ai_description, analysis_model) VALUES
('66666666-0000-0000-0000-000000000001', 'Pothole', 94.00, 'high', 'Roads & Infrastructure', 'Large road pothole detected on the left side of the road. Depth estimated at 15-20cm. Immediate repair recommended.', 'mock-v1'),
('66666666-0000-0000-0000-000000000002', 'Garbage Dump', 87.00, 'medium', 'Sanitation & Waste Management', 'Accumulated waste material detected near a residential area. Estimated volume: 2-3 cubic meters.', 'mock-v1'),
('66666666-0000-0000-0000-000000000003', 'Open Manhole', 96.00, 'high', 'Drainage Department', 'Open manhole detected with no cover. High risk of vehicle damage or pedestrian injury. Urgent attention required.', 'mock-v1'),
('66666666-0000-0000-0000-000000000005', 'Blocked Drain', 89.00, 'medium', 'Drainage Department', 'Drainage blockage detected with water overflow visible on road surface. Clearing recommended before monsoon.', 'mock-v1'),
('66666666-0000-0000-0000-000000000006', 'Sewage Overflow', 91.00, 'high', 'Sewage Department', 'Sewage overflow detected on public road. Health hazard identified. Immediate action required.', 'mock-v1'),
('66666666-0000-0000-0000-000000000007', 'Pothole', 88.00, 'medium', 'Roads & Infrastructure', 'Multiple potholes detected on road surface. Average diameter 30-40cm. Repair recommended.', 'mock-v1'),
('66666666-0000-0000-0000-000000000008', 'Overflowing Garbage Bin', 85.00, 'low', 'Sanitation & Waste Management', 'Public garbage bin overflowing with waste scattered around. Collection needed.', 'mock-v1'),
('66666666-0000-0000-0000-000000000009', 'Water Leakage', 93.00, 'high', 'Water Works', 'Significant water leakage detected from underground pipe. Water wastage estimated at high volume.', 'mock-v1'),
('66666666-0000-0000-0000-000000000010', 'Fallen Tree', 90.00, 'medium', 'Urban Forestry', 'Fallen tree detected blocking road. Estimated diameter 40cm. Road clearance required.', 'mock-v1'),
('66666666-0000-0000-0000-000000000011', 'Damaged Road', 92.00, 'high', 'Roads & Infrastructure', 'Road subsidence detected. Surface depression estimated at 10cm depth. Structural assessment recommended.', 'mock-v1'),
('66666666-0000-0000-0000-000000000013', 'Pothole', 86.00, 'medium', 'Roads & Infrastructure', 'Road pothole detected near junction. Diameter approximately 25cm.', 'mock-v1'),
('66666666-0000-0000-0000-000000000014', 'Open Manhole', 97.00, 'high', 'Drainage Department', 'Open manhole with missing cover detected on main road. Critical safety hazard.', 'mock-v1'),
('66666666-0000-0000-0000-000000000015', 'Pothole', 82.00, 'low', 'Roads & Infrastructure', 'Minor pothole detected. Diameter approximately 15cm. Low urgency.', 'mock-v1'),
('66666666-0000-0000-0000-000000000016', 'Broken Streetlight', 84.00, 'medium', 'Street Lighting', 'Non-functional streetlight detected. Multiple units may be affected in the area.', 'mock-v1'),
('66666666-0000-0000-0000-000000000017', 'Sewage Overflow', 95.00, 'high', 'Sewage Department', 'Sewage overflow detected near school area. Public health risk. Urgent remediation needed.', 'mock-v1'),
('66666666-0000-0000-0000-000000000018', 'Garbage Dump', 88.00, 'medium', 'Sanitation & Waste Management', 'Construction and mixed waste detected near canal. Estimated volume 3-4 cubic meters.', 'mock-v1'),
('66666666-0000-0000-0000-000000000020', 'Water Leakage', 87.00, 'medium', 'Water Works', 'Water leakage detected from underground source. Surface water accumulation visible.', 'mock-v1'),
('66666666-0000-0000-0000-000000000021', 'Pothole', 95.00, 'high', 'Roads & Infrastructure', 'Deep pothole detected on main road. Depth estimated 20cm+. Risk to two-wheeler traffic.', 'mock-v1'),
('66666666-0000-0000-0000-000000000022', 'Blocked Drain', 86.00, 'medium', 'Drainage Department', 'Drain blockage detected with debris accumulation. Water overflow visible.', 'mock-v1'),
('66666666-0000-0000-0000-000000000023', 'Overflowing Garbage Bin', 83.00, 'low', 'Sanitation & Waste Management', 'Bin overflow detected with scattered waste. Routine collection needed.', 'mock-v1'),
('66666666-0000-0000-0000-000000000024', 'Pothole', 89.00, 'medium', 'Roads & Infrastructure', 'Cluster of potholes detected on main road. Multiple repair points identified.', 'mock-v1'),
('66666666-0000-0000-0000-000000000025', 'Fallen Tree', 92.00, 'high', 'Urban Forestry', 'Large fallen tree detected blocking road. Estimated trunk diameter 50cm.', 'mock-v1'),
('66666666-0000-0000-0000-000000000026', 'Damaged Public Infrastructure', 85.00, 'medium', 'General Infrastructure', 'Damaged footpath detected with broken tiles and uneven surface. Pedestrian hazard.', 'mock-v1'),
('66666666-0000-0000-0000-000000000028', 'Damaged Road', 94.00, 'high', 'Roads & Infrastructure', 'Road surface collapse detected near bridge approach. Structural integrity concern.', 'mock-v1'),
('66666666-0000-0000-0000-000000000029', 'Broken Streetlight', 86.00, 'medium', 'Street Lighting', 'Multiple non-functional streetlights detected. Area has reduced visibility at night.', 'mock-v1'),
('66666666-0000-0000-0000-000000000030', 'Open Manhole', 96.00, 'high', 'Drainage Department', 'Open manhole on busy road. Critical safety hazard for vehicles and pedestrians.', 'mock-v1'),
('66666666-0000-0000-0000-000000000031', 'Pothole', 81.00, 'low', 'Roads & Infrastructure', 'Small pothole detected in interior lane. Low urgency repair.', 'mock-v1')
ON CONFLICT DO NOTHING;
