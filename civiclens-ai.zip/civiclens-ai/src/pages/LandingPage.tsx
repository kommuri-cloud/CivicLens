import { Link } from 'react-router-dom';
import { useState } from 'react';
import {
  Camera, Brain, MapPin, Users, ShieldCheck, BarChart3, ChevronDown,
  CheckCircle2, AlertTriangle, FileText, Bell, Clock, Zap, ArrowRight,
  Building2, Leaf, Sparkles,
} from 'lucide-react';
import { useI18n } from '@/lib/i18n';

export function LandingPage() {
  const { t } = useI18n();
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const faqs = [
    { q: 'How does AI image analysis work?', a: 'When you upload a photo of a civic issue, our AI system analyzes the image to identify the type of problem (pothole, garbage, drainage, etc.), estimate its severity, and suggest the appropriate municipal department. You can always review and correct the AI analysis before submitting.' },
    { q: 'What if someone already reported the same issue?', a: 'Our duplicate detection system checks for nearby existing complaints before you submit. If a similar issue has been reported within 500 meters, you can support the existing complaint instead of creating a duplicate, which helps municipal officers prioritize effectively.' },
    { q: 'How do I know if my complaint was actually fixed?', a: 'When an officer marks an issue as resolved, they upload a repair photo. Our AI compares the before and after images. Then you receive a notification to verify whether the issue was actually fixed. If not, you can reopen the complaint.' },
    { q: 'What is SLA and why does it matter?', a: 'SLA (Service Level Agreement) defines the target resolution time for each issue based on severity. High-severity issues like open manholes have a 24-hour SLA, while low-severity issues have up to 7 days. The system automatically flags overdue complaints.' },
    { q: 'Is my personal information safe?', a: 'Your personal information is kept private. Other citizens cannot see your name or contact details on the community map. Only municipal officers and admins can access complaint details for resolution purposes.' },
    { q: 'Which areas are currently supported?', a: 'CivicLens AI is currently in demo mode for Vijayawada. The platform is designed to be deployed for any city. Contact us to bring CivicLens AI to your municipality.' },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Nav */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-teal-600 flex items-center justify-center">
              <span className="text-white font-bold text-sm">CL</span>
            </div>
            <span className="font-bold text-slate-900">{t('app.name')}</span>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <a href="#how-it-works" className="text-sm text-slate-600 hover:text-slate-900">How It Works</a>
            <a href="#features" className="text-sm text-slate-600 hover:text-slate-900">Features</a>
            <a href="#faq" className="text-sm text-slate-600 hover:text-slate-900">FAQ</a>
            <Link to="/login" className="text-sm font-medium text-slate-700 hover:text-slate-900">{t('nav.login')}</Link>
            <Link to="/register" className="text-sm font-medium text-white bg-teal-600 hover:bg-teal-700 px-4 py-2 rounded-lg transition-colors">
              {t('nav.register')}
            </Link>
          </div>
          <Link to="/login" className="md:hidden text-sm font-medium text-white bg-teal-600 px-3 py-1.5 rounded-lg">
            {t('nav.login')}
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-20 px-4 sm:px-6 bg-gradient-to-b from-teal-50 to-white">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 text-teal-700 text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            AI-Powered Civic Issue Reporting
          </div>
          <h1 className="text-4xl sm:text-6xl font-bold text-slate-900 tracking-tight mb-6">
            Turn Civic Problems<br />Into Action.
          </h1>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto mb-8 leading-relaxed">
            Report potholes, garbage, drainage, streetlight and infrastructure problems with a photo.
            AI identifies the issue, routes it to the right department, and helps track it until resolution.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/register" className="inline-flex items-center gap-2 bg-teal-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-teal-700 transition-colors shadow-lg shadow-teal-600/20">
              <Camera className="w-5 h-5" />
              {t('action.report')}
            </Link>
            <Link to="/login" className="inline-flex items-center gap-2 bg-white text-slate-700 border border-slate-300 px-6 py-3 rounded-xl font-medium hover:bg-slate-50 transition-colors">
              <MapPin className="w-5 h-5" />
              {t('action.viewMap')}
            </Link>
          </div>
          <p className="text-xs text-slate-400 mt-6">
            Demo accounts available — login with citizen@demo.com, officer@demo.com, or admin@demo.com (password: Demo1234!)
          </p>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-slate-900 text-center mb-4">How It Works</h2>
          <p className="text-slate-500 text-center mb-12 max-w-2xl mx-auto">From photo to resolution in four simple steps</p>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { icon: Camera, title: '1. Capture', desc: 'Take a photo of the civic issue with your phone camera.' },
              { icon: Brain, title: '2. AI Analyzes', desc: 'AI identifies the issue type, severity, and routes it to the right department.' },
              { icon: Users, title: '3. Community Supports', desc: 'Citizens nearby can support existing complaints instead of creating duplicates.' },
              { icon: CheckCircle2, title: '4. Verified Resolution', desc: 'Officers fix the issue, upload repair photos, and citizens verify the fix.' },
            ].map((step, i) => (
              <div key={i} className="text-center">
                <div className="w-16 h-16 rounded-2xl bg-teal-50 flex items-center justify-center mx-auto mb-4">
                  <step.icon className="w-8 h-8 text-teal-600" />
                </div>
                <h3 className="font-semibold text-slate-900 mb-2">{step.title}</h3>
                <p className="text-sm text-slate-500">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* AI-Powered Reporting */}
      <section id="features" className="py-20 px-4 sm:px-6 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 text-teal-700 text-sm font-medium mb-4">
                <Brain className="w-4 h-4" /> AI-Powered Reporting
              </div>
              <h2 className="text-3xl font-bold text-slate-900 mb-4">AI identifies the issue for you</h2>
              <p className="text-slate-600 mb-6">No more guessing which department to contact. Our AI analyzes your photo and automatically detects the issue type, estimates severity, and suggests the right municipal department.</p>
              <ul className="space-y-3">
                {[
                  'Image classification for 11+ civic issue types',
                  'Automatic severity estimation (High, Medium, Low)',
                  'Smart department routing based on issue category',
                  'Duplicate detection within 500m radius',
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-teal-600 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-white rounded-2xl border border-slate-200 shadow-lg p-6">
              <div className="flex items-center gap-2 mb-4 pb-4 border-b border-slate-100">
                <div className="w-8 h-8 rounded-lg bg-teal-100 flex items-center justify-center">
                  <Brain className="w-5 h-5 text-teal-600" />
                </div>
                <span className="font-medium text-slate-900">AI Analysis Result</span>
              </div>
              <div className="space-y-3">
                <div className="flex justify-between"><span className="text-sm text-slate-500">Detected Issue:</span><span className="text-sm font-medium text-slate-900">Pothole</span></div>
                <div className="flex justify-between"><span className="text-sm text-slate-500">Confidence:</span><span className="text-sm font-medium text-teal-600">94%</span></div>
                <div className="flex justify-between"><span className="text-sm text-slate-500">Severity:</span><span className="text-sm font-medium text-red-600">High</span></div>
                <div className="flex justify-between"><span className="text-sm text-slate-500">Suggested Dept:</span><span className="text-sm font-medium text-slate-900">Roads & Infrastructure</span></div>
                <div className="pt-3 border-t border-slate-100">
                  <p className="text-sm text-slate-600">Large road pothole detected on the left side of the road. Depth estimated at 15-20cm. Immediate repair recommended.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Transparent Resolution */}
      <section className="py-20 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1 bg-white rounded-2xl border border-slate-200 shadow-lg p-6">
              <div className="flex items-center gap-2 mb-4 pb-4 border-b border-slate-100">
                <Clock className="w-5 h-5 text-teal-600" />
                <span className="font-medium text-slate-900">Complaint Timeline</span>
              </div>
              <div className="space-y-4">
                {[
                  { status: 'Submitted', time: '2 days ago', done: true },
                  { status: 'AI Analyzed', time: '2 days ago', done: true },
                  { status: 'Assigned to Roads Dept', time: '2 days ago', done: true },
                  { status: 'Officer Acknowledged', time: '1 day ago', done: true },
                  { status: 'Repair in Progress', time: '12h ago', done: true },
                  { status: 'Awaiting Citizen Verification', time: 'Pending', done: false },
                ].map((step, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center ${step.done ? 'bg-teal-600' : 'bg-slate-200'}`}>
                      {step.done ? <CheckCircle2 className="w-4 h-4 text-white" /> : <div className="w-2 h-2 rounded-full bg-slate-400" />}
                    </div>
                    <span className={`text-sm ${step.done ? 'text-slate-900 font-medium' : 'text-slate-400'}`}>{step.status}</span>
                    <span className="text-xs text-slate-400 ml-auto">{step.time}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="order-1 md:order-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 text-teal-700 text-sm font-medium mb-4">
                <ShieldCheck className="w-4 h-4" /> Transparent Resolution
              </div>
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Track every step from report to repair</h2>
              <p className="text-slate-600 mb-6">See exactly where your complaint is in the resolution process. Every status change is timestamped and visible. No more wondering what happened to your report.</p>
              <ul className="space-y-3">
                {[
                  'Real-time status timeline with timestamps',
                  'SLA tracking with breach alerts',
                  'Before/after repair photo comparison',
                  'AI-assisted repair verification',
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 text-teal-600 mt-0.5 flex-shrink-0" />
                    <span className="text-slate-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Community Verification */}
      <section className="py-20 px-4 sm:px-6 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-teal-600" />
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Community Verification</h3>
              <p className="text-sm text-slate-500">Citizens verify whether issues were actually fixed, creating accountability and trust in the system.</p>
            </div>
            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-teal-600" />
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Municipal Intelligence</h3>
              <p className="text-sm text-slate-500">Analytics dashboards for officers and admins with heatmaps, SLA compliance, and road health scores.</p>
            </div>
            <div className="bg-white rounded-2xl border border-slate-200 p-6">
              <div className="w-12 h-12 rounded-xl bg-teal-50 flex items-center justify-center mb-4">
                <Bell className="w-6 h-6 text-teal-600" />
              </div>
              <h3 className="font-semibold text-slate-900 mb-2">Smart Notifications</h3>
              <p className="text-sm text-slate-500">Get notified at every stage — submission, assignment, status changes, resolution, and verification requests.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Analytics */}
      <section className="py-20 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-100 text-teal-700 text-sm font-medium mb-4">
                <BarChart3 className="w-4 h-4" /> Analytics & Insights
              </div>
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Data-driven municipal management</h2>
              <p className="text-slate-600 mb-6">Officers and administrators get powerful analytics dashboards with real-time insights into complaint trends, department workload, SLA compliance, and problem areas.</p>
              <div className="grid grid-cols-2 gap-4">
                {[
                  { icon: AlertTriangle, label: 'SLA Breach Alerts', value: 'Auto-flagged' },
                  { icon: MapPin, label: 'Issue Heatmap', value: 'GIS-style' },
                  { icon: Zap, label: 'Road Health Score', value: 'Per area' },
                  { icon: FileText, label: 'Resolution Reports', value: 'By dept' },
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-slate-50">
                    <item.icon className="w-5 h-5 text-teal-600" />
                    <div>
                      <p className="text-xs text-slate-500">{item.label}</p>
                      <p className="text-sm font-medium text-slate-900">{item.value}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-teal-600 rounded-2xl p-6 text-white">
                <p className="text-4xl font-bold">84%</p>
                <p className="text-sm text-teal-100 mt-1">SLA Compliance</p>
              </div>
              <div className="bg-white rounded-2xl border border-slate-200 p-6">
                <p className="text-4xl font-bold text-slate-900">31h</p>
                <p className="text-sm text-slate-500 mt-1">Avg Resolution</p>
              </div>
              <div className="bg-white rounded-2xl border border-slate-200 p-6">
                <p className="text-4xl font-bold text-slate-900">1,247</p>
                <p className="text-sm text-slate-500 mt-1">Issues Reported</p>
              </div>
              <div className="bg-slate-900 rounded-2xl p-6 text-white">
                <p className="text-4xl font-bold">72</p>
                <p className="text-sm text-slate-300 mt-1">Road Health Score</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="py-20 px-4 sm:px-6 bg-slate-50">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-slate-900 text-center mb-12">Frequently Asked Questions</h2>
          <div className="space-y-3">
            {faqs.map((faq, i) => (
              <div key={i} className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between p-5 text-left"
                >
                  <span className="font-medium text-slate-900">{faq.q}</span>
                  <ChevronDown className={`w-5 h-5 text-slate-400 transition-transform ${openFaq === i ? 'rotate-180' : ''}`} />
                </button>
                {openFaq === i && (
                  <div className="px-5 pb-5 text-slate-600 text-sm">{faq.a}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 sm:px-6 bg-teal-600">
        <div className="max-w-3xl mx-auto text-center text-white">
          <h2 className="text-3xl font-bold mb-4">Ready to make your city better?</h2>
          <p className="text-teal-100 mb-8">Join CivicLens AI and start reporting civic issues in your area today.</p>
          <Link to="/register" className="inline-flex items-center gap-2 bg-white text-teal-700 px-6 py-3 rounded-xl font-medium hover:bg-teal-50 transition-colors">
            Get Started <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 bg-slate-900 text-slate-400">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-teal-600 flex items-center justify-center">
                <span className="text-white font-bold text-xs">CL</span>
              </div>
              <span className="font-medium text-white">CivicLens AI</span>
            </div>
            <p className="text-sm">Demo platform for Vijayawada. Not officially connected to any municipal corporation.</p>
            <div className="flex items-center gap-4 text-sm">
              <Link to="/login" className="hover:text-white">Login</Link>
              <Link to="/register" className="hover:text-white">Register</Link>
              <Link to="/how-it-works" className="hover:text-white">How It Works</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
