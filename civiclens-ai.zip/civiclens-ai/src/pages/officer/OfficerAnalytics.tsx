import { useEffect, useState, useCallback } from 'react';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { Card, StatCard, PageHeader, Spinner } from '@/components/ui';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, LineChart, Line, Area, AreaChart,
} from 'recharts';
import { formatSlaRemaining, isSlaBreached } from '@/lib/utils';
import { TrendingUp, Clock, CheckCircle2, AlertTriangle } from 'lucide-react';
import type { Issue } from '@/types';

const SEVERITY_COLORS: Record<string, string> = { high: '#ef4444', medium: '#f59e0b', low: '#10b981' };
const STATUS_COLORS: Record<string, string> = {
  submitted: '#94a3b8', ai_analyzed: '#3b82f6', assigned: '#6366f1',
  acknowledged: '#06b6d4', in_progress: '#f97316', resolved: '#22c55e',
  citizen_verification: '#a855f7', verified: '#10b981', reopened: '#ef4444', closed: '#64748b',
};

export function OfficerAnalytics() {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [issues, setIssues] = useState<Issue[]>([]);

  const fetchData = useCallback(async () => {
    if (!profile?.department_id) return;
    const { data } = await supabase
      .from('issues')
      .select('*')
      .eq('department_id', profile.department_id)
      .order('created_at', { ascending: false });
    setIssues((data || []) as Issue[]);
    setLoading(false);
  }, [profile]);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="flex justify-center py-20"><Spinner size="lg" /></div>;

  const resolved = issues.filter((i) => ['resolved', 'citizen_verification', 'verified', 'closed'].includes(i.status));
  const slaCompliant = resolved.filter((i) => i.sla_deadline && !isSlaBreached(i.sla_deadline)).length;
  const slaBreached = issues.filter((i) => i.sla_breached || (i.sla_deadline && isSlaBreached(i.sla_deadline) && !['verified', 'closed'].includes(i.status))).length;
  const slaRate = resolved.length > 0 ? Math.round((slaCompliant / resolved.length) * 100) : 0;

  // Status distribution
  const statusData = Object.entries(
    issues.reduce((acc, i) => { acc[i.status] = (acc[i.status] || 0) + 1; return acc; }, {} as Record<string, number>)
  ).map(([name, value]) => ({ name: name.replace(/_/g, ' '), value, color: STATUS_COLORS[name] || '#94a3b8' }));

  // Severity distribution
  const severityData = [
    { name: 'High', value: issues.filter((i) => i.severity === 'high').length, color: SEVERITY_COLORS.high },
    { name: 'Medium', value: issues.filter((i) => i.severity === 'medium').length, color: SEVERITY_COLORS.medium },
    { name: 'Low', value: issues.filter((i) => i.severity === 'low').length, color: SEVERITY_COLORS.low },
  ].filter((d) => d.value > 0);

  // Issues over time (last 7 days)
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return d;
  });
  const timeData = last7Days.map((d) => {
    const dayStr = d.toLocaleDateString('en', { weekday: 'short' });
    const count = issues.filter((i) => new Date(i.created_at).toDateString() === d.toDateString()).length;
    return { day: dayStr, issues: count };
  });

  // Resolution time by category
  const resolutionTimes = issues
    .filter((i) => i.resolved_at)
    .reduce((acc, i) => {
      const hours = (new Date(i.resolved_at!).getTime() - new Date(i.created_at).getTime()) / (1000 * 60 * 60);
      const cat = i.title.split(' ').slice(0, 2).join(' ');
      if (!acc[cat]) acc[cat] = { total: 0, count: 0 };
      acc[cat].total += hours;
      acc[cat].count += 1;
      return acc;
    }, {} as Record<string, { total: number; count: number }>);

  const resolutionData = Object.entries(resolutionTimes).map(([name, data]) => ({
    name,
    hours: Math.round(data.total / data.count),
  }));

  return (
    <div className="space-y-6">
      <PageHeader title="Analytics" subtitle="Department performance and complaint insights" />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Total Issues" value={issues.length} icon={<TrendingUp className="w-6 h-6" />} color="bg-teal-50 text-teal-600" />
        <StatCard label="Resolved" value={resolved.length} icon={<CheckCircle2 className="w-6 h-6" />} color="bg-emerald-50 text-emerald-600" />
        <StatCard label="SLA Compliance" value={`${slaRate}%`} icon={<Clock className="w-6 h-6" />} color="bg-blue-50 text-blue-600" />
        <StatCard label="SLA Breached" value={slaBreached} icon={<AlertTriangle className="w-6 h-6" />} color="bg-red-50 text-red-600" />
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-4">Issues Over Time (7 days)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={timeData}>
              <defs><linearGradient id="colorIssues" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#0d9488" stopOpacity={0.3} /><stop offset="95%" stopColor="#0d9488" stopOpacity={0} /></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="day" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Area type="monotone" dataKey="issues" stroke="#0d9488" fill="url(#colorIssues)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-4">Status Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={{ fontSize: 10 }}>
                {statusData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip />
              <Legend wrapperStyle={{ fontSize: 10 }} />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-4">Severity Distribution</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={severityData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                {severityData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-4">Avg Resolution Time (hours)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={resolutionData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-15} textAnchor="end" height={60} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="hours" fill="#0d9488" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>
    </div>
  );
}
