import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, Badge, Spinner, PageHeader, EmptyState } from '@/components/ui';
import { Button } from '@/components/ui/Button';
import { Users, Search, Shield, UserCog } from 'lucide-react';
import type { Profile, Department, Ward } from '@/types';

export function UserManagement() {
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<Profile[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [wards, setWards] = useState<Ward[]>([]);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [{ data: profiles }, { data: depts }, { data: w }] = await Promise.all([
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
      supabase.from('departments').select('*'),
      supabase.from('wards').select('*'),
    ]);
    setUsers((profiles || []) as Profile[]);
    setDepartments((depts || []) as Department[]);
    setWards((w || []) as Ward[]);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const filteredUsers = users.filter((u) => {
    if (roleFilter !== 'all' && u.role !== roleFilter) return false;
    if (search && !u.full_name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const setRole = async (userId: string, role: string) => {
    const { error } = await supabase.rpc('set_user_role', { p_user_id: userId, p_role: role });
    if (error) {
      alert('Could not update user role.');
      return;
    }
    await fetchData();
  };

  const assignOfficer = async (userId: string, deptId: string, wardId: string) => {
    const { error } = await supabase.rpc('set_officer_assignment', {
      p_officer_id: userId,
      p_department_id: deptId,
      p_ward_id: wardId,
    });
    if (error) {
      alert('Could not assign officer.');
      return;
    }
    await fetchData();
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size="lg" /></div>;

  return (
    <div>
      <PageHeader title="User Management" subtitle={`${users.length} registered users`} />

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>
        <select
          value={roleFilter}
          onChange={(e) => setRoleFilter(e.target.value)}
          className="px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
        >
          <option value="all">All Roles</option>
          <option value="citizen">Citizens</option>
          <option value="officer">Officers</option>
          <option value="admin">Admins</option>
        </select>
      </div>

      {filteredUsers.length === 0 ? (
        <Card><EmptyState icon={<Users className="w-12 h-12" />} title="No users found" /></Card>
      ) : (
        <div className="space-y-3">
          {filteredUsers.map((user) => (
            <Card key={user.id}>
              <div className="flex flex-col sm:flex-row sm:items-center gap-4">
                <div className="flex items-center gap-3 flex-1">
                  <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center text-sm font-bold text-slate-600">
                    {user.full_name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <p className="font-medium text-slate-900">{user.full_name}</p>
                    <p className="text-xs text-slate-500">{user.phone || 'No phone'}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <Badge className={user.role === 'admin' ? 'bg-purple-100 text-purple-700 border-purple-200' : user.role === 'officer' ? 'bg-blue-100 text-blue-700 border-blue-200' : 'bg-teal-100 text-teal-700 border-teal-200'}>
                    <Shield className="w-3 h-3" /> {user.role}
                  </Badge>

                  {/* Role changer */}
                  <select
                    value={user.role}
                    onChange={(e) => setRole(user.id, e.target.value)}
                    className="px-2 py-1 border border-slate-300 rounded text-xs"
                  >
                    <option value="citizen">Citizen</option>
                    <option value="officer">Officer</option>
                    <option value="admin">Admin</option>
                  </select>

                  {/* Officer assignment */}
                  {user.role === 'officer' && (
                    <div className="flex gap-1">
                      <select
                        value={user.department_id || ''}
                        onChange={(e) => assignOfficer(user.id, e.target.value, user.ward_id || '')}
                        className="px-2 py-1 border border-slate-300 rounded text-xs"
                      >
                        <option value="">Dept...</option>
                        {departments.map((d) => <option key={d.id} value={d.id}>{d.name.split(' ')[0]}</option>)}
                      </select>
                      <select
                        value={user.ward_id || ''}
                        onChange={(e) => assignOfficer(user.id, user.department_id || '', e.target.value)}
                        className="px-2 py-1 border border-slate-300 rounded text-xs"
                      >
                        <option value="">Ward...</option>
                        {wards.map((w) => <option key={w.id} value={w.id}>W{w.number}</option>)}
                      </select>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
