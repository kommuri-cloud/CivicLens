import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { aiService } from '@/services/ai';
import { Card, Badge, Spinner, EmptyState, Button } from '@/components/ui';
import { IssueMap } from '@/components/IssueMap';
import {
  formatStatus, formatSeverity, severityColor, statusColor, statusDotColor,
  formatDateTime, formatSlaRemaining, isSlaBreached, classNames,
} from '@/lib/utils';
import {
  ArrowLeft, MapPin, Clock, Brain, CheckCircle2, XCircle, Camera,
  Building2, User as UserIcon, AlertCircle, Upload, Users,
} from 'lucide-react';
import type { IssueWithRelations } from '@/types';

export function ComplaintDetail() {
  const { id } = useParams();
  const { profile } = useAuth();
  const navigate = useNavigate();

  const [issue, setIssue] = useState<IssueWithRelations | null>(null);
  const [loading, setLoading] = useState(true);
  const [verifying, setVerifying] = useState(false);
  const [verifyResult, setVerifyResult] = useState<'fixed' | 'not_fixed' | null>(null);
  const [verifyReason, setVerifyReason] = useState('');
  const [verifyPhoto, setVerifyPhoto] = useState<File | null>(null);
  const [submittingVerify, setSubmittingVerify] = useState(false);
  const [supported, setSupported] = useState(false);

  const fetchIssue = useCallback(async () => {
    if (!id) return;
    setLoading(true);

    const { data } = await supabase
      .from('issues')
      .select(`
        *,
        category:issue_categories(*),
        department:departments(*),
        ward:wards(*),
        assigned_officer:profiles!issues_assigned_officer_id_fkey(*),
        citizen:profiles!issues_citizen_id_fkey(*),
        images:issue_images(*),
        ai_analysis:issue_ai_analysis(*),
        status_history:issue_status_history(*),
        verifications:issue_verifications(*)
      `)
      .eq('id', id)
      .maybeSingle();

    setIssue(data as unknown as IssueWithRelations);
    setLoading(false);
  }, [id]);

  useEffect(() => {
    fetchIssue();
  }, [fetchIssue]);

  const handleVerify = async (isFixed: boolean) => {
    setSubmittingVerify(true);
    try {
      let photoUrl: string | null = null;
      if (verifyPhoto) {
        const fileName = `${issue!.id}/verification-${Date.now()}.jpg`;
        await supabase.storage.from('issue-images').upload(fileName, verifyPhoto);
        const { data: urlData } = supabase.storage.from('issue-images').getPublicUrl(fileName);
        photoUrl = urlData.publicUrl;
      }

      const { error } = await supabase.rpc('verify_issue', {
        p_issue_id: issue!.id,
        p_is_fixed: isFixed,
        p_reason: verifyReason,
        p_image_url: photoUrl,
      });

      if (error) throw error;

      setVerifyResult(isFixed ? 'fixed' : 'not_fixed');
      await fetchIssue();
    } catch (err) {
      console.error('Verification failed', err);
      alert('Could not submit your verification. Please try again.');
    } finally {
      setSubmittingVerify(false);
    }
  };

  const handleSupport = async () => {
    if (!issue) return;
    const { error } = await supabase.rpc('support_issue', { p_issue_id: issue.id });
    if (error) {
      alert('You have already supported this issue.');
      return;
    }
    setSupported(true);
    await fetchIssue();
  };

  if (loading) {
    return <div className="flex justify-center py-20"><Spinner size="lg" /></div>;
  }

  if (!issue) {
    return (
      <Card>
        <EmptyState icon={<AlertCircle className="w-12 h-12" />} title="Complaint not found" description="This complaint may have been removed." >
          <Link to="/dashboard/complaints"><Button>Back to Complaints</Button></Link>
        </EmptyState>
      </Card>
    );
  }

  const isOwnComplaint = profile?.id === issue.citizen_id;
  const slaBreached = isSlaBreached(issue.sla_deadline);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Link to="/dashboard/complaints" className="flex items-center gap-2 text-sm text-slate-600 hover:text-slate-900">
        <ArrowLeft className="w-4 h-4" /> Back to Complaints
      </Link>

      {/* Header */}
      <Card>
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="text-sm font-mono text-slate-500">{issue.complaint_id}</span>
              <Badge className={severityColor(issue.severity)}>{formatSeverity(issue.severity)} Severity</Badge>
              <Badge className={statusColor(issue.status)}>{formatStatus(issue.status)}</Badge>
            </div>
            <h1 className="text-xl font-bold text-slate-900">{issue.title}</h1>
            <p className="text-sm text-slate-500 mt-1">{issue.description}</p>
          </div>
          {!isOwnComplaint && !supported && (
            <Button variant="outline" onClick={handleSupport}>
              <Users className="w-4 h-4" /> Support
            </Button>
          )}
          {supported && <Badge className="bg-teal-100 text-teal-700 border-teal-200">Supported</Badge>}
        </div>
      </Card>

      {/* Info Grid */}
      <div className="grid sm:grid-cols-2 gap-4">
        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-3">Complaint Information</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">Category:</span><span className="font-medium text-slate-900">{issue.category?.name}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Department:</span><span className="font-medium text-slate-900">{issue.department?.name || 'Unassigned'}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Ward:</span><span className="font-medium text-slate-900">{issue.ward?.name || 'Unassigned'}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Reported by:</span><span className="font-medium text-slate-900">{isOwnComplaint ? 'You' : 'Anonymous'}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Date:</span><span className="font-medium text-slate-900">{formatDateTime(issue.created_at)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Assigned Officer:</span><span className="font-medium text-slate-900">{issue.assigned_officer?.full_name || 'Unassigned'}</span></div>
          </div>
        </Card>

        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-3">SLA Information</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-500">SLA Status:</span>
              <span className={classNames('font-medium', slaBreached ? 'text-red-600' : 'text-slate-900')}>
                {formatSlaRemaining(issue.sla_deadline)}
              </span>
            </div>
            {issue.ai_confidence && (
              <div className="flex justify-between"><span className="text-slate-500">AI Confidence:</span><span className="font-medium text-teal-600">{issue.ai_confidence}%</span></div>
            )}
            <div className="flex justify-between"><span className="text-slate-500">Supporters:</span><span className="font-medium text-slate-900">{issue.supporter_count}</span></div>
            {issue.resolved_at && <div className="flex justify-between"><span className="text-slate-500">Resolved:</span><span className="font-medium text-slate-900">{formatDateTime(issue.resolved_at)}</span></div>}
            {issue.verified_at && <div className="flex justify-between"><span className="text-slate-500">Verified:</span><span className="font-medium text-slate-900">{formatDateTime(issue.verified_at)}</span></div>}
          </div>
        </Card>
      </div>

      {/* Images */}
      {issue.images && issue.images.length > 0 && (
        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-3">Images</h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {issue.images.map((img) => (
              <div key={img.id} className="relative">
                <img src={img.image_url} alt="Issue" className="w-full h-32 object-cover rounded-lg border border-slate-200" />
                <span className="absolute bottom-1 left-1 px-2 py-0.5 rounded bg-black/60 text-white text-xs">{img.image_type}</span>
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Map */}
      <Card>
        <h3 className="text-sm font-medium text-slate-500 mb-3">Location</h3>
        <IssueMap singleMarker={{ lat: issue.latitude, lng: issue.longitude, label: issue.location_name }} height="300px" />
        <p className="text-sm text-slate-500 mt-2 flex items-center gap-1"><MapPin className="w-4 h-4" /> {issue.location_name} · {issue.latitude.toFixed(4)}, {issue.longitude.toFixed(4)}</p>
      </Card>

      {/* AI Analysis */}
      {issue.ai_analysis && issue.ai_analysis.length > 0 && (
        <Card>
          <div className="flex items-center gap-2 mb-3">
            <Brain className="w-5 h-5 text-teal-600" />
            <h3 className="text-sm font-medium text-slate-900">AI Analysis</h3>
          </div>
          <div className="grid grid-cols-2 gap-3 text-sm mb-3">
            <div><span className="text-slate-500">Detected:</span> <span className="font-medium text-slate-900">{issue.ai_analysis[0].detected_category}</span></div>
            <div><span className="text-slate-500">Confidence:</span> <span className="font-medium text-teal-600">{issue.ai_analysis[0].confidence}%</span></div>
            <div><span className="text-slate-500">Severity:</span> <span className="font-medium text-slate-900">{formatSeverity(issue.ai_analysis[0].estimated_severity)}</span></div>
            <div><span className="text-slate-500">Department:</span> <span className="font-medium text-slate-900">{issue.ai_analysis[0].suggested_department}</span></div>
          </div>
          <p className="text-sm text-slate-600 pt-3 border-t border-slate-100">{issue.ai_analysis[0].ai_description}</p>
        </Card>
      )}

      {/* Timeline */}
      <Card>
        <h3 className="text-sm font-medium text-slate-500 mb-4">Status Timeline</h3>
        <div className="space-y-4">
          {(issue.status_history || []).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).map((entry) => (
            <div key={entry.id} className="flex items-start gap-3">
              <div className={classNames('w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0', statusDotColor(entry.status as never))}>
                <CheckCircle2 className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-slate-900">{formatStatus(entry.status as never)}</p>
                {entry.comment && <p className="text-sm text-slate-500">{entry.comment}</p>}
                <p className="text-xs text-slate-400">{formatDateTime(entry.created_at)}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Citizen Verification */}
      {issue.status === 'citizen_verification' && isOwnComplaint && !verifyResult && (
        <Card className="border-teal-200 bg-teal-50/50">
          <h3 className="text-lg font-semibold text-slate-900 mb-2">Was this issue actually fixed?</h3>
          <p className="text-sm text-slate-600 mb-4">The officer has marked this issue as resolved. Please verify whether the repair was actually done.</p>

          {verifying ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Optional reason</label>
                <textarea
                  value={verifyReason}
                  onChange={(e) => setVerifyReason(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                  placeholder="Add any comments about the repair..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Optional photo</label>
                <label className="block border-2 border-dashed border-slate-300 rounded-lg p-4 text-center cursor-pointer hover:border-teal-400">
                  <input type="file" accept="image/*" capture="environment" onChange={(e) => setVerifyPhoto(e.target.files?.[0] || null)} className="hidden" />
                  <Camera className="w-6 h-6 text-slate-400 mx-auto" />
                  <span className="text-sm text-slate-500">{verifyPhoto ? verifyPhoto.name : 'Upload verification photo'}</span>
                </label>
              </div>
              <div className="flex gap-3">
                <Button variant="success" fullWidth loading={submittingVerify} onClick={() => handleVerify(true)}>
                  <CheckCircle2 className="w-4 h-4" /> Yes, Fixed
                </Button>
                <Button variant="danger" fullWidth loading={submittingVerify} onClick={() => handleVerify(false)}>
                  <XCircle className="w-4 h-4" /> No, Still Exists
                </Button>
              </div>
            </div>
          ) : (
            <div className="flex gap-3">
              <Button variant="success" fullWidth onClick={() => setVerifying(true)}>
                <CheckCircle2 className="w-4 h-4" /> Yes, Fixed
              </Button>
              <Button variant="danger" fullWidth onClick={() => setVerifying(true)}>
                <XCircle className="w-4 h-4" /> No, Still Exists
              </Button>
            </div>
          )}
        </Card>
      )}

      {verifyResult && (
        <Card className="border-emerald-200 bg-emerald-50/50">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-emerald-600" />
            <p className="text-sm font-medium text-slate-900">
              {verifyResult === 'fixed' ? 'Thank you for confirming the repair.' : 'The complaint has been reopened. The officer will address it again.'}
            </p>
          </div>
        </Card>
      )}
    </div>
  );
}
