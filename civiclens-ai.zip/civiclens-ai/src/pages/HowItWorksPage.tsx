import { Link } from 'react-router-dom';
import { Camera, Brain, MapPin, Users, CheckCircle2, ArrowRight, ShieldCheck } from 'lucide-react';

export function HowItWorksPage() {
  return (
    <div className="min-h-screen bg-white">
      <nav className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-teal-600 flex items-center justify-center">
              <span className="text-white font-bold text-sm">CL</span>
            </div>
            <span className="font-bold text-slate-900">CivicLens AI</span>
          </Link>
          <Link to="/login" className="text-sm font-medium text-white bg-teal-600 px-4 py-2 rounded-lg hover:bg-teal-700">
            Sign In
          </Link>
        </div>
      </nav>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-16">
        <h1 className="text-4xl font-bold text-slate-900 text-center mb-4">How It Works</h1>
        <p className="text-slate-500 text-center mb-16 max-w-2xl mx-auto">CivicLens AI makes civic issue reporting simple, transparent, and accountable. Here's the complete journey from problem to solution.</p>

        <div className="space-y-12">
          {[
            { icon: Camera, title: 'Step 1: Capture the Issue', desc: 'Take a photo of the civic problem using your phone camera or upload an existing image. The app supports multiple images for a single complaint.', color: 'bg-teal-50 text-teal-600' },
            { icon: Brain, title: 'Step 2: AI Analysis', desc: 'Our AI system analyzes the image to identify the issue type (pothole, garbage, drainage, etc.), estimate severity, and suggest the appropriate municipal department. You can review and correct the analysis before submitting.', color: 'bg-blue-50 text-blue-600' },
            { icon: MapPin, title: 'Step 3: Location Detection', desc: 'The app automatically detects your location using GPS, identifies the ward and nearby road name, and shows the issue on a map. You can manually adjust the location if needed.', color: 'bg-amber-50 text-amber-600' },
            { icon: Users, title: 'Step 4: Duplicate Detection', desc: 'Before submitting, the system checks for nearby existing complaints. If a similar issue has already been reported, you can support the existing complaint instead of creating a duplicate.', color: 'bg-purple-50 text-purple-600' },
            { icon: CheckCircle2, title: 'Step 5: Track Resolution', desc: 'Once submitted, you receive a unique complaint ID. Track the complaint through its lifecycle: Submitted → AI Analyzed → Assigned → In Progress → Resolved → Verified.', color: 'bg-emerald-50 text-emerald-600' },
            { icon: ShieldCheck, title: 'Step 6: Citizen Verification', desc: 'When an officer marks the issue as resolved, you receive a notification to verify whether the fix is real. This creates accountability and ensures issues are actually resolved.', color: 'bg-rose-50 text-rose-600' },
          ].map((step, i) => (
            <div key={i} className="flex gap-6">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0 ${step.color}`}>
                <step.icon className="w-7 h-7" />
              </div>
              <div className="pt-2">
                <h2 className="text-xl font-semibold text-slate-900 mb-2">{step.title}</h2>
                <p className="text-slate-600 leading-relaxed">{step.desc}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 text-center">
          <Link to="/register" className="inline-flex items-center gap-2 bg-teal-600 text-white px-6 py-3 rounded-xl font-medium hover:bg-teal-700 transition-colors">
            Get Started <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
