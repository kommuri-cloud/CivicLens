import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from '@/lib/auth';
import { I18nProvider } from '@/lib/i18n';
import type { ReactNode } from 'react';

import { LandingPage } from '@/pages/LandingPage';
import { LoginPage } from '@/pages/LoginPage';
import { RegisterPage } from '@/pages/RegisterPage';
import { HowItWorksPage } from '@/pages/HowItWorksPage';

import { CitizenLayout } from '@/layouts/CitizenLayout';
import { OfficerLayout } from '@/layouts/OfficerLayout';
import { AdminLayout } from '@/layouts/AdminLayout';

import { CitizenDashboard } from '@/pages/citizen/CitizenDashboard';
import { ReportIssue } from '@/pages/citizen/ReportIssue';
import { MyComplaints } from '@/pages/citizen/MyComplaints';
import { ComplaintDetail } from '@/pages/citizen/ComplaintDetail';
import { CivicMap } from '@/pages/citizen/CivicMap';
import { NotificationsPage } from '@/pages/citizen/NotificationsPage';
import { ProfilePage } from '@/pages/citizen/ProfilePage';

import { OfficerDashboard } from '@/pages/officer/OfficerDashboard';
import { ComplaintQueue } from '@/pages/officer/ComplaintQueue';
import { OfficerComplaintDetail } from '@/pages/officer/OfficerComplaintDetail';
import { OfficerAnalytics } from '@/pages/officer/OfficerAnalytics';

import { AdminDashboard } from '@/pages/admin/AdminDashboard';
import { UserManagement } from '@/pages/admin/UserManagement';
import { DepartmentManagement } from '@/pages/admin/DepartmentManagement';
import { WardManagement } from '@/pages/admin/WardManagement';
import { CategoryManagement } from '@/pages/admin/CategoryManagement';
import { SlaConfig } from '@/pages/admin/SlaConfig';

function ProtectedRoute({ children, roles }: { children: ReactNode; roles?: string[] }) {
  const { profile, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="animate-spin h-8 w-8 border-4 border-teal-600 border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!profile) {
    return <Navigate to="/login" replace />;
  }

  if (roles && !roles.includes(profile.role)) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/how-it-works" element={<HowItWorksPage />} />

      <Route path="/dashboard" element={<ProtectedRoute roles={['citizen']}><CitizenLayout /></ProtectedRoute>}>
        <Route index element={<CitizenDashboard />} />
        <Route path="report" element={<ReportIssue />} />
        <Route path="complaints" element={<MyComplaints />} />
        <Route path="complaints/:id" element={<ComplaintDetail />} />
        <Route path="map" element={<CivicMap />} />
        <Route path="notifications" element={<NotificationsPage />} />
        <Route path="profile" element={<ProfilePage />} />
      </Route>

      <Route path="/officer" element={<ProtectedRoute roles={['officer']}><OfficerLayout /></ProtectedRoute>}>
        <Route index element={<OfficerDashboard />} />
        <Route path="queue" element={<ComplaintQueue />} />
        <Route path="complaints/:id" element={<OfficerComplaintDetail />} />
        <Route path="analytics" element={<OfficerAnalytics />} />
      </Route>

      <Route path="/admin" element={<ProtectedRoute roles={['admin']}><AdminLayout /></ProtectedRoute>}>
        <Route index element={<AdminDashboard />} />
        <Route path="users" element={<UserManagement />} />
        <Route path="departments" element={<DepartmentManagement />} />
        <Route path="wards" element={<WardManagement />} />
        <Route path="categories" element={<CategoryManagement />} />
        <Route path="sla" element={<SlaConfig />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <I18nProvider>
      <AuthProvider>
        <BrowserRouter>
          <AppRoutes />
        </BrowserRouter>
      </AuthProvider>
    </I18nProvider>
  );
}
