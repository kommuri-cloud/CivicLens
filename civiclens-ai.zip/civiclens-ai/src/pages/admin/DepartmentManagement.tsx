import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, Spinner, PageHeader, EmptyState, Button } from '@/components/ui';
import { Building2, Plus } from 'lucide-react';
import type { Department } from '@/types';

export function DepartmentManagement() {
  const [loading, setLoading] = useState(true);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');

  const fetchDepts = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('departments').select('*').order('name');
    setDepartments((data || []) as Department[]);
    setLoading(false);
  }, []);

  useEffect(() => { fetchDepts(); }, [fetchDepts]);

  const addDept = async () => {
    if (!newName.trim()) return;
    await supabase.from('departments').insert({
      name: newName,
      description: newDesc,
      contact_email: newEmail,
      contact_phone: newPhone,
    });
    setNewName(''); setNewDesc(''); setNewEmail(''); setNewPhone('');
    setShowAdd(false);
    await fetchDepts();
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size="lg" /></div>;

  return (
    <div>
      <PageHeader title="Department Management" subtitle={`${departments.length} departments`}>
        <Button onClick={() => setShowAdd(!showAdd)}><Plus className="w-4 h-4" /> Add Department</Button>
      </PageHeader>

      {showAdd && (
        <Card className="mb-4">
          <h3 className="text-sm font-medium text-slate-900 mb-3">New Department</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            <input placeholder="Name" value={newName} onChange={(e) => setNewName(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
            <input placeholder="Email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
            <input placeholder="Phone" value={newPhone} onChange={(e) => setNewPhone(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
            <input placeholder="Description" value={newDesc} onChange={(e) => setNewDesc(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
          </div>
          <Button size="sm" className="mt-3" onClick={addDept}>Add Department</Button>
        </Card>
      )}

      {departments.length === 0 ? (
        <Card><EmptyState icon={<Building2 className="w-12 h-12" />} title="No departments" /></Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {departments.map((dept) => (
            <Card key={dept.id}>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg bg-teal-50 flex items-center justify-center flex-shrink-0">
                  <Building2 className="w-5 h-5 text-teal-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-slate-900">{dept.name}</p>
                  <p className="text-sm text-slate-500 mt-1">{dept.description}</p>
                  {dept.contact_email && <p className="text-xs text-slate-400 mt-1">{dept.contact_email}</p>}
                  {dept.contact_phone && <p className="text-xs text-slate-400">{dept.contact_phone}</p>}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
