import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, Spinner, PageHeader, EmptyState, Button, Badge } from '@/components/ui';
import { Tags, Plus } from 'lucide-react';
import type { IssueCategory, Department } from '@/types';

export function CategoryManagement() {
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState<IssueCategory[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newDept, setNewDept] = useState('');

  const fetchData = useCallback(async () => {
    setLoading(true);
    const [{ data: cats }, { data: depts }] = await Promise.all([
      supabase.from('issue_categories').select('*').order('name'),
      supabase.from('departments').select('*').order('name'),
    ]);
    setCategories((cats || []) as IssueCategory[]);
    setDepartments((depts || []) as Department[]);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const addCategory = async () => {
    if (!newName.trim()) return;
    await supabase.from('issue_categories').insert({
      name: newName,
      description: newDesc,
      default_department_id: newDept || null,
    });
    setNewName(''); setNewDesc(''); setNewDept('');
    setShowAdd(false);
    await fetchData();
  };

  const toggleActive = async (cat: IssueCategory) => {
    await supabase.from('issue_categories').update({ is_active: !cat.is_active }).eq('id', cat.id);
    await fetchData();
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size="lg" /></div>;

  return (
    <div>
      <PageHeader title="Issue Categories" subtitle={`${categories.length} categories configured`}>
        <Button onClick={() => setShowAdd(!showAdd)}><Plus className="w-4 h-4" /> Add Category</Button>
      </PageHeader>

      {showAdd && (
        <Card className="mb-4">
          <div className="grid sm:grid-cols-2 gap-3">
            <input placeholder="Category name" value={newName} onChange={(e) => setNewName(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
            <input placeholder="Description" value={newDesc} onChange={(e) => setNewDesc(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
            <select value={newDept} onChange={(e) => setNewDept(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm">
              <option value="">Select department...</option>
              {departments.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
          <Button size="sm" className="mt-3" onClick={addCategory}>Add Category</Button>
        </Card>
      )}

      {categories.length === 0 ? (
        <Card><EmptyState icon={<Tags className="w-12 h-12" />} title="No categories" /></Card>
      ) : (
        <div className="space-y-2">
          {categories.map((cat) => {
            const dept = departments.find((d) => d.id === cat.default_department_id);
            return (
              <Card key={cat.id}>
                <div className="flex items-center justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-medium text-slate-900">{cat.name}</p>
                      <Badge className={cat.is_active ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : 'bg-slate-100 text-slate-500 border-slate-200'}>
                        {cat.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-500">{cat.description}</p>
                    {dept && <p className="text-xs text-slate-400 mt-1">Dept: {dept.name}</p>}
                    <p className="text-xs text-slate-400">SLA: {cat.default_sla_high_hours}h / {cat.default_sla_medium_hours}h / {cat.default_sla_low_hours}h</p>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => toggleActive(cat)}>
                    {cat.is_active ? 'Deactivate' : 'Activate'}
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
