import type { IssueStatus, Severity } from '@/types';

export function formatStatus(status: IssueStatus): string {
  const map: Record<IssueStatus, string> = {
    submitted: 'Submitted',
    ai_analyzed: 'AI Analyzed',
    assigned: 'Assigned',
    acknowledged: 'Acknowledged',
    in_progress: 'In Progress',
    resolved: 'Resolved',
    citizen_verification: 'Citizen Verification',
    verified: 'Verified',
    reopened: 'Reopened',
    closed: 'Closed',
  };
  return map[status] || status;
}

export function formatSeverity(severity: Severity): string {
  const map: Record<Severity, string> = {
    high: 'High',
    medium: 'Medium',
    low: 'Low',
  };
  return map[severity] || severity;
}

export function severityColor(severity: Severity): string {
  switch (severity) {
    case 'high':
      return 'bg-red-100 text-red-700 border-red-200';
    case 'medium':
      return 'bg-amber-100 text-amber-700 border-amber-200';
    case 'low':
      return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    default:
      return 'bg-gray-100 text-gray-700 border-gray-200';
  }
}

export function severityDotColor(severity: Severity): string {
  switch (severity) {
    case 'high':
      return 'bg-red-500';
    case 'medium':
      return 'bg-amber-500';
    case 'low':
      return 'bg-emerald-500';
    default:
      return 'bg-gray-500';
  }
}

export function statusColor(status: IssueStatus): string {
  switch (status) {
    case 'submitted':
      return 'bg-gray-100 text-gray-700 border-gray-200';
    case 'ai_analyzed':
      return 'bg-blue-100 text-blue-700 border-blue-200';
    case 'assigned':
      return 'bg-indigo-100 text-indigo-700 border-indigo-200';
    case 'acknowledged':
      return 'bg-cyan-100 text-cyan-700 border-cyan-200';
    case 'in_progress':
      return 'bg-orange-100 text-orange-700 border-orange-200';
    case 'resolved':
      return 'bg-green-100 text-green-700 border-green-200';
    case 'citizen_verification':
      return 'bg-purple-100 text-purple-700 border-purple-200';
    case 'verified':
      return 'bg-emerald-100 text-emerald-700 border-emerald-200';
    case 'reopened':
      return 'bg-red-100 text-red-700 border-red-200';
    case 'closed':
      return 'bg-slate-100 text-slate-600 border-slate-200';
    default:
      return 'bg-gray-100 text-gray-700 border-gray-200';
  }
}

export function statusDotColor(status: IssueStatus): string {
  switch (status) {
    case 'submitted':
      return 'bg-gray-400';
    case 'ai_analyzed':
      return 'bg-blue-500';
    case 'assigned':
      return 'bg-indigo-500';
    case 'acknowledged':
      return 'bg-cyan-500';
    case 'in_progress':
      return 'bg-orange-500';
    case 'resolved':
      return 'bg-green-500';
    case 'citizen_verification':
      return 'bg-purple-500';
    case 'verified':
      return 'bg-emerald-500';
    case 'reopened':
      return 'bg-red-500';
    case 'closed':
      return 'bg-slate-400';
    default:
      return 'bg-gray-400';
  }
}

export function formatTimeAgo(dateString: string): string {
  const date = new Date(dateString);
  const now = new Date();
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  if (seconds < 60) return 'just now';
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  const months = Math.floor(days / 30);
  if (months < 12) return `${months}mo ago`;
  return `${Math.floor(months / 12)}y ago`;
}

export function formatDateTime(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function formatSlaRemaining(slaDeadline: string | null): string {
  if (!slaDeadline) return 'No SLA';
  const deadline = new Date(slaDeadline);
  const now = new Date();
  const diff = deadline.getTime() - now.getTime();

  if (diff <= 0) return 'SLA BREACHED';

  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

  if (hours > 24) {
    const days = Math.floor(hours / 24);
    const remainingHours = hours % 24;
    return `${days}d ${remainingHours}h remaining`;
  }

  return `${hours}h ${minutes}m remaining`;
}

export function isSlaBreached(slaDeadline: string | null): boolean {
  if (!slaDeadline) return false;
  return new Date(slaDeadline).getTime() < Date.now();
}

export function haversineDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export function classNames(...classes: (string | false | undefined | null)[]): string {
  return classes.filter(Boolean).join(' ');
}
