import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, Spinner, PageHeader, EmptyState, Button } from '@/components/ui';
import { MapPin, Plus } from 'lucide-react';
import type { Ward } from '@/types';

export function WardManagement() {
  const [loading, setLoading] = useState(true);
  const [wards, setWards] = useState<Ward[]>([]);
  const [showAdd, setShowAdd] = useState(false);
  const [newName, setNewName] = useState('');
  const [newNumber, setNewNumber] = useState('');
  const [newArea, setNewArea] = useState('');
  const [newPop, setNewPop] = useState('');

  const fetchWards = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('wards').select('*').order('number');
    setWards((data || []) as Ward[]);
    setLoading(false);
  }, []);

  useEffect(() => { fetchWards(); }, [fetchWards]);

  const addWard = async () => {
    if (!newName.trim() || !newNumber.trim()) return;
    await supabase.from('wards').insert({
      name: newName,
      number: parseInt(newNumber),
      area: newArea,
      population: parseInt(newPop) || 0,
    });
    setNewName(''); setNewNumber(''); setNewArea(''); setNewPop('');
    setShowAdd(false);
    await fetchWards();
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size="lg" /></div>;

  return (
    <div>
      <PageHeader title="Ward Management" subtitle={`${wards.length} wards`}>
        <Button onClick={() => setShowAdd(!showAdd)}><Plus className="w-4 h-4" /> Add Ward</Button>
      </PageHeader>

      {showAdd && (
        <Card className="mb-4">
          <div className="grid sm:grid-cols-2 gap-3">
            <input placeholder="Name" value={newName} onChange={(e) => setNewName(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
            <input placeholder="Number" type="number" value={newNumber} onChange={(e) => setNewNumber(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
            <input placeholder="Area" value={newArea} onChange={(e) => setNewArea(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
            <input placeholder="Population" type="number" value={newPop} onChange={(e) => setNewPop(e.target.value)} className="px-3 py-2 border border-slate-300 rounded-lg text-sm" />
          </div>
          <Button size="sm" className="mt-3" onClick={addWard}>Add Ward</Button>
        </Card>
      )}

      {wards.length === 0 ? (
        <Card><EmptyState icon={<MapPin className="w-12 h-12" />} title="No wards" /></Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {wards.map((ward) => (
            <Card key={ward.id}>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-teal-50 flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-teal-600">{ward.number}</span>
                </div>
                <div>
                  <p className="font-medium text-slate-900">{ward.name}</p>
                  <p className="text-xs text-slate-500">{ward.area} · Pop: {ward.population.toLocaleString()}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
