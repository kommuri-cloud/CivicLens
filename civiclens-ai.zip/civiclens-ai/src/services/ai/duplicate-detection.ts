import { supabase } from '@/lib/supabase';
import { haversineDistance } from '@/lib/utils';
import type { Issue, IssueWithRelations, DuplicateDetectionResult } from '@/types';

export async function detectDuplicates(
  latitude: number,
  longitude: number,
  categoryId: string,
  radiusMeters: number = 500
): Promise<DuplicateDetectionResult[]> {
  const { data, error } = await supabase
    .from('issues')
    .select(`
      *,
      category:issue_categories(*),
      department:departments(*),
      ward:wards(*),
      assigned_officer:profiles!issues_assigned_officer_id_fkey(*),
      citizen:profiles!issues_citizen_id_fkey(*)
    `)
    .neq('status', 'closed')
    .neq('status', 'verified');

  if (error) {
    console.error('Duplicate detection query failed', error);
    return [];
  }

  if (!data || data.length === 0) return [];

  const results: DuplicateDetectionResult[] = [];

  for (const issue of data as unknown as IssueWithRelations[]) {
    const distance = haversineDistance(latitude, longitude, issue.latitude, issue.longitude);

    if (distance > radiusMeters) continue;

    let matchScore = 0;

    if (issue.category_id === categoryId) matchScore += 50;
    if (distance < 100) matchScore += 30;
    else if (distance < 250) matchScore += 20;
    else if (distance < 500) matchScore += 10;

    const ageDays = (Date.now() - new Date(issue.created_at).getTime()) / (1000 * 60 * 60 * 24);
    if (ageDays < 7) matchScore += 20;
    else if (ageDays < 30) matchScore += 10;

    if (matchScore >= 40) {
      results.push({ issue, distance_meters: Math.round(distance), match_score: matchScore });
    }
  }

  results.sort((a, b) => b.match_score - a.match_score || a.distance_meters - b.distance_meters);

  return results.slice(0, 5);
}

export async function supportIssue(issueId: string): Promise<{ success: boolean; error?: string }> {
  const { error } = await supabase.rpc('support_issue', { p_issue_id: issueId });

  if (error) {
    if (error.code === '23505') {
      return { success: false, error: 'You have already supported this issue.' };
    }
    return { success: false, error: 'Could not support this issue. Please try again.' };
  }

  return { success: true };
}

export async function getNearbyIssues(
  latitude: number,
  longitude: number,
  radiusMeters: number = 2000
): Promise<Issue[]> {
  const { data, error } = await supabase
    .from('issues')
    .select('*')
    .neq('status', 'closed');

  if (error || !data) return [];

  return (data as Issue[]).filter((issue) => {
    const distance = haversineDistance(latitude, longitude, issue.latitude, issue.longitude);
    return distance <= radiusMeters;
  });
}
