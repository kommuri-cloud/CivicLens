import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { Card, Badge, Spinner, EmptyState, PageHeader } from '@/components/ui';
import { Button } from '@/components/ui/Button';
import { formatStatus, formatSeverity, severityColor, statusColor, formatDate, formatSlaRemaining, classNames } from '@/lib/utils';
import { Search, ChevronRight, Filter, FileText } from 'lucide-react';
import type { Issue, Severity, IssueStatus } from '@/types';

const PAGE_SIZE = 10;

export function ComplaintQueue() {
  const { profile } = useAuth();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [search, setSearch] = useState('');
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [page, setPage] = useState(0);

  const fetchIssues = useCallback(async () => {
    if (!profile?.department_id) return;
    setLoading(true);

    let query = supabase
      .from('issues')
      .select('*')
      .eq('department_id', profile.department_id)
      .order('created_at', { ascending: false });

    const { data } = await query;
    let issueList = (data || []) as Issue[];

    // Client-side filters
    if (search) {
      const s = search.toLowerCase();
      issueList = issueList.filter((i) =>
        i.complaint_id.toLowerCase().includes(s) ||
        i.title.toLowerCase().includes(s) ||
        i.location_name.toLowerCase().includes(s)
      );
    }
    if (severityFilter !== 'all') issueList = issueList.filter((i) => i.severity === severityFilter);
    if (statusFilter !== 'all') issueList = issueList.filter((i) => i.status === statusFilter);

    // Sort: high severity first, then SLA breached
    issueList.sort((a, b) => {
      if (a.severity === 'high' && b.severity !== 'high') return -1;
      if (a.severity !== 'high' && b.severity === 'high') return 1;
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });

    setIssues(issueList);
    setLoading(false);
  }, [profile, search, severityFilter, statusFilter]);

  useEffect(() => {
    fetchIssues();
  }, [fetchIssues]);

  const paginatedIssues = issues.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const totalPages = Math.ceil(issues.length / PAGE_SIZE);

  return (
    <div>
      <PageHeader title="Complaint Queue" subtitle={`${issues.length} complaints in your department`} />

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search by ID, title, or location..."
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(0); }}
            className="w-full pl-10 pr-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
          />
        </div>
        <select
          value={severityFilter}
          onChange={(e) => { setSeverityFilter(e.target.value); setPage(0); }}
          className="px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
        >
          <option value="all">All Severities</option>
          <option value="high">High</option>
          <option value="medium">Medium</option>
          <option value="low">Low</option>
        </select>
        <select
          value={statusFilter}
          onChange={(e) => { setStatusFilter(e.target.value); setPage(0); }}
          className="px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
        >
          <option value="all">All Statuses</option>
          <option value="submitted">Submitted</option>
          <option value="ai_analyzed">AI Analyzed</option>
          <option value="assigned">Assigned</option>
          <option value="acknowledged">Acknowledged</option>
          <option value="in_progress">In Progress</option>
          <option value="resolved">Resolved</option>
          <option value="citizen_verification">Citizen Verification</option>
          <option value="verified">Verified</option>
          <option value="reopened">Reopened</option>
          <option value="closed">Closed</option>
        </select>
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><Spinner size="lg" /></div>
      ) : issues.length === 0 ? (
        <Card><EmptyState icon={<FileText className="w-12 h-12" />} title="No complaints found" description="No complaints match your current filters." /></Card>
      ) : (
        <>
          {/* Table (desktop) */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-slate-200 text-left text-xs text-slate-500 uppercase">
                  <th className="py-3 px-3 font-medium">Complaint ID</th>
                  <th className="py-3 px-3 font-medium">Issue Type</th>
                  <th className="py-3 px-3 font-medium">Severity</th>
                  <th className="py-3 px-3 font-medium">Location</th>
                  <th className="py-3 px-3 font-medium">Date</th>
                  <th className="py-3 px-3 font-medium">SLA</th>
                  <th className="py-3 px-3 font-medium">Status</th>
                  <th className="py-3 px-3 font-medium"></th>
                </tr>
              </thead>
              <tbody>
                {paginatedIssues.map((issue) => {
                  const breached = issue.sla_breached || (issue.sla_deadline && new Date(issue.sla_deadline) < new Date() && !['verified', 'closed'].includes(issue.status));
                  return (
                    <tr key={issue.id} className="border-b border-slate-100 hover:bg-slate-50 cursor-pointer" onClick={() => navigate(`/officer/complaints/${issue.id}`)}>
                      <td className="py-3 px-3 text-sm font-mono text-slate-600">{issue.complaint_id}</td>
                      <td className="py-3 px-3 text-sm font-medium text-slate-900 max-w-[200px] truncate">{issue.title}</td>
                      <td className="py-3 px-3"><Badge className={severityColor(issue.severity)}>{formatSeverity(issue.severity)}</Badge></td>
                      <td className="py-3 px-3 text-sm text-slate-600 max-w-[150px] truncate">{issue.location_name}</td>
                      <td className="py-3 px-3 text-sm text-slate-600">{formatDate(issue.created_at)}</td>
                      <td className="py-3 px-3">
                        {breached ? <Badge className="bg-red-100 text-red-700 border-red-200">BREACHED</Badge> : <span className="text-xs text-slate-500">{formatSlaRemaining(issue.sla_deadline)}</span>}
                      </td>
                      <td className="py-3 px-3"><Badge className={statusColor(issue.status)}>{formatStatus(issue.status)}</Badge></td>
                      <td className="py-3 px-3"><ChevronRight className="w-4 h-4 text-slate-400" /></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Cards (mobile) */}
          <div className="md:hidden space-y-3">
            {paginatedIssues.map((issue) => {
              const breached = issue.sla_breached || (issue.sla_deadline && new Date(issue.sla_deadline) < new Date() && !['verified', 'closed'].includes(issue.status));
              return (
                <Card key={issue.id} className="cursor-pointer" >
                  <div onClick={() => navigate(`/officer/complaints/${issue.id}`)} className="flex items-center gap-3">
                    <div className={classNames('w-2 h-12 rounded-full flex-shrink-0', issue.severity === 'high' ? 'bg-red-500' : issue.severity === 'medium' ? 'bg-amber-500' : 'bg-emerald-500')} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="text-xs font-mono text-slate-500">{issue.complaint_id}</span>
                        <Badge className={severityColor(issue.severity)}>{formatSeverity(issue.severity)}</Badge>
                        <Badge className={statusColor(issue.status)}>{formatStatus(issue.status)}</Badge>
                      </div>
                      <p className="text-sm font-medium text-slate-900 truncate">{issue.title}</p>
                      <p className="text-xs text-slate-500">{issue.location_name} · {formatDate(issue.created_at)}</p>
                      {breached && <Badge className="bg-red-100 text-red-700 border-red-200 mt-1">SLA BREACHED</Badge>}
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-400" />
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <Button variant="outline" size="sm" disabled={page === 0} onClick={() => setPage(page - 1)}>Previous</Button>
              <span className="text-sm text-slate-500">Page {page + 1} of {totalPages}</span>
              <Button variant="outline" size="sm" disabled={page >= totalPages - 1} onClick={() => setPage(page + 1)}>Next</Button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
