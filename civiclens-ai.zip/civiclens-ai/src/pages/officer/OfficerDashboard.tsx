import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { Card, StatCard, PageHeader, Spinner, Badge, EmptyState } from '@/components/ui';
import { IssueMap } from '@/components/IssueMap';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend,
} from 'recharts';
import { formatStatus, formatSeverity, severityColor, statusColor, formatTimeAgo, formatSlaRemaining, classNames } from '@/lib/utils';
import { FileText, Clock, CheckCircle2, AlertTriangle, AlertCircle, ChevronRight, TrendingUp } from 'lucide-react';
import type { Issue } from '@/types';

const SEVERITY_COLORS: Record<string, string> = { high: '#ef4444', medium: '#f59e0b', low: '#10b981' };

export function OfficerDashboard() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [stats, setStats] = useState({ total: 0, pending: 0, inProgress: 0, resolved: 0, slaBreached: 0, highSeverity: 0 });

  const fetchData = useCallback(async () => {
    if (!profile?.department_id) return;

    const { data } = await supabase
      .from('issues')
      .select('*')
      .eq('department_id', profile.department_id)
      .order('created_at', { ascending: false });

    const issueList = (data || []) as Issue[];
    setIssues(issueList);

    setStats({
      total: issueList.length,
      pending: issueList.filter((i) => ['submitted', 'ai_analyzed', 'assigned', 'acknowledged'].includes(i.status)).length,
      inProgress: issueList.filter((i) => i.status === 'in_progress').length,
      resolved: issueList.filter((i) => ['resolved', 'citizen_verification', 'verified', 'closed'].includes(i.status)).length,
      slaBreached: issueList.filter((i) => i.sla_breached || (i.sla_deadline && new Date(i.sla_deadline) < new Date() && !['verified', 'closed'].includes(i.status))).length,
      highSeverity: issueList.filter((i) => i.severity === 'high' && !['verified', 'closed'].includes(i.status)).length,
    });

    setLoading(false);
  }, [profile]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  if (loading) {
    return <div className="flex justify-center py-20"><Spinner size="lg" /></div>;
  }

  // Sort: high severity first, then SLA breached, then by date
  const sortedIssues = [...issues].sort((a, b) => {
    if (a.severity === 'high' && b.severity !== 'high') return -1;
    if (a.severity !== 'high' && b.severity === 'high') return 1;
    const aBreached = a.sla_breached || (a.sla_deadline && new Date(a.sla_deadline) < new Date()) ? 1 : 0;
    const bBreached = b.sla_breached || (b.sla_deadline && new Date(b.sla_deadline) < new Date()) ? 1 : 0;
    if (aBreached !== bBreached) return bBreached - aBreached;
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });

  // Chart data
  const categoryData = issues.reduce((acc, issue) => {
    const cat = issue.title.split(' ').slice(0, 2).join(' ');
    acc[cat] = (acc[cat] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  const chartData = Object.entries(categoryData).map(([name, value]) => ({ name, value }));

  const severityData = [
    { name: 'High', value: issues.filter((i) => i.severity === 'high').length, color: SEVERITY_COLORS.high },
    { name: 'Medium', value: issues.filter((i) => i.severity === 'medium').length, color: SEVERITY_COLORS.medium },
    { name: 'Low', value: issues.filter((i) => i.severity === 'low').length, color: SEVERITY_COLORS.low },
  ].filter((d) => d.value > 0);

  return (
    <div className="space-y-6">
      <PageHeader title="Officer Dashboard" subtitle={`${profile?.full_name} · ${issues.length} issues in your department`} />

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard label="Total Issues" value={stats.total} icon={<FileText className="w-6 h-6" />} color="bg-teal-50 text-teal-600" />
        <StatCard label="Pending" value={stats.pending} icon={<Clock className="w-6 h-6" />} color="bg-amber-50 text-amber-600" />
        <StatCard label="In Progress" value={stats.inProgress} icon={<Clock className="w-6 h-6" />} color="bg-orange-50 text-orange-600" />
        <StatCard label="Resolved" value={stats.resolved} icon={<CheckCircle2 className="w-6 h-6" />} color="bg-emerald-50 text-emerald-600" />
        <StatCard label="SLA Breached" value={stats.slaBreached} icon={<AlertTriangle className="w-6 h-6" />} color="bg-red-50 text-red-600" />
        <StatCard label="High Severity" value={stats.highSeverity} icon={<AlertCircle className="w-6 h-6" />} color="bg-rose-50 text-rose-600" />
      </div>

      {/* Charts */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-4">Issues by Category</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} angle={-15} textAnchor="end" height={60} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="value" fill="#0d9488" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-4">Issues by Severity</h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie data={severityData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label>
                {severityData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Issue Map */}
      <Card>
        <h3 className="text-sm font-medium text-slate-500 mb-3">Issue Map</h3>
        <IssueMap issues={sortedIssues.filter((i) => !['closed', 'verified'].includes(i.status))} height="350px" showHeatCircles />
      </Card>

      {/* Priority Issues */}
      <div>
        <h3 className="text-lg font-semibold text-slate-900 mb-3 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-teal-600" /> Priority Issues
        </h3>
        {sortedIssues.length === 0 ? (
          <Card><EmptyState icon={<FileText className="w-12 h-12" />} title="No issues assigned" description="No issues have been assigned to your department yet." /></Card>
        ) : (
          <div className="space-y-3">
            {sortedIssues.slice(0, 10).map((issue) => {
              const breached = issue.sla_breached || (issue.sla_deadline && new Date(issue.sla_deadline) < new Date() && !['verified', 'closed'].includes(issue.status));
              return (
                <Card key={issue.id} className="hover:shadow-md transition-shadow cursor-pointer">
                  <div onClick={() => navigate(`/officer/complaints/${issue.id}`)} className="flex items-center gap-4">
                    <div className={classNames('w-2 h-12 rounded-full flex-shrink-0', issue.severity === 'high' ? 'bg-red-500' : issue.severity === 'medium' ? 'bg-amber-500' : 'bg-emerald-500')} />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="text-xs font-mono text-slate-500">{issue.complaint_id}</span>
                        <Badge className={severityColor(issue.severity)}>{formatSeverity(issue.severity)}</Badge>
                        <Badge className={statusColor(issue.status)}>{formatStatus(issue.status)}</Badge>
                        {breached && <Badge className="bg-red-100 text-red-700 border-red-200">SLA BREACHED</Badge>}
                      </div>
                      <p className="font-medium text-slate-900 truncate">{issue.title}</p>
                      <p className="text-sm text-slate-500 truncate">{issue.location_name} · {formatTimeAgo(issue.created_at)}</p>
                      {!breached && issue.sla_deadline && !['verified', 'closed'].includes(issue.status) && (
                        <p className="text-xs text-slate-400 mt-1">{formatSlaRemaining(issue.sla_deadline)}</p>
                      )}
                    </div>
                    <ChevronRight className="w-5 h-5 text-slate-400 flex-shrink-0" />
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
