import { useEffect, useState, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { Card, Badge, Spinner, EmptyState, PageHeader } from '@/components/ui';
import { formatTimeAgo, classNames } from '@/lib/utils';
import { Bell, CheckCircle2 } from 'lucide-react';
import type { Notification } from '@/types';

export function NotificationsPage() {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const fetchNotifications = useCallback(async () => {
    if (!profile) return;
    setLoading(true);
    const { data } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', profile.id)
      .order('created_at', { ascending: false });
    setNotifications((data || []) as Notification[]);
    setLoading(false);
  }, [profile]);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  const markAsRead = async (id: string) => {
    await supabase.from('notifications').update({ is_read: true }).eq('id', id);
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, is_read: true } : n)));
  };

  const markAllAsRead = async () => {
    if (!profile) return;
    await supabase.from('notifications').update({ is_read: true }).eq('user_id', profile.id).eq('is_read', false);
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
  };

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  return (
    <div>
      <PageHeader title="Notifications" subtitle={`${unreadCount} unread notification${unreadCount !== 1 ? 's' : ''}`}>
        {unreadCount > 0 && (
          <button onClick={markAllAsRead} className="text-sm font-medium text-teal-600 hover:text-teal-700">
            Mark all as read
          </button>
        )}
      </PageHeader>

      {loading ? (
        <div className="flex justify-center py-20"><Spinner size="lg" /></div>
      ) : notifications.length === 0 ? (
        <Card>
          <EmptyState icon={<Bell className="w-12 h-12" />} title="No notifications" description="You'll see updates about your complaints here." />
        </Card>
      ) : (
        <div className="space-y-2">
          {notifications.map((notif) => (
            <Card
              key={notif.id}
              className={classNames(
                'cursor-pointer hover:shadow-md transition-shadow',
                !notif.is_read && 'border-teal-200 bg-teal-50/30'
              )}
            >
              <div onClick={() => !notif.is_read && markAsRead(notif.id)}>
                <div className="flex items-start gap-3">
                  <div className={classNames(
                    'w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0',
                    notif.is_read ? 'bg-slate-100' : 'bg-teal-100'
                  )}>
                    {notif.is_read ? <Bell className="w-5 h-5 text-slate-400" /> : <Bell className="w-5 h-5 text-teal-600" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className={classNames('text-sm', notif.is_read ? 'font-medium text-slate-700' : 'font-semibold text-slate-900')}>{notif.title}</p>
                      {!notif.is_read && <span className="w-2 h-2 rounded-full bg-teal-500 flex-shrink-0" />}
                    </div>
                    <p className="text-sm text-slate-500 mt-0.5">{notif.message}</p>
                    <p className="text-xs text-slate-400 mt-1">{formatTimeAgo(notif.created_at)}</p>
                  </div>
                  {notif.issue_id && (
                    <Link to={`/dashboard/complaints/${notif.issue_id}`} className="text-xs text-teal-600 hover:text-teal-700 font-medium">
                      View
                    </Link>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
