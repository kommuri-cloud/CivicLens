export type UserRole = 'citizen' | 'officer' | 'admin';
export type Severity = 'high' | 'medium' | 'low';
export type IssueStatus =
  | 'submitted'
  | 'ai_analyzed'
  | 'assigned'
  | 'acknowledged'
  | 'in_progress'
  | 'resolved'
  | 'citizen_verification'
  | 'verified'
  | 'reopened'
  | 'closed';

export interface Profile {
  id: string;
  role: UserRole;
  full_name: string;
  phone: string;
  ward_id: string | null;
  department_id: string | null;
  is_active: boolean;
  created_at: string;
}

export interface Department {
  id: string;
  name: string;
  description: string;
  contact_email: string;
  contact_phone: string;
  created_at: string;
}

export interface Ward {
  id: string;
  name: string;
  number: number;
  area: string;
  population: number;
  created_at: string;
}

export interface IssueCategory {
  id: string;
  name: string;
  description: string;
  icon: string;
  default_department_id: string | null;
  default_sla_high_hours: number;
  default_sla_medium_hours: number;
  default_sla_low_hours: number;
  is_active: boolean;
  created_at: string;
}

export interface Issue {
  id: string;
  complaint_id: string;
  citizen_id: string;
  category_id: string;
  department_id: string | null;
  assigned_officer_id: string | null;
  ward_id: string | null;
  title: string;
  description: string;
  severity: Severity;
  status: IssueStatus;
  latitude: number;
  longitude: number;
  location_name: string;
  road_name: string;
  municipality: string;
  supporter_count: number;
  sla_deadline: string | null;
  sla_breached: boolean;
  ai_confidence: number | null;
  ai_analyzed_at: string | null;
  resolved_at: string | null;
  verified_at: string | null;
  closed_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface IssueImage {
  id: string;
  issue_id: string;
  image_url: string;
  image_type: 'citizen' | 'repair' | 'verification';
  uploaded_by: string | null;
  created_at: string;
}

export interface IssueAiAnalysis {
  id: string;
  issue_id: string;
  detected_category: string;
  confidence: number;
  estimated_severity: Severity;
  suggested_department: string;
  ai_description: string;
  analysis_model: string;
  created_at: string;
}

export interface IssueStatusHistory {
  id: string;
  issue_id: string;
  status: IssueStatus;
  previous_status: string | null;
  changed_by: string | null;
  comment: string;
  created_at: string;
}

export interface IssueSupporter {
  id: string;
  issue_id: string;
  citizen_id: string;
  created_at: string;
}

export interface IssueVerification {
  id: string;
  issue_id: string;
  citizen_id: string;
  is_fixed: boolean;
  reason: string;
  verification_image_url: string | null;
  ai_verification_confidence: number | null;
  ai_verification_status: string | null;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  issue_id: string | null;
  type: string;
  title: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

export interface AuditLog {
  id: string;
  actor_id: string | null;
  action: string;
  target_type: string;
  target_id: string | null;
  details: Record<string, unknown>;
  created_at: string;
}

export interface IssueWithRelations extends Issue {
  category?: IssueCategory;
  department?: Department;
  ward?: Ward;
  assigned_officer?: Profile;
  citizen?: Profile;
  images?: IssueImage[];
  ai_analysis?: IssueAiAnalysis[];
  status_history?: IssueStatusHistory[];
  supporters?: IssueSupporter[];
  verifications?: IssueVerification[];
}

export interface AiAnalysisResult {
  detected_category: string;
  confidence: number;
  estimated_severity: Severity;
  suggested_department: string;
  ai_description: string;
}

export interface DuplicateDetectionResult {
  issue: IssueWithRelations;
  distance_meters: number;
  match_score: number;
}

export interface RepairVerificationResult {
  issue_status: string;
  visual_similarity: number;
  detected_change: string;
  verification_confidence: number;
}
