import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { Card, Badge, Spinner, EmptyState, PageHeader } from '@/components/ui';
import { Button } from '@/components/ui/Button';
import { formatStatus, formatSeverity, severityColor, statusColor, formatTimeAgo, classNames } from '@/lib/utils';
import { FileText, ChevronRight, Plus } from 'lucide-react';
import type { Issue, IssueStatus } from '@/types';

const STATUS_FILTERS: { label: string; value: string | null }[] = [
  { label: 'All', value: null },
  { label: 'Pending', value: 'pending' },
  { label: 'In Progress', value: 'in_progress' },
  { label: 'Resolved', value: 'resolved' },
  { label: 'Reopened', value: 'reopened' },
];

export function MyComplaints() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [filter, setFilter] = useState<string | null>(null);

  const fetchIssues = useCallback(async () => {
    if (!profile) return;
    setLoading(true);

    let query = supabase.from('issues').select('*').eq('citizen_id', profile.id).order('created_at', { ascending: false });

    if (filter === 'pending') {
      query = query.in('status', ['submitted', 'ai_analyzed', 'assigned', 'acknowledged']);
    } else if (filter === 'in_progress') {
      query = query.eq('status', 'in_progress');
    } else if (filter === 'resolved') {
      query = query.in('status', ['resolved', 'citizen_verification', 'verified', 'closed']);
    } else if (filter === 'reopened') {
      query = query.eq('status', 'reopened');
    }

    const { data } = await query;
    setIssues((data || []) as Issue[]);
    setLoading(false);
  }, [profile, filter]);

  useEffect(() => {
    fetchIssues();
  }, [fetchIssues]);

  return (
    <div>
      <PageHeader title="My Complaints" subtitle="Track all your reported civic issues">
        <Button onClick={() => navigate('/dashboard/report')}>
          <Plus className="w-4 h-4" /> Report Issue
        </Button>
      </PageHeader>

      {/* Filter tabs */}
      <div className="flex gap-2 mb-4 overflow-x-auto pb-1">
        {STATUS_FILTERS.map((f) => (
          <button
            key={f.label}
            onClick={() => setFilter(f.value)}
            className={classNames(
              'px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors',
              filter === f.value ? 'bg-teal-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-20"><Spinner size="lg" /></div>
      ) : issues.length === 0 ? (
        <Card>
          <EmptyState
            icon={<FileText className="w-12 h-12" />}
            title="No complaints found"
            description="You haven't reported any issues matching this filter yet."
          >
            <Button onClick={() => navigate('/dashboard/report')}>
              <Plus className="w-4 h-4" /> Report an Issue
            </Button>
          </EmptyState>
        </Card>
      ) : (
        <div className="space-y-3">
          {issues.map((issue) => (
            <Card key={issue.id} className="hover:shadow-md transition-shadow cursor-pointer">
              <div onClick={() => navigate(`/dashboard/complaints/${issue.id}`)} className="flex items-center gap-4">
                <div className={classNames('w-2 h-12 rounded-full flex-shrink-0', issue.severity === 'high' ? 'bg-red-500' : issue.severity === 'medium' ? 'bg-amber-500' : 'bg-emerald-500')} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1 flex-wrap">
                    <span className="text-xs font-mono text-slate-500">{issue.complaint_id}</span>
                    <Badge className={severityColor(issue.severity)}>{formatSeverity(issue.severity)}</Badge>
                    <Badge className={statusColor(issue.status)}>{formatStatus(issue.status)}</Badge>
                  </div>
                  <p className="font-medium text-slate-900 truncate">{issue.title}</p>
                  <p className="text-sm text-slate-500 truncate">{issue.location_name} · {formatTimeAgo(issue.created_at)}</p>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400 flex-shrink-0" />
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
