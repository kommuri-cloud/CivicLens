/*
# CivicLens AI - Create Demo Auth Users

## Overview
Creates demo auth.users entries so that demo profiles can be linked.
All demo accounts use the password: Demo1234!

## Demo Accounts
- citizen@demo.com (Citizen - Ravi Kumar)
- officer@demo.com (Officer - Suresh Reddy, Roads Department)
- admin@demo.com (Admin - Municipal Commissioner)
- lakshmi@demo.com (Citizen - Lakshmi Devi)
- pradeep@demo.com (Citizen - Pradeep Naidu)
- officer.sanitation@demo.com (Officer - Sanitation)
- officer.drainage@demo.com (Officer - Drainage)
- officer.streetlights@demo.com (Officer - Streetlights)
- anjali@demo.com (Citizen - Anjali Rao)
- venkat@demo.com (Citizen - Venkat Reddy)
*/

-- Insert demo users into auth.users
-- Password: Demo1234! (bcrypt hashed)
INSERT INTO auth.users (id, instance_id, aud, role, email, encrypted_password, email_confirmed_at, created_at, updated_at, raw_user_meta_data, raw_app_meta_data)
VALUES
  ('55555555-0000-0000-0000-000000000001', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'citizen@demo.com', crypt('Demo1234!', gen_salt('bf')), now(), now(), now(), '{"full_name":"Ravi Kumar"}'::jsonb, '{"provider":"email","providers":["email"]}'::jsonb),
  ('55555555-0000-0000-0000-000000000002', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'officer@demo.com', crypt('Demo1234!', gen_salt('bf')), now(), now(), now(), '{"full_name":"Suresh Reddy"}'::jsonb, '{"provider":"email","providers":["email"]}'::jsonb),
  ('55555555-0000-0000-0000-000000000003', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'admin@demo.com', crypt('Demo1234!', gen_salt('bf')), now(), now(), now(), '{"full_name":"Municipal Commissioner"}'::jsonb, '{"provider":"email","providers":["email"]}'::jsonb),
  ('55555555-0000-0000-0000-000000000004', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'lakshmi@demo.com', crypt('Demo1234!', gen_salt('bf')), now(), now(), now(), '{"full_name":"Lakshmi Devi"}'::jsonb, '{"provider":"email","providers":["email"]}'::jsonb),
  ('55555555-0000-0000-0000-000000000005', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'pradeep@demo.com', crypt('Demo1234!', gen_salt('bf')), now(), now(), now(), '{"full_name":"Pradeep Naidu"}'::jsonb, '{"provider":"email","providers":["email"]}'::jsonb),
  ('55555555-0000-0000-0000-000000000006', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'officer.sanitation@demo.com', crypt('Demo1234!', gen_salt('bf')), now(), now(), now(), '{"full_name":"Officer Sharma"}'::jsonb, '{"provider":"email","providers":["email"]}'::jsonb),
  ('55555555-0000-0000-0000-000000000007', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'officer.drainage@demo.com', crypt('Demo1234!', gen_salt('bf')), now(), now(), now(), '{"full_name":"Officer Rao"}'::jsonb, '{"provider":"email","providers":["email"]}'::jsonb),
  ('55555555-0000-0000-0000-000000000008', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'officer.streetlights@demo.com', crypt('Demo1234!', gen_salt('bf')), now(), now(), now(), '{"full_name":"Officer Krishna"}'::jsonb, '{"provider":"email","providers":["email"]}'::jsonb),
  ('55555555-0000-0000-0000-000000000009', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'anjali@demo.com', crypt('Demo1234!', gen_salt('bf')), now(), now(), now(), '{"full_name":"Anjali Rao"}'::jsonb, '{"provider":"email","providers":["email"]}'::jsonb),
  ('55555555-0000-0000-0000-000000000010', '00000000-0000-0000-0000-000000000000', 'authenticated', 'authenticated', 'venkat@demo.com', crypt('Demo1234!', gen_salt('bf')), now(), now(), now(), '{"full_name":"Venkat Reddy"}'::jsonb, '{"provider":"email","providers":["email"]}'::jsonb)
ON CONFLICT (id) DO NOTHING;

-- Also insert identities for these users (needed for auth to work)
INSERT INTO auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
SELECT 
  gen_random_uuid()::text,
  id, 
  jsonb_build_object('sub', id::text, 'email', email), 
  'email', 
  now(), 
  now(), 
  now()
FROM auth.users
WHERE id IN (
  '55555555-0000-0000-0000-000000000001',
  '55555555-0000-0000-0000-000000000002',
  '55555555-0000-0000-0000-000000000003',
  '55555555-0000-0000-0000-000000000004',
  '55555555-0000-0000-0000-000000000005',
  '55555555-0000-0000-0000-000000000006',
  '55555555-0000-0000-0000-000000000007',
  '55555555-0000-0000-0000-000000000008',
  '55555555-0000-0000-0000-000000000009',
  '55555555-0000-0000-0000-000000000010'
)
ON CONFLICT DO NOTHING;
