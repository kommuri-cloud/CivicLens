import { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import type { Issue } from '@/types';
import { formatStatus, formatSeverity, severityDotColor } from '@/lib/utils';

delete (L.Icon.Default.prototype as unknown as { _getIconUrl?: unknown })._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png',
});

function createSeverityIcon(severity: string) {
  const colors: Record<string, string> = {
    high: '#ef4444',
    medium: '#f59e0b',
    low: '#10b981',
  };
  const color = colors[severity] || '#64748b';

  return L.divIcon({
    className: 'custom-marker',
    html: `<div style="background-color:${color};width:14px;height:14px;border-radius:50%;border:3px solid white;box-shadow:0 1px 4px rgba(0,0,0,0.3);"></div>`,
    iconSize: [20, 20],
    iconAnchor: [10, 10],
  });
}

interface MapProps {
  issues?: Issue[];
  center?: [number, number];
  zoom?: number;
  height?: string;
  showPopup?: boolean;
  onMarkerClick?: (issueId: string) => void;
  singleMarker?: { lat: number; lng: number; label?: string };
  showHeatCircles?: boolean;
}

function Recenter({ center }: { center: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(center);
  }, [center, map]);
  return null;
}

export function IssueMap({
  issues = [],
  center = [16.5062, 80.648],
  zoom = 13,
  height = '400px',
  showPopup = true,
  onMarkerClick,
  singleMarker,
  showHeatCircles = false,
}: MapProps) {
  return (
    <div style={{ height }} className="rounded-xl overflow-hidden border border-slate-200 z-0">
      <MapContainer center={center} zoom={zoom} style={{ height: '100%', width: '100%' }}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {singleMarker && (
          <>
            <Recenter center={[singleMarker.lat, singleMarker.lng]} />
            <Marker position={[singleMarker.lat, singleMarker.lng]}>
              {singleMarker.label && showPopup && (
                <Popup>{singleMarker.label}</Popup>
              )}
            </Marker>
          </>
        )}
        {issues.map((issue) => (
          <Marker
            key={issue.id}
            position={[issue.latitude, issue.longitude]}
            icon={createSeverityIcon(issue.severity)}
            eventHandlers={{
              click: () => onMarkerClick?.(issue.id),
            }}
          >
            {showPopup && (
              <Popup>
                <div className="text-sm">
                  <p className="font-semibold">{issue.title}</p>
                  <p className="text-gray-600">{issue.location_name}</p>
                  <p className="mt-1">
                    <span className={`inline-block w-2 h-2 rounded-full mr-1 ${severityDotColor(issue.severity)}`}></span>
                    {formatSeverity(issue.severity)} Severity
                  </p>
                  <p className="text-gray-500">{formatStatus(issue.status)}</p>
                  {issue.supporter_count > 0 && (
                    <p className="text-gray-500">{issue.supporter_count} reports</p>
                  )}
                </div>
              </Popup>
            )}
          </Marker>
        ))}
        {showHeatCircles &&
          issues.map((issue) => (
            <Circle
              key={`circle-${issue.id}`}
              center={[issue.latitude, issue.longitude]}
              radius={issue.severity === 'high' ? 300 : issue.severity === 'medium' ? 200 : 100}
              pathOptions={{
                color: issue.severity === 'high' ? '#ef4444' : issue.severity === 'medium' ? '#f59e0b' : '#10b981',
                fillColor: issue.severity === 'high' ? '#ef4444' : issue.severity === 'medium' ? '#f59e0b' : '#10b981',
                fillOpacity: 0.15,
              }}
            />
          ))}
      </MapContainer>
    </div>
  );
}
