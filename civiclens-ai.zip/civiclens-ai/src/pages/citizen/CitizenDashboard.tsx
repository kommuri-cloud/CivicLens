import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { Card, StatCard, PageHeader, Spinner, EmptyState, Badge } from '@/components/ui';
import { IssueMap } from '@/components/IssueMap';
import { Button } from '@/components/ui/Button';
import { getNearbyIssues } from '@/services/ai/duplicate-detection';
import { formatStatus, formatSeverity, severityColor, statusColor, formatTimeAgo, classNames } from '@/lib/utils';
import { Plus, FileText, Clock, CheckCircle2, RotateCcw, MapPin, AlertCircle, ChevronRight } from 'lucide-react';
import type { Issue } from '@/types';

export function CitizenDashboard() {
  const { profile } = useAuth();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [myIssues, setMyIssues] = useState<Issue[]>([]);
  const [nearbyIssues, setNearbyIssues] = useState<Issue[]>([]);
  const [stats, setStats] = useState({ total: 0, pending: 0, inProgress: 0, resolved: 0, reopened: 0 });
  const [locationDenied, setLocationDenied] = useState(false);

  const fetchData = useCallback(async () => {
    if (!profile) return;

    const { data: issues } = await supabase
      .from('issues')
      .select('*')
      .eq('citizen_id', profile.id)
      .order('created_at', { ascending: false });

    const issueList = (issues || []) as Issue[];
    setMyIssues(issueList);

    setStats({
      total: issueList.length,
      pending: issueList.filter((i) => ['submitted', 'ai_analyzed', 'assigned', 'acknowledged'].includes(i.status)).length,
      inProgress: issueList.filter((i) => i.status === 'in_progress').length,
      resolved: issueList.filter((i) => ['resolved', 'citizen_verification', 'verified', 'closed'].includes(i.status)).length,
      reopened: issueList.filter((i) => i.status === 'reopened').length,
    });

    // Try to get nearby issues
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (pos) => {
          const nearby = await getNearbyIssues(pos.coords.latitude, pos.coords.longitude, 3000);
          setNearbyIssues(nearby.slice(0, 20));
          setLoading(false);
        },
        async () => {
          setLocationDenied(true);
          // Fallback to Vijayawada center
          const nearby = await getNearbyIssues(16.5062, 80.648, 5000);
          setNearbyIssues(nearby.slice(0, 20));
          setLoading(false);
        },
        { timeout: 5000 }
      );
    } else {
      const nearby = await getNearbyIssues(16.5062, 80.648, 5000);
      setNearbyIssues(nearby.slice(0, 20));
      setLoading(false);
    }
  }, [profile]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader title="Dashboard" subtitle={`Welcome back, ${profile?.full_name}`}>
        <Button onClick={() => navigate('/dashboard/report')} size="lg">
          <Plus className="w-5 h-5" />
          Report an Issue
        </Button>
      </PageHeader>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <StatCard label="Total" value={stats.total} icon={<FileText className="w-6 h-6" />} color="bg-teal-50 text-teal-600" />
        <StatCard label="Pending" value={stats.pending} icon={<Clock className="w-6 h-6" />} color="bg-amber-50 text-amber-600" />
        <StatCard label="In Progress" value={stats.inProgress} icon={<Clock className="w-6 h-6" />} color="bg-orange-50 text-orange-600" />
        <StatCard label="Resolved" value={stats.resolved} icon={<CheckCircle2 className="w-6 h-6" />} color="bg-emerald-50 text-emerald-600" />
        <StatCard label="Reopened" value={stats.reopened} icon={<RotateCcw className="w-6 h-6" />} color="bg-red-50 text-red-600" />
      </div>

      {/* Nearby Issues Map */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-teal-600" />
            Nearby Civic Issues
          </h2>
          <Button variant="outline" size="sm" onClick={() => navigate('/dashboard/map')}>
            View Full Map
          </Button>
        </div>
        {locationDenied && (
          <div className="flex items-center gap-2 p-3 mb-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-700 text-sm">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            Location permission denied. Showing issues near Vijayawada city center.
          </div>
        )}
        <IssueMap issues={nearbyIssues} height="350px" />
      </div>

      {/* Recent Complaints */}
      <div>
        <h2 className="text-lg font-semibold text-slate-900 mb-3">Recent Complaints</h2>
        {myIssues.length === 0 ? (
          <Card>
            <EmptyState
              icon={<FileText className="w-12 h-12" />}
              title="No complaints yet"
              description="Report your first civic issue to get started."
            >
              <Button onClick={() => navigate('/dashboard/report')}>
                <Plus className="w-4 h-4" />
                Report an Issue
              </Button>
            </EmptyState>
          </Card>
        ) : (
          <div className="space-y-3">
            {myIssues.slice(0, 5).map((issue) => (
              <Card key={issue.id} className="hover:shadow-md transition-shadow cursor-pointer" >
                <div onClick={() => navigate(`/dashboard/complaints/${issue.id}`)} className="flex items-center gap-4">
                  <div className={classNames('w-2 h-12 rounded-full', issue.severity === 'high' ? 'bg-red-500' : issue.severity === 'medium' ? 'bg-amber-500' : 'bg-emerald-500')} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-mono text-slate-500">{issue.complaint_id}</span>
                      <Badge className={severityColor(issue.severity)}>{formatSeverity(issue.severity)}</Badge>
                      <Badge className={statusColor(issue.status)}>{formatStatus(issue.status)}</Badge>
                    </div>
                    <p className="font-medium text-slate-900 truncate">{issue.title}</p>
                    <p className="text-sm text-slate-500 truncate">{issue.location_name} · {formatTimeAgo(issue.created_at)}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-400 flex-shrink-0" />
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
