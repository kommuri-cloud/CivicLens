/*
# CivicLens AI - Seed Data Part 1: Departments, Wards, Categories, Profiles

Creates reference data and demo profiles linked to the demo auth users.
*/

-- ============ Departments ============
INSERT INTO departments (id, name, description, contact_email, contact_phone) VALUES
  ('11111111-0000-0000-0000-000000000001', 'Roads & Infrastructure', 'Responsible for road maintenance, pothole repair, and road infrastructure', 'roads@demo.vjc.gov', '0866-2571234'),
  ('11111111-0000-0000-0000-000000000002', 'Sanitation & Waste Management', 'Garbage collection, waste disposal, and public cleanliness', 'sanitation@demo.vjc.gov', '0866-2571235'),
  ('11111111-0000-0000-0000-000000000003', 'Drainage Department', 'Storm drains, drainage infrastructure, and flood prevention', 'drainage@demo.vjc.gov', '0866-2571236'),
  ('11111111-0000-0000-0000-000000000004', 'Street Lighting', 'Public street lighting maintenance and repair', 'streetlights@demo.vjc.gov', '0866-2571237'),
  ('11111111-0000-0000-0000-000000000005', 'Water Works', 'Water supply, leakage, and water infrastructure', 'water@demo.vjc.gov', '0866-2571238'),
  ('11111111-0000-0000-0000-000000000006', 'Sewage Department', 'Sewage systems and overflow management', 'sewage@demo.vjc.gov', '0866-2571239'),
  ('11111111-0000-0000-0000-000000000007', 'Urban Forestry', 'Tree management, fallen trees, and urban green spaces', 'forestry@demo.vjc.gov', '0866-2571240'),
  ('11111111-0000-0000-0000-000000000008', 'General Infrastructure', 'Public infrastructure, parks, and municipal facilities', 'infrastructure@demo.vjc.gov', '0866-2571241')
ON CONFLICT (name) DO NOTHING;

-- ============ Wards ============
INSERT INTO wards (id, name, number, area, population) VALUES
  ('22222222-0000-0000-0000-000000000001', 'Ward 1 - One Town', 1, 'Old Town', 45000),
  ('22222222-0000-0000-0000-000000000002', 'Ward 2 - Governorpet', 2, 'Governorpet', 38000),
  ('22222222-0000-0000-0000-000000000003', 'Ward 3 - Labbipet', 3, 'Labbipet', 52000),
  ('22222222-0000-0000-0000-000000000004', 'Ward 4 - Suryaraopet', 4, 'Suryaraopet', 41000),
  ('22222222-0000-0000-0000-000000000005', 'Ward 5 - Gandhi Nagar', 5, 'Gandhi Nagar', 47000),
  ('22222222-0000-0000-0000-000000000006', 'Ward 6 - Benz Circle', 6, 'Benz Circle', 55000),
  ('22222222-0000-0000-0000-000000000007', 'Ward 7 - Moghalrajpuram', 7, 'Moghalrajpuram', 43000),
  ('22222222-0000-0000-0000-000000000008', 'Ward 8 - Patamata', 8, 'Patamata', 49000),
  ('22222222-0000-0000-0000-000000000009', 'Ward 9 - Satyanarayanapuram', 9, 'Satyanarayanapuram', 51000),
  ('22222222-0000-0000-0000-000000000010', 'Ward 10 - Ajit Singh Nagar', 10, 'Ajit Singh Nagar', 46000),
  ('22222222-0000-0000-0000-000000000011', 'Ward 11 - Gunadala', 11, 'Gunadala', 53000),
  ('22222222-0000-0000-0000-000000000012', 'Ward 12 - Poranki', 12, 'Poranki', 39000)
ON CONFLICT (name) DO NOTHING;

-- ============ Issue Categories ============
INSERT INTO issue_categories (id, name, description, icon, default_department_id, default_sla_high_hours, default_sla_medium_hours, default_sla_low_hours) VALUES
  ('33333333-0000-0000-0000-000000000001', 'Pothole', 'Potholes in road surface', 'CircleDot', '11111111-0000-0000-0000-000000000001', 24, 72, 168),
  ('33333333-0000-0000-0000-000000000002', 'Damaged Road', 'Road surface damage, cracks, subsidence', 'Construction', '11111111-0000-0000-0000-000000000001', 48, 120, 240),
  ('33333333-0000-0000-0000-000000000003', 'Garbage Dump', 'Illegal garbage dumping', 'Trash2', '11111111-0000-0000-0000-000000000002', 12, 48, 96),
  ('33333333-0000-0000-0000-000000000004', 'Overflowing Garbage Bin', 'Public garbage bins overflowing', 'Trash2', '11111111-0000-0000-0000-000000000002', 12, 24, 72),
  ('33333333-0000-0000-0000-000000000005', 'Blocked Drain', 'Blocked or clogged drainage', 'Waves', '11111111-0000-0000-0000-000000000003', 24, 72, 168),
  ('33333333-0000-0000-0000-000000000006', 'Open Manhole', 'Open or damaged manhole - dangerous', 'CircleAlert', '11111111-0000-0000-0000-000000000003', 6, 12, 24),
  ('33333333-0000-0000-0000-000000000007', 'Broken Streetlight', 'Street lighting not working', 'Lightbulb', '11111111-0000-0000-0000-000000000004', 24, 72, 168),
  ('33333333-0000-0000-0000-000000000008', 'Water Leakage', 'Water pipe leakage or supply issue', 'Droplets', '11111111-0000-0000-0000-000000000005', 24, 72, 168),
  ('33333333-0000-0000-0000-000000000009', 'Sewage Overflow', 'Sewage overflow or blockage', 'Biohazard', '11111111-0000-0000-0000-000000000006', 12, 48, 96),
  ('33333333-0000-0000-0000-000000000010', 'Fallen Tree', 'Fallen trees blocking roads or paths', 'TreePine', '11111111-0000-0000-0000-000000000007', 6, 24, 72),
  ('33333333-0000-0000-0000-000000000011', 'Damaged Public Infrastructure', 'Damaged public property, fences, walls, bus stops', 'Building2', '11111111-0000-0000-0000-000000000008', 48, 120, 240),
  ('33333333-0000-0000-0000-000000000012', 'Other', 'Other civic issues', 'CircleHelp', '11111111-0000-0000-0000-000000000008', 48, 120, 240)
ON CONFLICT (name) DO NOTHING;

-- ============ Demo Profiles ============
INSERT INTO profiles (id, role, full_name, phone, ward_id, department_id, is_active) VALUES
  ('55555555-0000-0000-0000-000000000001', 'citizen', 'Ravi Kumar', '9876543210', '22222222-0000-0000-0000-000000000003', NULL, true),
  ('55555555-0000-0000-0000-000000000002', 'officer', 'Suresh Reddy', '9876543211', '22222222-0000-0000-0000-000000000003', '11111111-0000-0000-0000-000000000001', true),
  ('55555555-0000-0000-0000-000000000003', 'admin', 'Municipal Commissioner', '9876543212', NULL, NULL, true),
  ('55555555-0000-0000-0000-000000000004', 'citizen', 'Lakshmi Devi', '9876543213', '22222222-0000-0000-0000-000000000005', NULL, true),
  ('55555555-0000-0000-0000-000000000005', 'citizen', 'Pradeep Naidu', '9876543214', '22222222-0000-0000-0000-000000000006', NULL, true),
  ('55555555-0000-0000-0000-000000000006', 'officer', 'Officer Sharma', '9876543215', '22222222-0000-0000-0000-000000000002', '11111111-0000-0000-0000-000000000002', true),
  ('55555555-0000-0000-0000-000000000007', 'officer', 'Officer Rao', '9876543216', '22222222-0000-0000-0000-000000000007', '11111111-0000-0000-0000-000000000003', true),
  ('55555555-0000-0000-0000-000000000008', 'officer', 'Officer Krishna', '9876543217', '22222222-0000-0000-0000-000000000008', '11111111-0000-0000-0000-000000000004', true),
  ('55555555-0000-0000-0000-000000000009', 'citizen', 'Anjali Rao', '9876543218', '22222222-0000-0000-0000-000000000009', NULL, true),
  ('55555555-0000-0000-0000-000000000010', 'citizen', 'Venkat Reddy', '9876543219', '22222222-0000-0000-0000-000000000010', NULL, true)
ON CONFLICT (id) DO NOTHING;
