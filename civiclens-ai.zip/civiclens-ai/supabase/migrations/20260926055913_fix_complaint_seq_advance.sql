/*
# Fix: Advance complaint_seq past seeded data

## Root Cause
The seed migrations inserted 32 issues with hardcoded complaint IDs
(CIV-2026-000001 through CIV-2026-000032) but never advanced the
`complaint_seq` sequence. The sequence remained at 1, so every call to
`generate_complaint_id()` produced an ID that already existed — causing
a unique-constraint violation on `issues.complaint_id` that aborted the
entire citizen complaint submission.

## Fix
Set the sequence's current value to the highest existing complaint number
so the next generated ID is CIV-2026-000033 (one past the last seeded row).
*/

SELECT setval('complaint_seq', (
  SELECT COALESCE(MAX(
    CAST(
      regexp_replace(complaint_id, '^CIV-\d{4}-', '') AS int
    )
  ), 0)
  FROM issues
));
