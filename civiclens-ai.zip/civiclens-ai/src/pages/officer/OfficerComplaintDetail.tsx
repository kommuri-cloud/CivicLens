import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { aiService } from '@/services/ai';
import { Card, Badge, Spinner, EmptyState, Button } from '@/components/ui';
import { IssueMap } from '@/components/IssueMap';
import {
  formatStatus, formatSeverity, severityColor, statusColor, statusDotColor,
  formatDateTime, formatSlaRemaining, isSlaBreached, classNames,
} from '@/lib/utils';
import {
  ArrowLeft, MapPin, Brain, CheckCircle2, Clock, AlertCircle, Camera,
  User as UserIcon, Building2, Upload, Play, FileText, ShieldCheck,
} from 'lucide-react';
import type { IssueWithRelations, Profile } from '@/types';

export function OfficerComplaintDetail() {
  const { id } = useParams();
  const { profile } = useAuth();
  const navigate = useNavigate();

  const [issue, setIssue] = useState<IssueWithRelations | null>(null);
  const [loading, setLoading] = useState(true);
  const [officers, setOfficers] = useState<Profile[]>([]);
  const [actionLoading, setActionLoading] = useState(false);
  const [repairPhoto, setRepairPhoto] = useState<File | null>(null);
  const [repairPreview, setRepairPreview] = useState<string | null>(null);
  const [showRepairUpload, setShowRepairUpload] = useState(false);
  const [verificationResult, setVerificationResult] = useState<{ issue_status: string; visual_similarity: number; detected_change: string; verification_confidence: number } | null>(null);
  const [verifying, setVerifying] = useState(false);

  const fetchIssue = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    const { data } = await supabase
      .from('issues')
      .select(`
        *,
        category:issue_categories(*),
        department:departments(*),
        ward:wards(*),
        assigned_officer:profiles!issues_assigned_officer_id_fkey(*),
        citizen:profiles!issues_citizen_id_fkey(*),
        images:issue_images(*),
        ai_analysis:issue_ai_analysis(*),
        status_history:issue_status_history(*)
      `)
      .eq('id', id)
      .maybeSingle();
    setIssue(data as unknown as IssueWithRelations);
    setLoading(false);
  }, [id]);

  useEffect(() => {
    fetchIssue();
  }, [fetchIssue]);

  useEffect(() => {
    const fetchOfficers = async () => {
      if (!issue?.department_id) return;
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('role', 'officer')
        .eq('department_id', issue.department_id);
      setOfficers((data || []) as Profile[]);
    };
    if (issue) fetchOfficers();
  }, [issue]);

  const changeStatus = async (newStatus: string, comment?: string) => {
    setActionLoading(true);
    const { error } = await supabase.rpc('change_issue_status', {
      p_issue_id: issue!.id,
      p_new_status: newStatus,
      p_comment: comment || '',
    });
    if (error) {
      alert('Could not update status. Please try again.');
    } else {
      await fetchIssue();
    }
    setActionLoading(false);
  };

  const assignOfficer = async (officerId: string) => {
    setActionLoading(true);
    const { error } = await supabase.rpc('assign_issue_officer', {
      p_issue_id: issue!.id,
      p_officer_id: officerId,
    });
    if (error) {
      alert('Could not assign officer.');
    } else {
      await fetchIssue();
    }
    setActionLoading(false);
  };

  const handleRepairUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setRepairPhoto(file);
    setRepairPreview(URL.createObjectURL(file));
  };

  const submitRepairPhoto = async () => {
    if (!repairPhoto || !issue || !profile) return;
    setActionLoading(true);

    try {
      const fileName = `${issue.id}/repair-${Date.now()}.jpg`;
      await supabase.storage.from('issue-images').upload(fileName, repairPhoto);
      const { data: urlData } = supabase.storage.from('issue-images').getPublicUrl(fileName);

      await supabase.from('issue_images').insert({
        issue_id: issue.id,
        image_url: urlData.publicUrl,
        image_type: 'repair',
        uploaded_by: profile.id,
      });

      setShowRepairUpload(false);
      setRepairPhoto(null);
      setRepairPreview(null);
      await fetchIssue();
    } catch {
      alert('Could not upload repair photo.');
    }
    setActionLoading(false);
  };

  const markResolved = async () => {
    setActionLoading(true);
    await changeStatus('resolved', 'Issue has been resolved by officer');
    setActionLoading(false);
  };

  const runAiVerification = async () => {
    if (!issue) return;
    const beforeImage = issue.images?.find((img) => img.image_type === 'citizen');
    const afterImage = issue.images?.find((img) => img.image_type === 'repair');
    if (!beforeImage || !afterImage) {
      alert('Both before and after images are needed for verification.');
      return;
    }
    setVerifying(true);
    const result = await aiService.verifyRepair(beforeImage.image_url, afterImage.image_url);
    setVerificationResult(result);
    setVerifying(false);
  };

  if (loading) {
    return <div className="flex justify-center py-20"><Spinner size="lg" /></div>;
  }

  if (!issue) {
    return <Card><EmptyState icon={<AlertCircle className="w-12 h-12" />} title="Complaint not found"><Link to="/officer/queue"><Button>Back to Queue</Button></Link></EmptyState></Card>;
  }

  const slaBreached = isSlaBreached(issue.sla_deadline);
  const canAct = profile?.role === 'officer' || profile?.role === 'admin';

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <Link to="/officer/queue" className="flex items-center gap-2 text-sm text-slate-600 hover:text-slate-900">
        <ArrowLeft className="w-4 h-4" /> Back to Queue
      </Link>

      {/* Header */}
      <Card>
        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="text-sm font-mono text-slate-500">{issue.complaint_id}</span>
              <Badge className={severityColor(issue.severity)}>{formatSeverity(issue.severity)} Severity</Badge>
              <Badge className={statusColor(issue.status)}>{formatStatus(issue.status)}</Badge>
              {slaBreached && !['verified', 'closed'].includes(issue.status) && <Badge className="bg-red-100 text-red-700 border-red-200">SLA BREACHED</Badge>}
            </div>
            <h1 className="text-xl font-bold text-slate-900">{issue.title}</h1>
            <p className="text-sm text-slate-500 mt-1">{issue.description}</p>
          </div>
        </div>
      </Card>

      {/* Info Grid */}
      <div className="grid sm:grid-cols-2 gap-4">
        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-3">Complaint Information</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">Category:</span><span className="font-medium text-slate-900">{issue.category?.name}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Department:</span><span className="font-medium text-slate-900">{issue.department?.name}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Ward:</span><span className="font-medium text-slate-900">{issue.ward?.name}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Citizen:</span><span className="font-medium text-slate-900">{issue.citizen?.full_name || 'Anonymous'}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Date:</span><span className="font-medium text-slate-900">{formatDateTime(issue.created_at)}</span></div>
            <div className="flex justify-between"><span className="text-slate-500">Officer:</span><span className="font-medium text-slate-900">{issue.assigned_officer?.full_name || 'Unassigned'}</span></div>
          </div>
        </Card>

        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-3">SLA & Status</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between"><span className="text-slate-500">SLA:</span><span className={classNames('font-medium', slaBreached ? 'text-red-600' : 'text-slate-900')}>{formatSlaRemaining(issue.sla_deadline)}</span></div>
            {issue.ai_confidence && <div className="flex justify-between"><span className="text-slate-500">AI Confidence:</span><span className="font-medium text-teal-600">{issue.ai_confidence}%</span></div>}
            <div className="flex justify-between"><span className="text-slate-500">Supporters:</span><span className="font-medium text-slate-900">{issue.supporter_count}</span></div>
            {issue.resolved_at && <div className="flex justify-between"><span className="text-slate-500">Resolved:</span><span className="font-medium text-slate-900">{formatDateTime(issue.resolved_at)}</span></div>}
          </div>
        </Card>
      </div>

      {/* Before/After Images */}
      {issue.images && issue.images.length > 0 && (
        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-3">Images</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-slate-400 mb-2">BEFORE (Citizen)</p>
              {issue.images.filter((img) => img.image_type === 'citizen').map((img) => (
                <img key={img.id} src={img.image_url} alt="Before" className="w-full h-40 object-cover rounded-lg border border-slate-200" />
              ))}
              {issue.images.filter((img) => img.image_type === 'citizen').length === 0 && <div className="w-full h-40 bg-slate-100 rounded-lg flex items-center justify-center text-sm text-slate-400">No image</div>}
            </div>
            <div>
              <p className="text-xs text-slate-400 mb-2">AFTER (Repair)</p>
              {issue.images.filter((img) => img.image_type === 'repair').map((img) => (
                <img key={img.id} src={img.image_url} alt="After" className="w-full h-40 object-cover rounded-lg border border-slate-200" />
              ))}
              {issue.images.filter((img) => img.image_type === 'repair').length === 0 && <div className="w-full h-40 bg-slate-100 rounded-lg flex items-center justify-center text-sm text-slate-400">No repair photo yet</div>}
            </div>
          </div>
        </Card>
      )}

      {/* AI Verification */}
      {issue.images?.some((img) => img.image_type === 'repair') && (
        <Card>
          <div className="flex items-center gap-2 mb-3">
            <ShieldCheck className="w-5 h-5 text-teal-600" />
            <h3 className="text-sm font-medium text-slate-900">Repair Verification</h3>
          </div>
          {verifying ? (
            <div className="flex justify-center py-6"><Spinner /></div>
          ) : verificationResult ? (
            <div className="bg-teal-50 rounded-xl p-4 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-slate-500">Issue Status:</span><span className="font-medium text-slate-900">{verificationResult.issue_status}</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Visual Similarity:</span><span className="font-medium text-slate-900">{verificationResult.visual_similarity}%</span></div>
              <div className="flex justify-between"><span className="text-slate-500">Verification Confidence:</span><span className="font-medium text-teal-600">{verificationResult.verification_confidence}%</span></div>
              <p className="text-slate-600 pt-2 border-t border-teal-100">{verificationResult.detected_change}</p>
            </div>
          ) : (
            <Button variant="outline" onClick={runAiVerification}>
              <Brain className="w-4 h-4" /> Run AI Repair Verification
            </Button>
          )}
        </Card>
      )}

      {/* Map */}
      <Card>
        <h3 className="text-sm font-medium text-slate-500 mb-3">Location</h3>
        <IssueMap singleMarker={{ lat: issue.latitude, lng: issue.longitude, label: issue.location_name }} height="300px" />
      </Card>

      {/* AI Analysis */}
      {issue.ai_analysis && issue.ai_analysis.length > 0 && (
        <Card>
          <div className="flex items-center gap-2 mb-3"><Brain className="w-5 h-5 text-teal-600" /><h3 className="text-sm font-medium text-slate-900">AI Analysis</h3></div>
          <div className="grid grid-cols-2 gap-3 text-sm mb-3">
            <div><span className="text-slate-500">Detected:</span> <span className="font-medium text-slate-900">{issue.ai_analysis[0].detected_category}</span></div>
            <div><span className="text-slate-500">Confidence:</span> <span className="font-medium text-teal-600">{issue.ai_analysis[0].confidence}%</span></div>
          </div>
          <p className="text-sm text-slate-600">{issue.ai_analysis[0].ai_description}</p>
        </Card>
      )}

      {/* Timeline */}
      <Card>
        <h3 className="text-sm font-medium text-slate-500 mb-4">Timeline</h3>
        <div className="space-y-4">
          {(issue.status_history || []).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).map((entry) => (
            <div key={entry.id} className="flex items-start gap-3">
              <div className={classNames('w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0', statusDotColor(entry.status as never))}>
                <CheckCircle2 className="w-4 h-4 text-white" />
              </div>
              <div>
                <p className="text-sm font-medium text-slate-900">{formatStatus(entry.status as never)}</p>
                {entry.comment && <p className="text-sm text-slate-500">{entry.comment}</p>}
                <p className="text-xs text-slate-400">{formatDateTime(entry.created_at)}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      {/* Officer Actions */}
      {canAct && !['verified', 'closed'].includes(issue.status) && (
        <Card className="border-teal-200">
          <h3 className="text-sm font-medium text-slate-900 mb-4">Officer Actions</h3>
          <div className="flex flex-wrap gap-2">
            {issue.status === 'submitted' || issue.status === 'ai_analyzed' ? (
              <Button size="sm" onClick={() => assignOfficer(profile!.id)} loading={actionLoading}>
                <UserIcon className="w-4 h-4" /> Assign to Me
              </Button>
            ) : null}

            {issue.status === 'assigned' && (
              <Button size="sm" onClick={() => changeStatus('acknowledged', 'Officer acknowledged')} loading={actionLoading}>
                <CheckCircle2 className="w-4 h-4" /> Acknowledge
              </Button>
            )}

            {(issue.status === 'acknowledged' || issue.status === 'assigned') && (
              <Button size="sm" variant="secondary" onClick={() => changeStatus('in_progress', 'Work started')} loading={actionLoading}>
                <Play className="w-4 h-4" /> Start Work
              </Button>
            )}

            {issue.status === 'in_progress' && (
              <>
                <Button size="sm" variant="outline" onClick={() => setShowRepairUpload(!showRepairUpload)}>
                  <Camera className="w-4 h-4" /> Upload Repair Photo
                </Button>
                {issue.images?.some((img) => img.image_type === 'repair') && (
                  <Button size="sm" variant="success" onClick={markResolved} loading={actionLoading}>
                    <CheckCircle2 className="w-4 h-4" /> Mark Resolved
                  </Button>
                )}
              </>
            )}

            {issue.status === 'reopened' && (
              <Button size="sm" onClick={() => changeStatus('in_progress', 'Reopened issue being addressed')} loading={actionLoading}>
                <Play className="w-4 h-4" /> Start Working Again
              </Button>
            )}

            {/* Assign to other officer */}
            {officers.length > 0 && (issue.status === 'submitted' || issue.status === 'ai_analyzed' || issue.status === 'assigned') && (
              <select
                className="px-3 py-1.5 border border-slate-300 rounded-lg text-sm"
                onChange={(e) => e.target.value && assignOfficer(e.target.value)}
                value=""
              >
                <option value="">Assign to officer...</option>
                {officers.map((o) => <option key={o.id} value={o.id}>{o.full_name}</option>)}
              </select>
            )}
          </div>

          {/* Repair photo upload */}
          {showRepairUpload && (
            <div className="mt-4 p-4 bg-slate-50 rounded-lg">
              <label className="block border-2 border-dashed border-slate-300 rounded-lg p-6 text-center cursor-pointer hover:border-teal-400">
                <input type="file" accept="image/*" capture="environment" onChange={handleRepairUpload} className="hidden" />
                <Upload className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                <span className="text-sm text-slate-600">{repairPhoto ? repairPhoto.name : 'Upload repair photo'}</span>
              </label>
              {repairPreview && <img src={repairPreview} alt="Repair preview" className="mt-3 w-full h-40 object-cover rounded-lg border border-slate-200" />}
              <Button size="sm" className="mt-3" onClick={submitRepairPhoto} disabled={!repairPhoto} loading={actionLoading}>
                Submit Repair Photo
              </Button>
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
