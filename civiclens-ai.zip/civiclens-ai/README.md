# CivicLens AI Platform

A civic issue reporting platform. Citizens report problems (potholes, garbage, drainage, etc.) with photos and GPS location, AI helps classify them and detect duplicates, and municipal officers and admins manage and resolve them.

## Features

- **Citizen portal**: report issues with photos, view a civic map, track complaints, get notifications
- **Officer portal**: complaint queue, complaint detail handling, analytics
- **Admin portal**: users, wards, departments, categories, SLA configuration
- Multi-language support, duplicate complaint detection, interactive maps

## Tech stack

React 18, TypeScript, Vite, Tailwind CSS, React Router, Leaflet, Recharts, Supabase (auth, database, storage)

## Getting started

```bash
npm install
cp .env.example .env   # then fill in your Supabase credentials
npm run dev
```

## Supabase setup

1. Create a project at https://supabase.com
2. Run the SQL files in `supabase/migrations/` in filename order (SQL editor or `supabase db push`)
3. Copy your project URL and anon key into `.env`

## Scripts

| Command | Description |
| --- | --- |
| `npm run dev` | Start dev server |
| `npm run build` | Production build |
| `npm run preview` | Preview production build |
| `npm run lint` | Run ESLint |
| `npm run typecheck` | Type-check |
