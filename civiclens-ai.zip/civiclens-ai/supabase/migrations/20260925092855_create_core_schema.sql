/*
# CivicLens AI - Core Database Schema

## Overview
Creates the complete relational schema for the CivicLens AI civic issue reporting platform.
All tables use uuid primary keys and timestamps with timezone.

## New Tables

### departments
Municipal departments (Roads, Sanitation, etc.)

### wards
City administrative wards with geographic boundaries.

### issue_categories
Configurable issue categories (Pothole, Garbage Dump, etc.) with default SLA per severity.

### profiles
Extends Supabase auth.users with role (citizen/officer/admin), full name, phone, ward/department assignment.

### issues
Core complaint table with geospatial location, severity, status, SLA deadline.

### issue_images
Images attached to issues (citizen photos, officer repair photos).

### issue_ai_analysis
AI analysis results for each issue.

### issue_status_history
Timeline of every status transition with timestamps.

### issue_supporters
Citizens who support an existing issue (duplicate prevention). Unique per issue+citizen.

### issue_verifications
Citizen verification of resolved issues (fixed / still exists).

### notifications
In-app notifications for status changes, SLA breaches, verification requests.

### audit_logs
Audit trail of admin/officer actions.

## Indexes
Created on all frequently-queried columns.

## Security
- RLS enabled on all tables (policies in separate migration)
- Helper functions for complaint ID generation, SLA calculation, and updated_at
*/

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============ departments ============
CREATE TABLE IF NOT EXISTS departments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text DEFAULT '',
  contact_email text DEFAULT '',
  contact_phone text DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ wards ============
CREATE TABLE IF NOT EXISTS wards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  number int UNIQUE NOT NULL,
  area text DEFAULT '',
  population int DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ issue_categories ============
CREATE TABLE IF NOT EXISTS issue_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  description text DEFAULT '',
  icon text DEFAULT '',
  default_department_id uuid REFERENCES departments(id) ON DELETE SET NULL,
  default_sla_high_hours int NOT NULL DEFAULT 24,
  default_sla_medium_hours int NOT NULL DEFAULT 72,
  default_sla_low_hours int NOT NULL DEFAULT 168,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ profiles ============
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'citizen' CHECK (role IN ('citizen', 'officer', 'admin')),
  full_name text NOT NULL DEFAULT '',
  phone text DEFAULT '',
  ward_id uuid REFERENCES wards(id) ON DELETE SET NULL,
  department_id uuid REFERENCES departments(id) ON DELETE SET NULL,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ issues ============
CREATE TABLE IF NOT EXISTS issues (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  complaint_id text UNIQUE NOT NULL,
  citizen_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  category_id uuid NOT NULL REFERENCES issue_categories(id) ON DELETE RESTRICT,
  department_id uuid REFERENCES departments(id) ON DELETE SET NULL,
  assigned_officer_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  ward_id uuid REFERENCES wards(id) ON DELETE SET NULL,
  title text NOT NULL DEFAULT '',
  description text DEFAULT '',
  severity text NOT NULL DEFAULT 'medium' CHECK (severity IN ('high', 'medium', 'low')),
  status text NOT NULL DEFAULT 'submitted' CHECK (status IN ('submitted','ai_analyzed','assigned','acknowledged','in_progress','resolved','citizen_verification','verified','reopened','closed')),
  latitude numeric(9,6) NOT NULL,
  longitude numeric(9,6) NOT NULL,
  location_name text DEFAULT '',
  road_name text DEFAULT '',
  municipality text DEFAULT '',
  supporter_count int NOT NULL DEFAULT 0,
  sla_deadline timestamptz,
  sla_breached boolean NOT NULL DEFAULT false,
  ai_confidence numeric(5,2),
  ai_analyzed_at timestamptz,
  resolved_at timestamptz,
  verified_at timestamptz,
  closed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- ============ issue_images ============
CREATE TABLE IF NOT EXISTS issue_images (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  issue_id uuid NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  image_url text NOT NULL,
  image_type text NOT NULL DEFAULT 'citizen' CHECK (image_type IN ('citizen', 'repair', 'verification')),
  uploaded_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ issue_ai_analysis ============
CREATE TABLE IF NOT EXISTS issue_ai_analysis (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  issue_id uuid NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  detected_category text NOT NULL,
  confidence numeric(5,2) NOT NULL,
  estimated_severity text NOT NULL,
  suggested_department text NOT NULL,
  ai_description text DEFAULT '',
  analysis_model text DEFAULT 'mock-v1',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ issue_status_history ============
CREATE TABLE IF NOT EXISTS issue_status_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  issue_id uuid NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  status text NOT NULL,
  previous_status text,
  changed_by uuid REFERENCES profiles(id) ON DELETE SET NULL,
  comment text DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ issue_supporters ============
CREATE TABLE IF NOT EXISTS issue_supporters (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  issue_id uuid NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  citizen_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(issue_id, citizen_id)
);

-- ============ issue_verifications ============
CREATE TABLE IF NOT EXISTS issue_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  issue_id uuid NOT NULL REFERENCES issues(id) ON DELETE CASCADE,
  citizen_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  is_fixed boolean NOT NULL,
  reason text DEFAULT '',
  verification_image_url text,
  ai_verification_confidence numeric(5,2),
  ai_verification_status text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ notifications ============
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  issue_id uuid REFERENCES issues(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  is_read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ audit_logs ============
CREATE TABLE IF NOT EXISTS audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  action text NOT NULL,
  target_type text NOT NULL,
  target_id uuid,
  details jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ============ Indexes ============
CREATE INDEX IF NOT EXISTS idx_issues_complaint_id ON issues(complaint_id);
CREATE INDEX IF NOT EXISTS idx_issues_citizen_id ON issues(citizen_id);
CREATE INDEX IF NOT EXISTS idx_issues_category_id ON issues(category_id);
CREATE INDEX IF NOT EXISTS idx_issues_department_id ON issues(department_id);
CREATE INDEX IF NOT EXISTS idx_issues_ward_id ON issues(ward_id);
CREATE INDEX IF NOT EXISTS idx_issues_status ON issues(status);
CREATE INDEX IF NOT EXISTS idx_issues_severity ON issues(severity);
CREATE INDEX IF NOT EXISTS idx_issues_created_at ON issues(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_issues_assigned_officer ON issues(assigned_officer_id);
CREATE INDEX IF NOT EXISTS idx_issues_location ON issues(latitude, longitude);
CREATE INDEX IF NOT EXISTS idx_issue_images_issue_id ON issue_images(issue_id);
CREATE INDEX IF NOT EXISTS idx_issue_status_history_issue_id ON issue_status_history(issue_id);
CREATE INDEX IF NOT EXISTS idx_issue_status_history_created ON issue_status_history(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_issue_supporters_issue_id ON issue_supporters(issue_id);
CREATE INDEX IF NOT EXISTS idx_issue_supporters_citizen_id ON issue_supporters(citizen_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
CREATE INDEX IF NOT EXISTS idx_audit_logs_actor_id ON audit_logs(actor_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_target ON audit_logs(target_type, target_id);

-- ============ Enable RLS on all tables ============
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE wards ENABLE ROW LEVEL SECURITY;
ALTER TABLE issue_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE issues ENABLE ROW LEVEL SECURITY;
ALTER TABLE issue_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE issue_ai_analysis ENABLE ROW LEVEL SECURITY;
ALTER TABLE issue_status_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE issue_supporters ENABLE ROW LEVEL SECURITY;
ALTER TABLE issue_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- ============ Helper: generate complaint ID ============
CREATE SEQUENCE IF NOT EXISTS complaint_seq START 1;

CREATE OR REPLACE FUNCTION generate_complaint_id()
RETURNS text
LANGUAGE sql
AS $$
  SELECT 'CIV-' || EXTRACT(YEAR FROM now())::text || '-' || lpad((nextval('complaint_seq'))::text, 6, '0');
$$;

-- ============ Helper: update updated_at ============
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS issues_updated_at ON issues;
CREATE TRIGGER issues_updated_at BEFORE UPDATE ON issues
FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============ Helper: calculate SLA deadline ============
CREATE OR REPLACE FUNCTION calculate_sla_deadline(p_category_id uuid, p_severity text)
RETURNS timestamptz
LANGUAGE plpgsql
AS $$
DECLARE
  v_hours int;
BEGIN
  SELECT CASE p_severity
    WHEN 'high' THEN default_sla_high_hours
    WHEN 'medium' THEN default_sla_medium_hours
    WHEN 'low' THEN default_sla_low_hours
  END INTO v_hours
  FROM issue_categories WHERE id = p_category_id;
  
  IF v_hours IS NULL THEN
    v_hours := 72;
  END IF;
  
  RETURN now() + (v_hours || ' hours')::interval;
END;
$$;

-- ============ Auto-create profile on signup ============
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO profiles (id, role, full_name)
  VALUES (NEW.id, 'citizen', COALESCE(NEW.raw_user_meta_data->>'full_name', 'New Citizen'));
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION handle_new_user();
