import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, StatCard, PageHeader, Spinner, Badge } from '@/components/ui';
import { IssueMap } from '@/components/IssueMap';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend, AreaChart, Area,
} from 'recharts';
import { formatSlaRemaining, isSlaBreached, classNames } from '@/lib/utils';
import { FileText, Clock, CheckCircle2, AlertTriangle, AlertCircle, MapPin, TrendingUp, Users } from 'lucide-react';
import type { Issue, Ward, Department } from '@/types';

const SEVERITY_COLORS: Record<string, string> = { high: '#ef4444', medium: '#f59e0b', low: '#10b981' };

export function AdminDashboard() {
  const [loading, setLoading] = useState(true);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [wards, setWards] = useState<Ward[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);

  const fetchData = useCallback(async () => {
    const [{ data: issueData }, { data: wardData }, { data: deptData }] = await Promise.all([
      supabase.from('issues').select('*').order('created_at', { ascending: false }),
      supabase.from('wards').select('*').order('number'),
      supabase.from('departments').select('*').order('name'),
    ]);
    setIssues((issueData || []) as Issue[]);
    setWards((wardData || []) as Ward[]);
    setDepartments((deptData || []) as Department[]);
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  if (loading) return <div className="flex justify-center py-20"><Spinner size="lg" /></div>;

  const resolved = issues.filter((i) => ['resolved', 'citizen_verification', 'verified', 'closed'].includes(i.status));
  const slaBreached = issues.filter((i) => i.sla_breached || (i.sla_deadline && isSlaBreached(i.sla_deadline) && !['verified', 'closed'].includes(i.status))).length;
  const highSeverity = issues.filter((i) => i.severity === 'high' && !['verified', 'closed'].includes(i.status)).length;
  const slaRate = resolved.length > 0 ? Math.round((resolved.filter((i) => i.sla_deadline && !isSlaBreached(i.sla_deadline)).length / resolved.length) * 100) : 0;

  // Issues by ward
  const wardData = wards.map((w) => ({
    name: w.name.replace('Ward ', 'W'),
    issues: issues.filter((i) => i.ward_id === w.id).length,
  resolved: issues.filter((i) => i.ward_id === w.id && ['resolved', 'verified', 'closed'].includes(i.status)).length,
  })).filter((d) => d.issues > 0);

  // Issues by department
  const deptData = departments.map((d) => ({
    name: d.name.split(' ').slice(0, 2).join(' '),
    issues: issues.filter((i) => i.department_id === d.id).length,
  })).filter((d) => d.issues > 0);

  // Category distribution
  const categoryData = issues.reduce((acc, i) => {
    const cat = i.title.split(' ').slice(0, 2).join(' ');
    acc[cat] = (acc[cat] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  const catChart = Object.entries(categoryData).map(([name, value]) => ({ name, value }));

  // Road health scores per ward
  const roadHealthData = wards.map((w) => {
    const wardIssues = issues.filter((i) => i.ward_id === w.id);
    if (wardIssues.length === 0) return null;
    const potholes = wardIssues.filter((i) => i.title.toLowerCase().includes('pothole')).length;
    const highSev = wardIssues.filter((i) => i.severity === 'high').length;
    const resolvedCount = wardIssues.filter((i) => ['resolved', 'verified', 'closed'].includes(i.status)).length;
    const resolutionRate = wardIssues.length > 0 ? resolvedCount / wardIssues.length : 0;
    const score = Math.max(0, Math.round(100 - potholes * 5 - highSev * 8 + resolutionRate * 30));
    return { name: w.name.replace('Ward ', 'W'), score, issues: wardIssues.length };
  }).filter(Boolean) as { name: string; score: number; issues: number }[];

  // Time series (last 14 days)
  const last14Days = Array.from({ length: 14 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (13 - i));
    return d;
  });
  const timeData = last14Days.map((d) => ({
    day: d.toLocaleDateString('en', { day: '2-digit', month: 'short' }),
    issues: issues.filter((i) => new Date(i.created_at).toDateString() === d.toDateString()).length,
  }));

  return (
    <div className="space-y-6">
      <PageHeader title="Admin Dashboard" subtitle="City-wide civic issue management and analytics" />

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard label="Total Issues" value={issues.length} icon={<FileText className="w-6 h-6" />} color="bg-teal-50 text-teal-600" />
        <StatCard label="Pending" value={issues.filter((i) => ['submitted', 'ai_analyzed', 'assigned', 'acknowledged'].includes(i.status)).length} icon={<Clock className="w-6 h-6" />} color="bg-amber-50 text-amber-600" />
        <StatCard label="Resolved" value={resolved.length} icon={<CheckCircle2 className="w-6 h-6" />} color="bg-emerald-50 text-emerald-600" />
        <StatCard label="SLA Breached" value={slaBreached} icon={<AlertTriangle className="w-6 h-6" />} color="bg-red-50 text-red-600" />
        <StatCard label="High Severity" value={highSeverity} icon={<AlertCircle className="w-6 h-6" />} color="bg-rose-50 text-rose-600" />
        <StatCard label="SLA Compliance" value={`${slaRate}%`} icon={<TrendingUp className="w-6 h-6" />} color="bg-blue-50 text-blue-600" />
      </div>

      {/* Charts Row 1 */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-4">Complaints Over Time (14 days)</h3>
          <ResponsiveContainer width="100%" height={250}>
            <AreaChart data={timeData}>
              <defs><linearGradient id="colorIssues" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#0d9488" stopOpacity={0.3} /><stop offset="95%" stopColor="#0d9488" stopOpacity={0} /></linearGradient></defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="day" tick={{ fontSize: 10 }} angle={-30} textAnchor="end" height={60} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Area type="monotone" dataKey="issues" stroke="#0d9488" fill="url(#colorIssues)" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-4">Issues by Category</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={catChart} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis type="number" tick={{ fontSize: 11 }} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 10 }} width={100} />
              <Tooltip />
              <Bar dataKey="value" fill="#0d9488" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Charts Row 2 */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-4">Issues by Ward</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={wardData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-30} textAnchor="end" height={60} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="issues" fill="#6366f1" radius={[4, 4, 0, 0]} />
              <Bar dataKey="resolved" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <h3 className="text-sm font-medium text-slate-500 mb-4">Department Workload</h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={deptData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
              <XAxis dataKey="name" tick={{ fontSize: 10 }} angle={-30} textAnchor="end" height={60} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="issues" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {/* Road Health Scores */}
      <Card>
        <h3 className="text-sm font-medium text-slate-500 mb-4">Road Health Scores by Ward</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {roadHealthData.map((ward) => (
            <div key={ward.name} className={classNames('p-4 rounded-xl border', ward.score >= 70 ? 'bg-emerald-50 border-emerald-200' : ward.score >= 50 ? 'bg-amber-50 border-amber-200' : 'bg-red-50 border-red-200')}>
              <p className="text-xs text-slate-500 mb-1">{ward.name}</p>
              <p className={classNames('text-2xl font-bold', ward.score >= 70 ? 'text-emerald-700' : ward.score >= 50 ? 'text-amber-700' : 'text-red-700')}>{ward.score}</p>
              <p className="text-xs text-slate-400">{ward.issues} issues</p>
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-400 mt-3">Note: Road Health Score is an analytical indicator based on complaint density, severity, and resolution rate. Not an official government rating.</p>
      </Card>

      {/* Heatmap */}
      <Card>
        <h3 className="text-sm font-medium text-slate-500 mb-3">Civic Issue Heatmap</h3>
        <IssueMap issues={issues.filter((i) => !['closed', 'verified'].includes(i.status))} height="400px" showHeatCircles />
      </Card>

      {/* High Priority Issues */}
      <Card>
        <h3 className="text-sm font-medium text-slate-500 mb-3">High Severity & SLA Breached Issues</h3>
        <div className="space-y-2">
          {issues.filter((i) => (i.severity === 'high' || i.sla_breached) && !['verified', 'closed'].includes(i.status)).slice(0, 10).map((issue) => (
            <div key={issue.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
              <span className="text-xs font-mono text-slate-500">{issue.complaint_id}</span>
              <span className="text-sm font-medium text-slate-900 flex-1 truncate">{issue.title}</span>
              {issue.severity === 'high' && <Badge className="bg-red-100 text-red-700 border-red-200">High</Badge>}
              {(i => i.sla_breached || (i.sla_deadline && isSlaBreached(i.sla_deadline)))(issue) && <Badge className="bg-orange-100 text-orange-700 border-orange-200">SLA Breached</Badge>}
              <span className="text-xs text-slate-400">{formatSlaRemaining(issue.sla_deadline)}</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
