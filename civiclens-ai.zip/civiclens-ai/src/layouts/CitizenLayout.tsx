import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { useAuth, getHomeRoute } from '@/lib/auth';
import { useI18n } from '@/lib/i18n';
import { Bell, Home, Plus, Map, FileText, User, LogOut, Menu, X, Globe } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { classNames } from '@/lib/utils';
import type { Language } from '@/lib/i18n';
import type { Notification } from '@/types';

export function CitizenLayout() {
  const { profile, signOut } = useAuth();
  const { t, language, setLanguage } = useI18n();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (!profile) return;
    const fetchUnread = async () => {
      const { count } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', profile.id)
        .eq('is_read', false);
      setUnreadCount(count || 0);
    };
    fetchUnread();
    const interval = setInterval(fetchUnread, 30000);
    return () => clearInterval(interval);
  }, [profile]);

  const navItems = [
    { to: '/dashboard', label: t('nav.dashboard'), icon: Home },
    { to: '/dashboard/report', label: t('nav.report'), icon: Plus },
    { to: '/dashboard/complaints', label: t('nav.complaints'), icon: FileText },
    { to: '/dashboard/map', label: t('nav.map'), icon: Map },
  ];

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Desktop header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-teal-600 flex items-center justify-center">
                <span className="text-white font-bold text-sm">CL</span>
              </div>
              <span className="font-bold text-slate-900 hidden sm:block">{t('app.name')}</span>
            </div>

            <nav className="hidden md:flex items-center gap-1">
              {navItems.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.to === '/dashboard'}
                  className={({ isActive }) =>
                    classNames(
                      'flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                      isActive ? 'bg-teal-50 text-teal-700' : 'text-slate-600 hover:bg-slate-100'
                    )
                  }
                >
                  <item.icon className="w-4 h-4" />
                  {item.label}
                </NavLink>
              ))}
            </nav>

            <div className="flex items-center gap-2">
              <LanguageSwitcher language={language} setLanguage={setLanguage} />
              <NavLink to="/dashboard/notifications" className="relative p-2 rounded-lg text-slate-600 hover:bg-slate-100">
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </NavLink>
              <NavLink to="/dashboard/profile" className="p-2 rounded-lg text-slate-600 hover:bg-slate-100 hidden sm:block">
                <User className="w-5 h-5" />
              </NavLink>
              <button onClick={handleSignOut} className="p-2 rounded-lg text-slate-600 hover:bg-slate-100" title={t('nav.logout')}>
                <LogOut className="w-5 h-5" />
              </button>
              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="md:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100">
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden border-t border-slate-200 bg-white">
            {navItems.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === '/dashboard'}
                onClick={() => setMobileMenuOpen(false)}
                className={({ isActive }) =>
                  classNames(
                    'flex items-center gap-3 px-4 py-3 text-sm font-medium border-b border-slate-100',
                    isActive ? 'bg-teal-50 text-teal-700' : 'text-slate-700'
                  )
                }
              >
                <item.icon className="w-5 h-5" />
                {item.label}
              </NavLink>
            ))}
          </div>
        )}
      </header>

      {/* Main content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-6 pb-24 md:pb-6">
        <Outlet />
      </main>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-30">
        <div className="flex items-center justify-around h-16">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.to === '/dashboard'}
              className={({ isActive }) =>
                classNames(
                  'flex flex-col items-center gap-1 px-2 py-1 text-xs font-medium',
                  isActive ? 'text-teal-600' : 'text-slate-500'
                )
              }
            >
              <item.icon className="w-5 h-5" />
              {item.label}
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}

function LanguageSwitcher({ language, setLanguage }: { language: Language; setLanguage: (l: Language) => void }) {
  const [open, setOpen] = useState(false);
  const languages: { code: Language; label: string }[] = [
    { code: 'en', label: 'English' },
    { code: 'te', label: 'తెలుగు' },
    { code: 'hi', label: 'हिन्दी' },
  ];

  return (
    <div className="relative">
      <button onClick={() => setOpen(!open)} className="p-2 rounded-lg text-slate-600 hover:bg-slate-100">
        <Globe className="w-5 h-5" />
      </button>
      {open && (
        <div className="absolute right-0 mt-1 w-32 bg-white rounded-lg shadow-lg border border-slate-200 py-1 z-50">
          {languages.map((lang) => (
            <button
              key={lang.code}
              onClick={() => { setLanguage(lang.code); setOpen(false); }}
              className={classNames(
                'block w-full text-left px-4 py-2 text-sm hover:bg-slate-50',
                language === lang.code ? 'text-teal-600 font-medium' : 'text-slate-700'
              )}
            >
              {lang.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
