import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, Spinner, PageHeader, Button } from '@/components/ui';
import { Clock, Save } from 'lucide-react';
import type { IssueCategory } from '@/types';

export function SlaConfig() {
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState<IssueCategory[]>([]);
  const [edited, setEdited] = useState<Record<string, { high: number; medium: number; low: number }>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const fetchCategories = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase.from('issue_categories').select('*').order('name');
    setCategories((data || []) as IssueCategory[]);
    setLoading(false);
  }, []);

  useEffect(() => { fetchCategories(); }, [fetchCategories]);

  const handleEdit = (catId: string, severity: 'high' | 'medium' | 'low', value: number) => {
    setEdited((prev) => ({
      ...prev,
      [catId]: { ...(prev[catId] || { high: 0, medium: 0, low: 0 }), [severity]: value },
    }));
  };

  const handleSave = async () => {
    setSaving(true);
    for (const [catId, slas] of Object.entries(edited)) {
      const cat = categories.find((c) => c.id === catId);
      if (!cat) continue;
      await supabase.from('issue_categories').update({
        default_sla_high_hours: slas.high || cat.default_sla_high_hours,
        default_sla_medium_hours: slas.medium || cat.default_sla_medium_hours,
        default_sla_low_hours: slas.low || cat.default_sla_low_hours,
      }).eq('id', catId);
    }
    setSaving(false);
    setSaved(true);
    setEdited({});
    setTimeout(() => setSaved(false), 3000);
    await fetchCategories();
  };

  if (loading) return <div className="flex justify-center py-20"><Spinner size="lg" /></div>;

  return (
    <div>
      <PageHeader title="SLA Configuration" subtitle="Configure target resolution times by category and severity">
        <Button onClick={handleSave} loading={saving} disabled={Object.keys(edited).length === 0}>
          <Save className="w-4 h-4" /> Save Changes
        </Button>
      </PageHeader>

      {saved && (
        <div className="mb-4 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm flex items-center gap-2">
          <Save className="w-4 h-4" /> SLA settings saved successfully.
        </div>
      )}

      <Card>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-200 text-left text-xs text-slate-500 uppercase">
                <th className="py-3 px-3 font-medium">Category</th>
                <th className="py-3 px-3 font-medium text-center">High (hours)</th>
                <th className="py-3 px-3 font-medium text-center">Medium (hours)</th>
                <th className="py-3 px-3 font-medium text-center">Low (hours)</th>
              </tr>
            </thead>
            <tbody>
              {categories.map((cat) => (
                <tr key={cat.id} className="border-b border-slate-100">
                  <td className="py-3 px-3">
                    <p className="text-sm font-medium text-slate-900">{cat.name}</p>
                    <p className="text-xs text-slate-500">{cat.description}</p>
                  </td>
                  <td className="py-3 px-3 text-center">
                    <input
                      type="number"
                      defaultValue={cat.default_sla_high_hours}
                      onChange={(e) => handleEdit(cat.id, 'high', parseInt(e.target.value) || 0)}
                      className="w-20 px-2 py-1 border border-slate-300 rounded text-sm text-center focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                  </td>
                  <td className="py-3 px-3 text-center">
                    <input
                      type="number"
                      defaultValue={cat.default_sla_medium_hours}
                      onChange={(e) => handleEdit(cat.id, 'medium', parseInt(e.target.value) || 0)}
                      className="w-20 px-2 py-1 border border-slate-300 rounded text-sm text-center focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                  </td>
                  <td className="py-3 px-3 text-center">
                    <input
                      type="number"
                      defaultValue={cat.default_sla_low_hours}
                      onChange={(e) => handleEdit(cat.id, 'low', parseInt(e.target.value) || 0)}
                      className="w-20 px-2 py-1 border border-slate-300 rounded text-sm text-center focus:outline-none focus:ring-2 focus:ring-teal-500"
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card className="mt-4">
        <div className="flex items-center gap-3">
          <Clock className="w-5 h-5 text-slate-400" />
          <div>
            <p className="text-sm font-medium text-slate-900">SLA Guidelines</p>
            <p className="text-xs text-slate-500">High severity (e.g., open manholes): 6-24 hours. Medium (e.g., potholes): 24-72 hours. Low (e.g., minor cracks): 72-168 hours (7 days).</p>
          </div>
        </div>
      </Card>
    </div>
  );
}
