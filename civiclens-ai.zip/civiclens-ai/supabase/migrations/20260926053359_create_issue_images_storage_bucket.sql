/*
# Create issue-images storage bucket

## Purpose
The citizen complaint submission flow uploads photos to a Supabase Storage
bucket named `issue-images`. The bucket and its storage policies were never
created, so `supabase.storage.from('issue-images').upload(...)` failed with
a "bucket not found" error, which aborted the entire complaint submission.

## Changes
1. Creates a PUBLIC storage bucket `issue-images` (public so complaint photos
   can be displayed via public URLs in `<img>` tags across the app).
2. Adds storage.object policies:
   - SELECT: anyone (anon + authenticated) can read complaint photos.
   - INSERT: authenticated users can upload photos to the bucket.

## Security
- Bucket is public for READ (photos are community-visible on the civic map).
- Only authenticated users can WRITE (upload) — no anonymous uploads.
- No UPDATE or DELETE policies are added here; existing table-level RLS on
  `issue_images` already governs row-level delete access.
*/

INSERT INTO storage.buckets (id, name, public)
VALUES ('issue-images', 'issue-images', true)
ON CONFLICT (id) DO NOTHING;

-- Allow anyone to read complaint images (public community map / detail pages)
DROP POLICY IF EXISTS "issue_images_select_public" ON storage.objects;
CREATE POLICY "issue_images_select_public" ON storage.objects
  FOR SELECT TO anon, authenticated
  USING (bucket_id = 'issue-images');

-- Allow authenticated citizens/officers to upload complaint images
DROP POLICY IF EXISTS "issue_images_insert_auth" ON storage.objects;
CREATE POLICY "issue_images_insert_auth" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'issue-images');
