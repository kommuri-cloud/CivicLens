import { useEffect, useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { Card, Badge, Spinner, EmptyState, PageHeader } from '@/components/ui';
import { IssueMap } from '@/components/IssueMap';
import { formatStatus, formatSeverity, severityColor, statusColor, formatTimeAgo, classNames } from '@/lib/utils';
import { MapPin, ChevronRight, Filter } from 'lucide-react';
import type { Issue } from '@/types';

export function CivicMap() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [filteredIssues, setFilteredIssues] = useState<Issue[]>([]);
  const [severityFilter, setSeverityFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const fetchIssues = useCallback(async () => {
    setLoading(true);
    const { data } = await supabase
      .from('issues')
      .select('*')
      .neq('status', 'closed')
      .order('created_at', { ascending: false });
    setIssues((data || []) as Issue[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchIssues();
  }, [fetchIssues]);

  useEffect(() => {
    let filtered = issues;
    if (severityFilter !== 'all') filtered = filtered.filter((i) => i.severity === severityFilter);
    if (statusFilter !== 'all') {
      if (statusFilter === 'active') filtered = filtered.filter((i) => !['resolved', 'verified', 'closed'].includes(i.status));
      else filtered = filtered.filter((i) => i.status === statusFilter);
    }
    setFilteredIssues(filtered);
  }, [issues, severityFilter, statusFilter]);

  return (
    <div>
      <PageHeader title="Civic Map" subtitle="View all reported civic issues in your area" />

      {loading ? (
        <div className="flex justify-center py-20"><Spinner size="lg" /></div>
      ) : (
        <div className="space-y-4">
          {/* Filters */}
          <div className="flex flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-slate-400" />
              <span className="text-sm text-slate-500">Severity:</span>
            </div>
            {['all', 'high', 'medium', 'low'].map((s) => (
              <button
                key={s}
                onClick={() => setSeverityFilter(s)}
                className={classNames(
                  'px-3 py-1 rounded-lg text-xs font-medium capitalize transition-colors',
                  severityFilter === s ? 'bg-teal-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                )}
              >
                {s}
              </button>
            ))}
            <div className="w-px h-6 bg-slate-200 mx-1" />
            {[
              { label: 'All', value: 'all' },
              { label: 'Active', value: 'active' },
              { label: 'In Progress', value: 'in_progress' },
              { label: 'Resolved', value: 'resolved' },
            ].map((f) => (
              <button
                key={f.value}
                onClick={() => setStatusFilter(f.value)}
                className={classNames(
                  'px-3 py-1 rounded-lg text-xs font-medium transition-colors',
                  statusFilter === f.value ? 'bg-teal-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
                )}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Map */}
          <IssueMap issues={filteredIssues} height="450px" showHeatCircles />

          {/* Issue List */}
          <div>
            <h2 className="text-lg font-semibold text-slate-900 mb-3">{filteredIssues.length} Issues</h2>
            {filteredIssues.length === 0 ? (
              <Card><EmptyState icon={<MapPin className="w-12 h-12" />} title="No issues found" description="No issues match your current filters." /></Card>
            ) : (
              <div className="grid sm:grid-cols-2 gap-3">
                {filteredIssues.map((issue) => (
                  <Card key={issue.id} className="hover:shadow-md transition-shadow cursor-pointer">
                    <div onClick={() => navigate(`/dashboard/complaints/${issue.id}`)} className="flex items-center gap-3">
                      <div className={classNames('w-2 h-10 rounded-full flex-shrink-0', issue.severity === 'high' ? 'bg-red-500' : issue.severity === 'medium' ? 'bg-amber-500' : 'bg-emerald-500')} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={severityColor(issue.severity)}>{formatSeverity(issue.severity)}</Badge>
                          <Badge className={statusColor(issue.status)}>{formatStatus(issue.status)}</Badge>
                        </div>
                        <p className="text-sm font-medium text-slate-900 truncate">{issue.title}</p>
                        <p className="text-xs text-slate-500">{issue.location_name} · {formatTimeAgo(issue.created_at)}</p>
                        {issue.supporter_count > 0 && <p className="text-xs text-teal-600">{issue.supporter_count} reports</p>}
                      </div>
                      <ChevronRight className="w-5 h-5 text-slate-400 flex-shrink-0" />
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
