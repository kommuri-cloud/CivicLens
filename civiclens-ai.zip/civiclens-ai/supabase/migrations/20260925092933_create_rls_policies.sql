/*
# CivicLens AI - Row Level Security Policies

## Overview
Enables role-based access control across all tables. Three roles:
- citizen: can read public/community issues, manage own complaints, support issues, verify repairs
- officer: can read/manage issues assigned to their department, update status, upload repair photos
- admin: full access to all tables for management

## Security Changes
- RLS policies on all 12 tables
- SECURITY DEFINER functions for privileged mutations (status changes, officer assignment, supporter increment)
- Column-level protections on sensitive fields (role, status, severity, supporter_count, sla fields)
*/

-- Helper: check if current user is admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'
  );
$$;

-- Helper: check if current user is officer
CREATE OR REPLACE FUNCTION is_officer()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'officer'
  );
$$;

-- Helper: check if current user is officer or admin
CREATE OR REPLACE FUNCTION is_staff()
RETURNS boolean
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('officer', 'admin')
  );
$$;

-- Helper: get current user's department
CREATE OR REPLACE FUNCTION my_department_id()
RETURNS uuid
LANGUAGE sql
SECURITY DEFINER SET search_path = public
AS $$
  SELECT department_id FROM profiles WHERE id = auth.uid();
$$;

-- ============ profiles policies ============
DROP POLICY IF EXISTS "profiles_select_own_or_staff" ON profiles;
CREATE POLICY "profiles_select_own_or_staff" ON profiles
  FOR SELECT TO authenticated
  USING (id = auth.uid() OR is_staff());

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles
  FOR UPDATE TO authenticated
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- Protect role column: only admins can change role via set_user_role function
REVOKE UPDATE ON profiles FROM authenticated;
GRANT UPDATE (full_name, phone) ON profiles TO authenticated;

-- ============ departments policies ============
DROP POLICY IF EXISTS "departments_select_all" ON departments;
CREATE POLICY "departments_select_all" ON departments
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "departments_modify_admin" ON departments;
CREATE POLICY "departments_modify_admin" ON departments
  FOR ALL TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

-- ============ wards policies ============
DROP POLICY IF EXISTS "wards_select_all" ON wards;
CREATE POLICY "wards_select_all" ON wards
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "wards_modify_admin" ON wards;
CREATE POLICY "wards_modify_admin" ON wards
  FOR ALL TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

-- ============ issue_categories policies ============
DROP POLICY IF EXISTS "categories_select_all" ON issue_categories;
CREATE POLICY "categories_select_all" ON issue_categories
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "categories_modify_admin" ON issue_categories;
CREATE POLICY "categories_modify_admin" ON issue_categories
  FOR ALL TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

-- ============ issues policies ============
-- Citizens can see their own issues + all community issues (public map)
DROP POLICY IF EXISTS "issues_select_all" ON issues;
CREATE POLICY "issues_select_all" ON issues
  FOR SELECT TO authenticated
  USING (true);

-- Citizens can insert issues (citizen_id defaults to auth.uid())
DROP POLICY IF EXISTS "issues_insert_own" ON issues;
CREATE POLICY "issues_insert_own" ON issues
  FOR INSERT TO authenticated
  WITH CHECK (citizen_id = auth.uid());

-- Citizens can update own issues (limited columns only - description, title, severity)
-- Officers can update issues in their department
-- Admins can update all issues
DROP POLICY IF EXISTS "issues_update_own_or_dept" ON issues;
CREATE POLICY "issues_update_own_or_dept" ON issues
  FOR UPDATE TO authenticated
  USING (
    citizen_id = auth.uid()
    OR (is_officer() AND (department_id = my_department_id() OR assigned_officer_id = auth.uid()))
    OR is_admin()
  )
  WITH CHECK (
    citizen_id = auth.uid()
    OR (is_officer() AND (department_id = my_department_id() OR assigned_officer_id = auth.uid()))
    OR is_admin()
  );

-- Only citizen who created or admin can delete
DROP POLICY IF EXISTS "issues_delete_own_or_admin" ON issues;
CREATE POLICY "issues_delete_own_or_admin" ON issues
  FOR DELETE TO authenticated
  USING (citizen_id = auth.uid() OR is_admin());

-- Protect sensitive columns from direct citizen writes
REVOKE UPDATE ON issues FROM authenticated;
GRANT UPDATE (title, description, severity) ON issues TO authenticated;

-- ============ issue_images policies ============
DROP POLICY IF EXISTS "images_select_all" ON issue_images;
CREATE POLICY "images_select_all" ON issue_images
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "images_insert_auth" ON issue_images;
CREATE POLICY "images_insert_auth" ON issue_images
  FOR INSERT TO authenticated
  WITH CHECK (true);

DROP POLICY IF EXISTS "images_delete_own_or_admin" ON issue_images;
CREATE POLICY "images_delete_own_or_admin" ON issue_images
  FOR DELETE TO authenticated
  USING (
    uploaded_by = auth.uid() OR is_admin()
  );

-- ============ issue_ai_analysis policies ============
DROP POLICY IF EXISTS "ai_analysis_select_all" ON issue_ai_analysis;
CREATE POLICY "ai_analysis_select_all" ON issue_ai_analysis
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "ai_analysis_insert_auth" ON issue_ai_analysis;
CREATE POLICY "ai_analysis_insert_auth" ON issue_ai_analysis
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- ============ issue_status_history policies ============
DROP POLICY IF EXISTS "history_select_all" ON issue_status_history;
CREATE POLICY "history_select_all" ON issue_status_history
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "history_insert_auth" ON issue_status_history;
CREATE POLICY "history_insert_auth" ON issue_status_history
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- ============ issue_supporters policies ============
DROP POLICY IF EXISTS "supporters_select_all" ON issue_supporters;
CREATE POLICY "supporters_select_all" ON issue_supporters
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "supporters_insert_own" ON issue_supporters;
CREATE POLICY "supporters_insert_own" ON issue_supporters
  FOR INSERT TO authenticated
  WITH CHECK (citizen_id = auth.uid());

DROP POLICY IF EXISTS "supporters_delete_own" ON issue_supporters;
CREATE POLICY "supporters_delete_own" ON issue_supporters
  FOR DELETE TO authenticated
  USING (citizen_id = auth.uid());

-- ============ issue_verifications policies ============
DROP POLICY IF EXISTS "verifications_select_all" ON issue_verifications;
CREATE POLICY "verifications_select_all" ON issue_verifications
  FOR SELECT TO authenticated
  USING (true);

DROP POLICY IF EXISTS "verifications_insert_own" ON issue_verifications;
CREATE POLICY "verifications_insert_own" ON issue_verifications
  FOR INSERT TO authenticated
  WITH CHECK (citizen_id = auth.uid());

-- ============ notifications policies ============
DROP POLICY IF EXISTS "notifications_select_own" ON notifications;
CREATE POLICY "notifications_select_own" ON notifications
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

DROP POLICY IF EXISTS "notifications_update_own" ON notifications;
CREATE POLICY "notifications_update_own" ON notifications
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

DROP POLICY IF EXISTS "notifications_insert_any" ON notifications;
CREATE POLICY "notifications_insert_any" ON notifications
  FOR INSERT TO authenticated
  WITH CHECK (true);

DROP POLICY IF EXISTS "notifications_delete_own" ON notifications;
CREATE POLICY "notifications_delete_own" ON notifications
  FOR DELETE TO authenticated
  USING (user_id = auth.uid());

-- ============ audit_logs policies ============
DROP POLICY IF EXISTS "audit_logs_select_staff" ON audit_logs;
CREATE POLICY "audit_logs_select_staff" ON audit_logs
  FOR SELECT TO authenticated
  USING (is_staff());

DROP POLICY IF EXISTS "audit_logs_insert_any" ON audit_logs;
CREATE POLICY "audit_logs_insert_any" ON audit_logs
  FOR INSERT TO authenticated
  WITH CHECK (true);

-- ============ SECURITY DEFINER: Change issue status ============
-- Officers/admins use this to change status with authorization check
CREATE OR REPLACE FUNCTION change_issue_status(
  p_issue_id uuid,
  p_new_status text,
  p_comment text DEFAULT ''
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_issue RECORD;
  v_old_status text;
  v_citizen_id uuid;
BEGIN
  SELECT status, citizen_id, department_id, assigned_officer_id INTO v_issue
  FROM issues WHERE id = p_issue_id;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Issue not found';
  END IF;
  
  v_old_status := v_issue.status;
  v_citizen_id := v_issue.citizen_id;
  
  -- Authorization: officer must be in the right department or assigned, or admin
  IF NOT is_admin()
    AND NOT (
      is_officer()
      AND (v_issue.department_id = my_department_id() OR v_issue.assigned_officer_id = auth.uid())
    )
  THEN
    RAISE EXCEPTION 'Not authorized to change this issue status';
  END IF;
  
  -- Update issue status
  UPDATE issues SET status = p_new_status WHERE id = p_issue_id;
  
  -- Set timestamps based on status
  IF p_new_status = 'resolved' THEN
    UPDATE issues SET resolved_at = now() WHERE id = p_issue_id;
  ELSIF p_new_status = 'verified' THEN
    UPDATE issues SET verified_at = now() WHERE id = p_issue_id;
  ELSIF p_new_status = 'closed' THEN
    UPDATE issues SET closed_at = now() WHERE id = p_issue_id;
  END IF;
  
  -- Insert status history
  INSERT INTO issue_status_history (issue_id, status, previous_status, changed_by, comment)
  VALUES (p_issue_id, p_new_status, v_old_status, auth.uid(), p_comment);
  
  -- Send notification to citizen
  INSERT INTO notifications (user_id, issue_id, type, title, message)
  VALUES (
    v_citizen_id,
    p_issue_id,
    'status_change',
    'Issue Status Updated',
    'Your complaint status has been updated to: ' || p_new_status
  );
END;
$$;

REVOKE EXECUTE ON FUNCTION change_issue_status FROM anon;
GRANT EXECUTE ON FUNCTION change_issue_status TO authenticated;

-- ============ SECURITY DEFINER: Assign officer to issue ============
CREATE OR REPLACE FUNCTION assign_issue_officer(
  p_issue_id uuid,
  p_officer_id uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_old_officer uuid;
BEGIN
  SELECT assigned_officer_id INTO v_old_officer FROM issues WHERE id = p_issue_id;
  
  IF NOT is_staff() THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;
  
  UPDATE issues SET assigned_officer_id = p_officer_id, status = 'assigned' WHERE id = p_issue_id;
  
  INSERT INTO issue_status_history (issue_id, status, previous_status, changed_by, comment)
  VALUES (p_issue_id, 'assigned', (SELECT status FROM issues WHERE id = p_issue_id), auth.uid(), 'Officer assigned');
  
  -- Notify the assigned officer
  INSERT INTO notifications (user_id, issue_id, type, title, message)
  VALUES (p_officer_id, p_issue_id, 'assignment', 'New Issue Assigned', 'A new issue has been assigned to you.');
  
  -- Notify the citizen
  INSERT INTO notifications (user_id, issue_id, type, title, message)
  SELECT citizen_id, p_issue_id, 'assignment', 'Issue Assigned', 'Your complaint has been assigned to an officer.'
  FROM issues WHERE id = p_issue_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION assign_issue_officer FROM anon;
GRANT EXECUTE ON FUNCTION assign_issue_officer TO authenticated;

-- ============ SECURITY DEFINER: Support an issue (increment count) ============
CREATE OR REPLACE FUNCTION support_issue(p_issue_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  -- Insert supporter record (unique constraint prevents duplicates)
  INSERT INTO issue_supporters (issue_id, citizen_id)
  VALUES (p_issue_id, auth.uid());
  
  -- Increment supporter count
  UPDATE issues SET supporter_count = supporter_count + 1 WHERE id = p_issue_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION support_issue FROM anon;
GRANT EXECUTE ON FUNCTION support_issue TO authenticated;

-- ============ SECURITY DEFINER: Set user role (admin only) ============
CREATE OR REPLACE FUNCTION set_user_role(p_user_id uuid, p_role text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;
  
  IF p_role NOT IN ('citizen', 'officer', 'admin') THEN
    RAISE EXCEPTION 'Invalid role';
  END IF;
  
  UPDATE profiles SET role = p_role WHERE id = p_user_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION set_user_role FROM anon;
GRANT EXECUTE ON FUNCTION set_user_role TO authenticated;

-- ============ SECURITY DEFINER: Assign officer department/ward (admin only) ============
CREATE OR REPLACE FUNCTION set_officer_assignment(
  p_officer_id uuid,
  p_department_id uuid,
  p_ward_id uuid
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;
  
  UPDATE profiles
  SET department_id = p_department_id, ward_id = p_ward_id
  WHERE id = p_officer_id;
END;
$$;

REVOKE EXECUTE ON FUNCTION set_officer_assignment FROM anon;
GRANT EXECUTE ON FUNCTION set_officer_assignment TO authenticated;

-- ============ SECURITY DEFINER: Verify issue (citizen) ============
CREATE OR REPLACE FUNCTION verify_issue(
  p_issue_id uuid,
  p_is_fixed boolean,
  p_reason text DEFAULT '',
  p_image_url text DEFAULT NULL
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  v_citizen_id uuid;
BEGIN
  SELECT citizen_id INTO v_citizen_id FROM issues WHERE id = p_issue_id;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Issue not found';
  END IF;
  
  -- Only the citizen who reported can verify
  IF auth.uid() != v_citizen_id THEN
    RAISE EXCEPTION 'Only the reporting citizen can verify this issue';
  END IF;
  
  -- Insert verification record
  INSERT INTO issue_verifications (issue_id, citizen_id, is_fixed, reason, verification_image_url)
  VALUES (p_issue_id, auth.uid(), p_is_fixed, p_reason, p_image_url);
  
  -- Update issue status
  IF p_is_fixed THEN
    UPDATE issues SET status = 'verified', verified_at = now() WHERE id = p_issue_id;
    INSERT INTO issue_status_history (issue_id, status, previous_status, changed_by, comment)
    VALUES (p_issue_id, 'verified', 'citizen_verification', auth.uid(), 'Citizen confirmed issue is fixed');
  ELSE
    UPDATE issues SET status = 'reopened' WHERE id = p_issue_id;
    INSERT INTO issue_status_history (issue_id, status, previous_status, changed_by, comment)
    VALUES (p_issue_id, 'reopened', 'citizen_verification', auth.uid(), COALESCE(p_reason, 'Citizen reported issue still exists'));
  END IF;
END;
$$;

REVOKE EXECUTE ON FUNCTION verify_issue FROM anon;
GRANT EXECUTE ON FUNCTION verify_issue TO authenticated;
