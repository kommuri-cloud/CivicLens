import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';

export type Language = 'en' | 'te' | 'hi';

interface TranslationKey {
  [key: string]: string;
}

const translations: Record<Language, TranslationKey> = {
  en: {
    'app.name': 'CivicLens AI',
    'app.tagline': 'Turn Civic Problems Into Action',
    'nav.dashboard': 'Dashboard',
    'nav.report': 'Report Issue',
    'nav.complaints': 'My Complaints',
    'nav.map': 'Civic Map',
    'nav.notifications': 'Notifications',
    'nav.profile': 'Profile',
    'nav.logout': 'Logout',
    'nav.login': 'Login',
    'nav.register': 'Register',
    'nav.officerDashboard': 'Officer Dashboard',
    'nav.adminDashboard': 'Admin Dashboard',
    'action.report': 'Report an Issue',
    'action.viewMap': 'View Civic Map',
    'action.support': 'Support',
    'action.verify': 'Verify',
    'label.totalComplaints': 'Total Complaints',
    'label.pending': 'Pending',
    'label.inProgress': 'In Progress',
    'label.resolved': 'Resolved',
    'label.reopened': 'Reopened',
    'label.slaBreached': 'SLA Breached',
    'label.highSeverity': 'High Severity',
    'label.nearbyIssues': 'Nearby Civic Issues',
    'label.complaintId': 'Complaint ID',
    'label.issueType': 'Issue Type',
    'label.severity': 'Severity',
    'label.department': 'Department',
    'label.location': 'Location',
    'label.status': 'Status',
    'label.reportedDate': 'Reported Date',
    'label.assignedOfficer': 'Assigned Officer',
    'label.sla': 'SLA',
    'label.actions': 'Actions',
    'label.ward': 'Ward',
    'label.citizen': 'Citizen',
    'label.aiConfidence': 'AI Confidence',
    'label.description': 'Description',
    'label.timeline': 'Timeline',
    'label.images': 'Images',
    'label.aiAnalysis': 'AI Analysis',
    'label.detectedIssue': 'Detected Issue',
    'label.confidence': 'Confidence',
    'label.suggestedDepartment': 'Suggested Department',
    'label.submitNew': 'Submit New Complaint',
    'label.supportExisting': 'Support Existing Issue',
    'label.duplicateDetected': 'Possible duplicate detected',
    'msg.noComplaints': 'No complaints found',
    'msg.loading': 'Loading...',
    'msg.error': 'Something went wrong',
  },
  te: {
    'app.name': 'సివిక్‌లెన్స్ AI',
    'app.tagline': 'పౌర సమస్యలను చర్యగా మార్చండి',
    'nav.dashboard': 'డాష్‌బోర్డ్',
    'nav.report': 'సమస్యను నివేదించండి',
    'nav.complaints': 'నా ఫిర్యాదులు',
    'nav.map': 'సివిక్ మ్యాప్',
    'nav.notifications': 'నోటిఫికేషన్లు',
    'nav.profile': 'ప్రొఫైల్',
    'nav.logout': 'లాగ్ అవుట్',
    'nav.login': 'లాగిన్',
    'nav.register': 'నమోదు',
    'nav.officerDashboard': 'అధికారి డాష్‌బోర్డ్',
    'nav.adminDashboard': 'అడ్మిన్ డాష్‌బోర్డ్',
    'action.report': 'సమస్యను నివేదించండి',
    'action.viewMap': 'సివిక్ మ్యాప్ చూడండి',
    'action.support': 'మద్దతు',
    'action.verify': 'ధృవీకరించండి',
    'label.totalComplaints': 'మొత్తం ఫిర్యాదులు',
    'label.pending': 'పెండింగ్',
    'label.inProgress': 'ప్రోగ్రెస్‌లో',
    'label.resolved': 'పరిష్కరించబడింది',
    'label.reopened': 'తిరిగి తెరవబడింది',
    'label.slaBreached': 'SLA ఉల్లంఘన',
    'label.highSeverity': 'అధిక తీవ్రత',
    'label.nearbyIssues': 'సమీపంలోని సివిక్ సమస్యలు',
    'label.complaintId': 'ఫిర్యాద ID',
    'label.issueType': 'సమస్య రకం',
    'label.severity': 'తీవ్రత',
    'label.department': 'విభాగం',
    'label.location': 'స్థానం',
    'label.status': 'స్థితి',
    'label.reportedDate': 'నివేదిక తేదీ',
    'label.assignedOfficer': 'కేటాయించిన అధికారి',
    'label.sla': 'SLA',
    'label.actions': 'చర్యలు',
    'label.ward': 'వార్డ్',
    'label.citizen': 'పౌరుడు',
    'label.aiConfidence': 'AI విశ్వాసం',
    'label.description': 'వివరణ',
    'label.timeline': 'కాలక్రమం',
    'label.images': 'చిత్రాలు',
    'label.aiAnalysis': 'AI విశ్లేషణ',
    'label.detectedIssue': 'గుర్తించిన సమస్య',
    'label.confidence': 'విశ్వాసం',
    'label.suggestedDepartment': 'సూచించిన విభాగం',
    'label.submitNew': 'కొత్త ఫిర్యాదు సమర్పించండి',
    'label.supportExisting': 'ఉన్న సమస్యను మద్దతించండి',
    'label.duplicateDetected': 'నకిలీ గుర్తించబడింది',
    'msg.noComplaints': 'ఫిర్యాదులు కనుగొనబడలేదు',
    'msg.loading': 'లోడ్ అవుతోంది...',
    'msg.error': 'ఏదో తప్పు జరిగింది',
  },
  hi: {
    'app.name': 'सिविकलेंस AI',
    'app.tagline': 'नागरिक समस्याओं को कार्रवाई में बदलें',
    'nav.dashboard': 'डैशबोर्ड',
    'nav.report': 'समस्या की रिपोर्ट करें',
    'nav.complaints': 'मेरी शिकायतें',
    'nav.map': 'सिविक मानचित्र',
    'nav.notifications': 'सूचनाएं',
    'nav.profile': 'प्रोफ़ाइल',
    'nav.logout': 'लॉग आउट',
    'nav.login': 'लॉगिन',
    'nav.register': 'पंजीकरण',
    'nav.officerDashboard': 'अधिकारी डैशबोर्ड',
    'nav.adminDashboard': 'व्यवस्थापक डैशबोर्ड',
    'action.report': 'समस्या की रिपोर्ट करें',
    'action.viewMap': 'सिविक मानचित्र देखें',
    'action.support': 'समर्थन',
    'action.verify': 'सत्यापित करें',
    'label.totalComplaints': 'कुल शिकायतें',
    'label.pending': 'लंबित',
    'label.inProgress': 'प्रगति पर',
    'label.resolved': 'हल हो गया',
    'label.reopened': 'पुनः खोला गया',
    'label.slaBreached': 'SLA उल्लंघन',
    'label.highSeverity': 'उच्च गंभीरता',
    'label.nearbyIssues': 'निकटवर्ती नागरिक समस्याएं',
    'label.complaintId': 'शिकायत ID',
    'label.issueType': 'समस्या प्रकार',
    'label.severity': 'गंभीरता',
    'label.department': 'विभाग',
    'label.location': 'स्थान',
    'label.status': 'स्थिति',
    'label.reportedDate': 'रिपोर्ट तिथि',
    'label.assignedOfficer': 'नियुक्त अधिकारी',
    'label.sla': 'SLA',
    'label.actions': 'कार्रवाई',
    'label.ward': 'वार्ड',
    'label.citizen': 'नागरिक',
    'label.aiConfidence': 'AI विश्वास',
    'label.description': 'विवरण',
    'label.timeline': 'समयरेखा',
    'label.images': 'छवियां',
    'label.aiAnalysis': 'AI विश्लेषण',
    'label.detectedIssue': 'पहचानी गई समस्या',
    'label.confidence': 'विश्वास',
    'label.suggestedDepartment': 'सुझाया गया विभाग',
    'label.submitNew': 'नई शिकायत दर्ज करें',
    'label.supportExisting': 'मौजूदा समस्या का समर्थन करें',
    'label.duplicateDetected': 'संभावित डुप्लिकेट पाया गया',
    'msg.noComplaints': 'कोई शिकायत नहीं मिली',
    'msg.loading': 'लोड हो रहा है...',
    'msg.error': 'कुछ गलत हो गया',
  },
};

interface I18nContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('civiclens-language') as Language | null;
    return saved || 'en';
  });

  const handleSetLanguage = useCallback((lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('civiclens-language', lang);
  }, []);

  const t = useCallback(
    (key: string) => {
      return translations[language]?.[key] || translations.en[key] || key;
    },
    [language]
  );

  return (
    <I18nContext.Provider value={{ language, setLanguage: handleSetLanguage, t }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n must be used within I18nProvider');
  return ctx;
}
