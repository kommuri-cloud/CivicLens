import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';
import { aiService } from '@/services/ai';
import { detectDuplicates, supportIssue } from '@/services/ai/duplicate-detection';
import { Card, Button, Badge, Spinner } from '@/components/ui';
import { IssueMap } from '@/components/IssueMap';
import { formatSeverity, severityColor, classNames } from '@/lib/utils';
import type { IssueCategory, Department, Ward, Severity, DuplicateDetectionResult, AiAnalysisResult } from '@/types';
import {
  Camera, Upload, Brain, MapPin, Users, CheckCircle2, AlertCircle,
  ChevronRight, ChevronLeft, FileText, Clock, Building2, RefreshCw, X,
} from 'lucide-react';

const STEPS = ['Capture', 'AI Analysis', 'Location', 'Duplicate Check', 'Submit'];

export function ReportIssue() {
  const { profile } = useAuth();
  const navigate = useNavigate();

  const [step, setStep] = useState(0);
  const [categories, setCategories] = useState<IssueCategory[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [wards, setWards] = useState<Ward[]>([]);

  // Step 1: Image
  const [images, setImages] = useState<File[]>([]);
  const [imagePreviews, setImagePreviews] = useState<string[]>([]);

  // Step 2: AI Analysis
  const [aiLoading, setAiLoading] = useState(false);
  const [aiResult, setAiResult] = useState<AiAnalysisResult | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [description, setDescription] = useState('');
  const [severity, setSeverity] = useState<Severity>('medium');

  // Step 3: Location
  const [latitude, setLatitude] = useState<number | null>(null);
  const [longitude, setLongitude] = useState<number | null>(null);
  const [locationName, setLocationName] = useState('');
  const [selectedWard, setSelectedWard] = useState<string>('');
  const [locationDenied, setLocationDenied] = useState(false);

  // Step 4: Duplicates
  const [duplicates, setDuplicates] = useState<DuplicateDetectionResult[]>([]);
  const [dupLoading, setDupLoading] = useState(false);

  // Step 5: Submit
  const [submitting, setSubmitting] = useState(false);
  const [submittedId, setSubmittedId] = useState<string | null>(null);

  useEffect(() => {
    const fetchMeta = async () => {
      const [{ data: cats }, { data: depts }, { data: w }] = await Promise.all([
        supabase.from('issue_categories').select('*').eq('is_active', true).order('name'),
        supabase.from('departments').select('*').order('name'),
        supabase.from('wards').select('*').order('number'),
      ]);
      setCategories((cats || []) as IssueCategory[]);
      setDepartments((depts || []) as Department[]);
      setWards((w || []) as Ward[]);
    };
    fetchMeta();
  }, []);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    setImages((prev) => [...prev, ...files].slice(0, 5));
    const previews = files.map((f) => URL.createObjectURL(f));
    setImagePreviews((prev) => [...prev, ...previews].slice(0, 5));
  };

  const removeImage = (index: number) => {
    setImages((prev) => prev.filter((_, i) => i !== index));
    setImagePreviews((prev) => prev.filter((_, i) => i !== index));
  };

  const runAiAnalysis = async () => {
    if (images.length === 0) return;
    setAiLoading(true);
    const result = await aiService.analyzeImage({
      name: images[0].name,
      size: images[0].size,
      type: images[0].type,
      dataUrl: imagePreviews[0],
    });
    setAiResult(result);
    const matchedCat = categories.find((c) => c.name === result.detected_category);
    if (matchedCat) setSelectedCategory(matchedCat.id);
    setSeverity(result.estimated_severity);
    setDescription(result.ai_description);
    setAiLoading(false);
  };

  const detectLocation = useCallback(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLatitude(pos.coords.latitude);
          setLongitude(pos.coords.longitude);
          setLocationName('Current location detected');

          // Find nearest ward
          let nearestWard = '';
          let minDist = Infinity;
          for (const ward of wards) {
            // Use ward center approximation - in real app, wards would have polygon data
            // For demo, we assign ward based on area proximity
            const wardLat = 16.5062 + (ward.number - 6) * 0.005;
            const wardLng = 80.648 + (ward.number - 6) * 0.005;
            const dist = Math.sqrt(
              Math.pow(pos.coords.latitude - wardLat, 2) +
              Math.pow(pos.coords.longitude - wardLng, 2)
            );
            if (dist < minDist) {
              minDist = dist;
              nearestWard = ward.id;
            }
          }
          if (nearestWard) setSelectedWard(nearestWard);
        },
        () => {
          setLocationDenied(true);
          // Fallback to Vijayawada center
          setLatitude(16.5062);
          setLongitude(80.648);
          setLocationName('Vijayawada (default)');
        },
        { timeout: 5000 }
      );
    }
  }, [wards]);

  useEffect(() => {
    if (step === 2 && latitude === null) {
      detectLocation();
    }
  }, [step, latitude, detectLocation]);

  const checkDuplicates = async () => {
    if (!latitude || !longitude || !selectedCategory) return;
    setDupLoading(true);
    const dups = await detectDuplicates(latitude, longitude, selectedCategory, 500);
    setDuplicates(dups);
    setDupLoading(false);
  };

  useEffect(() => {
    if (step === 3) {
      checkDuplicates();
    }
  }, [step]);

  const handleSupportExisting = async (issueId: string) => {
    const result = await supportIssue(issueId);
    if (result.success) {
      navigate(`/dashboard/complaints/${issueId}`);
    } else {
      alert(result.error || 'Could not support this issue.');
    }
  };

  const handleSubmit = async () => {
    if (!profile || !latitude || !longitude || !selectedCategory) return;
    setSubmitting(true);

    let operation = 'starting submission';

    try {
      // Generate complaint ID
      operation = 'generating complaint ID';
      const { data: complaintId, error: complaintIdError } = await supabase.rpc('generate_complaint_id');
      if (complaintIdError) throw complaintIdError;
      if (!complaintId) throw new Error('Complaint ID was not returned.');

      // Find the department for the selected category
      const category = categories.find((c) => c.id === selectedCategory);
      const departmentId = category?.default_department_id || departments[0]?.id;

      // Calculate SLA deadline
      operation = 'calculating SLA deadline';
      const { data: slaDeadline, error: slaError } = await supabase.rpc('calculate_sla_deadline', {
        p_category_id: selectedCategory,
        p_severity: severity,
      });
      if (slaError) throw slaError;

      // Insert the issue (include AI fields up-front since citizens lack UPDATE
      // permission on status/ai_confidence/ai_analyzed_at columns)
      const issueRow: Record<string, unknown> = {
        complaint_id: complaintId,
        citizen_id: profile.id,
        category_id: selectedCategory,
        department_id: departmentId,
        ward_id: selectedWard || null,
        title: description.substring(0, 80) || category?.name || 'Civic Issue',
        description,
        severity,
        status: aiResult ? 'ai_analyzed' : 'submitted',
        latitude,
        longitude,
        location_name: locationName,
        municipality: 'Vijayawada',
        sla_deadline: slaDeadline,
      };
      if (aiResult) {
        issueRow.ai_confidence = aiResult.confidence;
        issueRow.ai_analyzed_at = new Date().toISOString();
      }

      operation = 'creating complaint';
      const { data: issue, error } = await supabase
        .from('issues')
        .insert(issueRow)
        .select()
        .single();

      if (error) throw error;
      if (!issue) throw new Error('Complaint was not returned after creation.');

      // Insert status history
      operation = 'recording submitted status';
      const { error: submittedHistoryError } = await supabase.from('issue_status_history').insert({
        issue_id: issue.id,
        status: 'submitted',
        changed_by: profile.id,
        comment: 'Issue reported by citizen',
      });
      if (submittedHistoryError) throw submittedHistoryError;

      // Insert AI analysis record + ai_analyzed status history
      if (aiResult) {
        operation = 'saving AI analysis';
        const { error: aiError } = await supabase.from('issue_ai_analysis').insert({
          issue_id: issue.id,
          detected_category: aiResult.detected_category,
          confidence: aiResult.confidence,
          estimated_severity: aiResult.estimated_severity,
          suggested_department: aiResult.suggested_department,
          ai_description: aiResult.ai_description,
        });
        if (aiError) throw aiError;

        operation = 'recording AI analyzed status';
        const { error: aiHistoryError } = await supabase.from('issue_status_history').insert({
          issue_id: issue.id,
          status: 'ai_analyzed',
          previous_status: 'submitted',
          changed_by: profile.id,
          comment: `AI analysis: ${aiResult.detected_category} (${aiResult.confidence}% confidence)`,
        });
        if (aiHistoryError) throw aiHistoryError;
      }

      // Upload images
      for (let i = 0; i < images.length; i++) {
        const file = images[i];
        const fileName = `${issue.id}/${Date.now()}-${i}.jpg`;
        operation = `uploading image ${i + 1}`;
        const { error: uploadError } = await supabase.storage.from('issue-images').upload(fileName, file);
        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage.from('issue-images').getPublicUrl(fileName);
        operation = `saving image ${i + 1} reference`;
        const { error: imageReferenceError } = await supabase.from('issue_images').insert({
          issue_id: issue.id,
          image_url: urlData.publicUrl,
          image_type: 'citizen',
          uploaded_by: profile.id,
        });
        if (imageReferenceError) throw imageReferenceError;
      }

      // Create notification
      operation = 'creating submission notification';
      const { error: notificationError } = await supabase.from('notifications').insert({
        user_id: profile.id,
        issue_id: issue.id,
        type: 'submission',
        title: 'Issue Reported Successfully',
        message: `Your complaint ${complaintId} has been submitted and is being processed.`,
      });
      if (notificationError) throw notificationError;

      setSubmittedId(complaintId);
    } catch (err) {
      const errorInfo = err && typeof err === 'object' && 'code' in err
        ? {
            operation,
            message: (err as { message?: string }).message,
            code: (err as { code?: string }).code,
            details: (err as { details?: string }).details,
            hint: (err as { hint?: string }).hint,
          }
        : { operation, message: err instanceof Error ? err.message : String(err) };
      console.error('Complaint submission failed:', errorInfo);
      alert('Could not submit your complaint. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  // Success screen
  if (submittedId) {
    const category = categories.find((c) => c.id === selectedCategory);
    const department = departments.find((d) => d.id === category?.default_department_id);
    const ward = wards.find((w) => w.id === selectedWard);

    return (
      <div className="max-w-2xl mx-auto py-8">
        <Card className="text-center py-12">
          <div className="w-16 h-16 rounded-full bg-emerald-100 flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="w-8 h-8 text-emerald-600" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mb-2">Complaint Submitted!</h1>
          <p className="text-slate-500 mb-6">Your civic issue has been reported successfully.</p>

          <div className="bg-slate-50 rounded-xl p-6 text-left space-y-3 mb-6">
            <div className="flex justify-between"><span className="text-sm text-slate-500">Complaint ID:</span><span className="text-sm font-mono font-bold text-teal-600">{submittedId}</span></div>
            <div className="flex justify-between"><span className="text-sm text-slate-500">Issue Type:</span><span className="text-sm font-medium text-slate-900">{category?.name || 'Unknown'}</span></div>
            <div className="flex justify-between"><span className="text-sm text-slate-500">Location:</span><span className="text-sm font-medium text-slate-900">{locationName}</span></div>
            <div className="flex justify-between"><span className="text-sm text-slate-500">Ward:</span><span className="text-sm font-medium text-slate-900">{ward?.name || 'Unassigned'}</span></div>
            <div className="flex justify-between"><span className="text-sm text-slate-500">Severity:</span><Badge className={severityColor(severity)}>{formatSeverity(severity)}</Badge></div>
            <div className="flex justify-between"><span className="text-sm text-slate-500">Department:</span><span className="text-sm font-medium text-slate-900">{department?.name || 'Unassigned'}</span></div>
            <div className="flex justify-between"><span className="text-sm text-slate-500">Status:</span><span className="text-sm font-medium text-slate-900">AI Analyzed</span></div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button onClick={() => navigate('/dashboard/complaints')}>
              View My Complaints
            </Button>
            <Button variant="outline" onClick={() => navigate('/dashboard')}>
              Back to Dashboard
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      {/* Step indicator */}
      <div className="flex items-center justify-between mb-8">
        {STEPS.map((s, i) => (
          <div key={i} className="flex items-center flex-1">
            <div className={classNames(
              'flex items-center justify-center w-9 h-9 rounded-full text-sm font-medium flex-shrink-0',
              i < step ? 'bg-teal-600 text-white' : i === step ? 'bg-teal-600 text-white ring-4 ring-teal-100' : 'bg-slate-100 text-slate-400'
            )}>
              {i < step ? <CheckCircle2 className="w-5 h-5" /> : i + 1}
            </div>
            <span className={classNames('ml-2 text-sm font-medium hidden sm:block', i <= step ? 'text-slate-900' : 'text-slate-400')}>{s}</span>
            {i < STEPS.length - 1 && <div className={classNames('h-0.5 flex-1 mx-2', i < step ? 'bg-teal-600' : 'bg-slate-200')} />}
          </div>
        ))}
      </div>

      {/* Step 1: Capture */}
      {step === 0 && (
        <Card>
          <h2 className="text-lg font-semibold text-slate-900 mb-1">Step 1: Capture or Upload</h2>
          <p className="text-sm text-slate-500 mb-6">Take a photo of the civic issue or upload an existing image.</p>

          <label className="block border-2 border-dashed border-slate-300 rounded-xl p-8 text-center cursor-pointer hover:border-teal-400 hover:bg-teal-50/30 transition-colors mb-4">
            <input type="file" accept="image/*" capture="environment" multiple onChange={handleImageUpload} className="hidden" />
            <Camera className="w-10 h-10 text-slate-400 mx-auto mb-3" />
            <p className="text-sm font-medium text-slate-700">Take a photo or upload images</p>
            <p className="text-xs text-slate-400 mt-1">JPG, PNG up to 5 images</p>
          </label>

          {imagePreviews.length > 0 && (
            <div className="grid grid-cols-3 gap-3 mb-4">
              {imagePreviews.map((preview, i) => (
                <div key={i} className="relative group">
                  <img src={preview} alt={`Upload ${i + 1}`} className="w-full h-24 object-cover rounded-lg border border-slate-200" />
                  <button
                    onClick={() => removeImage(i)}
                    className="absolute top-1 right-1 w-6 h-6 rounded-full bg-red-500 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <div className="flex justify-between">
            <Button variant="outline" onClick={() => navigate('/dashboard')}>
              <ChevronLeft className="w-4 h-4" /> Cancel
            </Button>
            <Button onClick={() => setStep(1)} disabled={images.length === 0}>
              Next <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </Card>
      )}

      {/* Step 2: AI Analysis */}
      {step === 1 && (
        <Card>
          <h2 className="text-lg font-semibold text-slate-900 mb-1">Step 2: AI Analysis</h2>
          <p className="text-sm text-slate-500 mb-6">AI is analyzing your image. You can review and correct the results.</p>

          {aiLoading ? (
            <div className="flex flex-col items-center py-12">
              <Spinner size="lg" />
              <p className="text-sm text-slate-500 mt-4">Analyzing image...</p>
            </div>
          ) : aiResult ? (
            <div className="space-y-4">
              <div className="bg-teal-50 rounded-xl p-4 border border-teal-100">
                <div className="flex items-center gap-2 mb-3">
                  <Brain className="w-5 h-5 text-teal-600" />
                  <span className="font-medium text-teal-900">AI Analysis Result</span>
                </div>
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div><span className="text-slate-500">Detected Issue:</span> <span className="font-medium text-slate-900">{aiResult.detected_category}</span></div>
                  <div><span className="text-slate-500">Confidence:</span> <span className="font-medium text-teal-600">{aiResult.confidence}%</span></div>
                  <div><span className="text-slate-500">Severity:</span> <span className="font-medium text-slate-900">{formatSeverity(aiResult.estimated_severity)}</span></div>
                  <div><span className="text-slate-500">Department:</span> <span className="font-medium text-slate-900">{aiResult.suggested_department}</span></div>
                </div>
                <p className="text-sm text-slate-600 mt-3 pt-3 border-t border-teal-100">{aiResult.ai_description}</p>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Category (editable)</label>
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                  >
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>{cat.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Description (editable)</label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={3}
                    className="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1.5">Severity (editable)</label>
                  <div className="flex gap-2">
                    {(['high', 'medium', 'low'] as Severity[]).map((sev) => (
                      <button
                        key={sev}
                        onClick={() => setSeverity(sev)}
                        className={classNames(
                          'flex-1 py-2 px-3 rounded-lg text-sm font-medium border transition-colors',
                          severity === sev ? severityColor(sev) + ' ring-2 ring-offset-1' : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                        )}
                      >
                        {formatSeverity(sev)}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-2">
                <Button variant="outline" onClick={() => setStep(0)}><ChevronLeft className="w-4 h-4" /> Back</Button>
                <Button onClick={() => setStep(2)}>Next <ChevronRight className="w-4 h-4" /></Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <Button onClick={runAiAnalysis} loading={aiLoading}>
                <Brain className="w-5 h-5" /> Run AI Analysis
              </Button>
            </div>
          )}
        </Card>
      )}

      {/* Step 3: Location */}
      {step === 2 && (
        <Card>
          <h2 className="text-lg font-semibold text-slate-900 mb-1">Step 3: Location</h2>
          <p className="text-sm text-slate-500 mb-6">Confirm the location of the issue.</p>

          {latitude !== null && longitude !== null ? (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="p-3 bg-slate-50 rounded-lg">
                  <p className="text-xs text-slate-500">Latitude</p>
                  <p className="font-medium text-slate-900">{latitude.toFixed(6)}</p>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg">
                  <p className="text-xs text-slate-500">Longitude</p>
                  <p className="font-medium text-slate-900">{longitude.toFixed(6)}</p>
                </div>
                <div className="p-3 bg-slate-50 rounded-lg col-span-2">
                  <p className="text-xs text-slate-500">Location</p>
                  <p className="font-medium text-slate-900">{locationName}</p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">Ward</label>
                <select
                  value={selectedWard}
                  onChange={(e) => setSelectedWard(e.target.value)}
                  className="w-full px-3 py-2.5 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
                >
                  <option value="">Select ward</option>
                  {wards.map((w) => (
                    <option key={w.id} value={w.id}>{w.name}</option>
                  ))}
                </select>
              </div>

              <IssueMap
                singleMarker={{ lat: latitude, lng: longitude, label: locationName }}
                height="300px"
              />

              {locationDenied && (
                <div className="flex items-center gap-2 p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-700 text-sm">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  Using default location. Enable location access for precise reporting.
                </div>
              )}

              <div className="flex justify-between">
                <Button variant="outline" onClick={() => setStep(1)}><ChevronLeft className="w-4 h-4" /> Back</Button>
                <Button onClick={() => setStep(3)}>Next <ChevronRight className="w-4 h-4" /></Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <Spinner />
              <p className="text-sm text-slate-500 mt-4">Detecting your location...</p>
              <Button variant="outline" size="sm" className="mt-4" onClick={detectLocation}>
                <RefreshCw className="w-4 h-4" /> Retry
              </Button>
            </div>
          )}
        </Card>
      )}

      {/* Step 4: Duplicate Check */}
      {step === 3 && (
        <Card>
          <h2 className="text-lg font-semibold text-slate-900 mb-1">Step 4: Duplicate Check</h2>
          <p className="text-sm text-slate-500 mb-6">Checking for nearby existing complaints.</p>

          {dupLoading ? (
            <div className="flex flex-col items-center py-12">
              <Spinner size="lg" />
              <p className="text-sm text-slate-500 mt-4">Searching for duplicates...</p>
            </div>
          ) : duplicates.length > 0 ? (
            <div className="space-y-4">
              <div className="flex items-center gap-2 p-3 rounded-lg bg-amber-50 border border-amber-200 text-amber-700 text-sm">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                Possible duplicate detected. A similar issue has already been reported nearby.
              </div>

              {duplicates.map((dup) => (
                <div key={dup.issue.id} className="border border-slate-200 rounded-xl p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <p className="font-medium text-slate-900">{dup.issue.title}</p>
                      <p className="text-sm text-slate-500">{dup.issue.location_name}</p>
                    </div>
                    <Badge className={severityColor(dup.issue.severity)}>{formatSeverity(dup.issue.severity)}</Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-sm mb-4">
                    <div><span className="text-slate-500">Distance:</span> <span className="font-medium text-slate-900">{dup.distance_meters}m</span></div>
                    <div><span className="text-slate-500">Reports:</span> <span className="font-medium text-slate-900">{dup.issue.supporter_count + 1}</span></div>
                    <div><span className="text-slate-500">Status:</span> <span className="font-medium text-slate-900 capitalize">{dup.issue.status.replace(/_/g, ' ')}</span></div>
                  </div>
                  <Button variant="outline" size="sm" fullWidth onClick={() => handleSupportExisting(dup.issue.id)}>
                    <Users className="w-4 h-4" /> Support Existing Issue
                  </Button>
                </div>
              ))}

              <div className="pt-2">
                <p className="text-sm text-slate-500 text-center mb-3">or</p>
                <Button fullWidth onClick={() => setStep(4)}>
                  Submit New Complaint <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-2 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm">
                <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                No duplicates found. You can submit a new complaint.
              </div>
            </div>
          )}

          <div className="flex justify-between mt-4">
            <Button variant="outline" onClick={() => setStep(2)}><ChevronLeft className="w-4 h-4" /> Back</Button>
            {!dupLoading && duplicates.length === 0 && (
              <Button onClick={() => setStep(4)}>Next <ChevronRight className="w-4 h-4" /></Button>
            )}
          </div>
        </Card>
      )}

      {/* Step 5: Submit */}
      {step === 4 && (
        <Card>
          <h2 className="text-lg font-semibold text-slate-900 mb-1">Step 5: Review & Submit</h2>
          <p className="text-sm text-slate-500 mb-6">Review your complaint details before submitting.</p>

          <div className="space-y-3 bg-slate-50 rounded-xl p-4 mb-6">
            <div className="flex items-center gap-2"><FileText className="w-4 h-4 text-slate-400" /><span className="text-sm text-slate-500">Category:</span> <span className="text-sm font-medium text-slate-900">{categories.find((c) => c.id === selectedCategory)?.name}</span></div>
            <div className="flex items-center gap-2"><AlertCircle className="w-4 h-4 text-slate-400" /><span className="text-sm text-slate-500">Severity:</span> <Badge className={severityColor(severity)}>{formatSeverity(severity)}</Badge></div>
            <div className="flex items-center gap-2"><MapPin className="w-4 h-4 text-slate-400" /><span className="text-sm text-slate-500">Location:</span> <span className="text-sm font-medium text-slate-900">{locationName}</span></div>
            <div className="flex items-center gap-2"><Building2 className="w-4 h-4 text-slate-400" /><span className="text-sm text-slate-500">Department:</span> <span className="text-sm font-medium text-slate-900">{departments.find((d) => d.id === categories.find((c) => c.id === selectedCategory)?.default_department_id)?.name || 'Auto-assigned'}</span></div>
            <div className="flex items-center gap-2"><Clock className="w-4 h-4 text-slate-400" /><span className="text-sm text-slate-500">Images:</span> <span className="text-sm font-medium text-slate-900">{images.length} photo(s)</span></div>
          </div>

          {imagePreviews.length > 0 && (
            <div className="grid grid-cols-3 gap-2 mb-6">
              {imagePreviews.map((preview, i) => (
                <img key={i} src={preview} alt={`Preview ${i + 1}`} className="w-full h-20 object-cover rounded-lg border border-slate-200" />
              ))}
            </div>
          )}

          <div className="flex justify-between">
            <Button variant="outline" onClick={() => setStep(3)}><ChevronLeft className="w-4 h-4" /> Back</Button>
            <Button onClick={handleSubmit} loading={submitting} size="lg">
              Submit Complaint
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
